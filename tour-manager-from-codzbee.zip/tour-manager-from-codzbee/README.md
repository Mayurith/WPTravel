# Tour Manager - WordPress Plugin

A comprehensive tour management solution for WordPress that helps travel agencies and tour operators manage their offerings efficiently.

## Features

### Tour Management
- Create and manage detailed tour packages
- Day-by-day itinerary planning
- Multiple location support with stay durations
- Hotel associations with meal plan details
- Guest capacity configuration (adults/children)
- Journey highlights and FAQ sections

### Hotel Management
- Image galleries for property visuals
- Location-based organization

### Location Management
- **Google Maps Integration** with waypoints for tour routes
- Geographic coordinates storage (latitude/longitude)
- Address autocomplete using Google Places API
- Waypoint optimization for efficient routing

### Booking & Inquiries
- Inquiry management system
- Status tracking for customer requests
- Notification system
- Admin interface for handling bookings

### Additional Features
- Custom taxonomy for tour categories
- Search widget for frontend
- Shortcodes for easy display
- Responsive design ready

## Installation

1. Upload the `tour-manager-from-codzbee` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the plugin settings under 'Tour Manager' in the admin menu
4. Create the Inquiry form page using `tm_inquiry_form` shortcode
5. Start creating your cities, locations, hotels, and tours

## Requirements

- WordPress 6.8.1 or higher
- PHP 8.2.23 or higher
- MySQL 8.0.35 or higher

## Frequently Asked Questions

### How do I display tours on my site?
Use the included shortcode `[tm_tours]` to display all tours. You can customize the output with various attributes.

### Can I customize the booking form?
Yes, the inquiry form can be customized through template files or via hooks and filters.

## Screenshots

1. Tour creation interface
2. Hotel management screen
3. Location mapping
4. Inquiry dashboard
5. Frontend tour display

## Changelog

### 1.0.0
- Added new shortcode attributes
- Improved mobile responsiveness
- Fixed minor bugs in inquiry system