<!-- includes/templates/location-metabox/location-meta-box.php -->

<!-- country -->
<style>
    .location-meta-fields .form-field {
        margin-bottom: 15px;
    }

    .location-meta-fields label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .location-meta-fields select,
    .location-meta-fields textarea {
        width: 100%;
        max-width: 500px;
    }

    .location-meta-fields textarea {
        resize: vertical;
        min-height: 80px;
    }
</style>

<div class="location-meta-fields">
    <div class="form-field">
        <label for="tm_location_country">Country:</label>
        <select name="tm_location_country" id="tm_location_country" required>
            <option value="">Select a Country</option>
            <?php foreach ($countries as $country): ?>
                <option value="<?= esc_attr($country); ?>" <?php selected($location_country, $country); ?>>
                    <?= esc_html($country); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-field">
        <label for="tm_location_city">City:</label>
        <select name="tm_location_city" id="tm_location_city" required>
            <option value="">Select a Country First</option>
            <?php if (!empty($cities)): ?>
                <?php foreach ($cities as $city): ?>
                    <option value="<?= esc_attr($city->ID); ?>" <?php selected($location_city, $city->ID); ?>>
                        <?= esc_html($city->post_title); ?>
                    </option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>
        <input type="hidden" name="tm_location_city_title" id="tm_location_city_title" value="<?= esc_attr($location_city_title); ?>">
    </div>
</div>

<div class="form-field location-type-selection">
    <div>Select Location Type</div>
    <div class="location-type-options">
        <div>
            <label>
                <input type="radio" name="location_type" value="Activity" <?php checked($location_type, 'Activity') ?>>
                Activity
            </label>
        </div>
        <div>
            <label>
                <input type="radio" name="location_type" value="Attraction" <?php checked($location_type, 'Attraction') ?>>
                Attraction
            </label>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function ($) {
        var citySelect = $('#tm_location_city');
        var hiddenTitleInput = $('#tm_location_city_title');


        citySelect.on('change', function () {
            var selectedCityText = citySelect.find('option:selected').text();
            hiddenTitleInput.val(selectedCityText);
        });


        var initialCityText = citySelect.find('option:selected').text();
        hiddenTitleInput.val(initialCityText);

        // When country selection changes
        $('#tm_location_country').on('change', function () {
            var country = $(this).val();

            if (country) {
                // Show loading
                citySelect.html('<option value="">Loading cities...</option>');

                // AJAX request to get cities
                $.ajax({
                    url: location_manager.ajax_url,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'get_cities_by_country_for_location',
                        country: country,
                        nonce: location_manager.nonce
                    },
                    success: function (response) {
                        if (response.success) {
                            citySelect.html(response.data);

                            // Update hidden input with first city (if auto-selected)
                            var firstCityText = citySelect.find('option:selected').text();
                            hiddenTitleInput.val(firstCityText);
                        } else {
                            console.error('Error:', response.data);
                            citySelect.html('<option value="">Error loading cities</option>');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error:', error);
                        citySelect.html('<option value="">Error loading cities</option>');
                    }
                });
            } else {
                citySelect.html('<option value="">Select a Country First</option>');
                hiddenTitleInput.val('');
            }
        });
    });
</script>
