<?php
if (!defined('ABSPATH')) {
    exit;
}

$location_name = get_post_meta($post->ID, '_location_name', true);
$latitude = get_post_meta($post->ID, '_location_lat', true);
$longitude = get_post_meta($post->ID, '_location_lng', true);
?>

<div class="location-picker-container">
    <!-- Location Input Section -->
    <div class="location-input-section">
        <label for="location_input" class="location-label">
            <i class="fas fa-map-marker-alt"></i>
            Search Location on Map
        </label>
        <div class="input-with-icon">
            <input type="text" 
                   id="location_input" 
                   placeholder="Search for a location or address..." 
                   name="location_name" 
                   value="<?= esc_attr($location_name); ?>" 
                   class="location-input"/>
            <i class="fas fa-search input-icon"></i>
        </div>
    </div>

    <!-- Coordinates Display -->
    <div class="coordinates-container">
        <div class="coordinate-field">
            <label for="location_lat" class="coordinate-label">
                <!-- <i class="fas fa-globe-americas"></i> -->
                Latitude
            </label>
            <input type="text" 
                   id="location_lat" 
                   placeholder="Latitude" 
                   name="location_lat" 
                   value="<?= esc_attr($latitude); ?>" 
                   class="coordinate-input" 
                   readonly>
        </div>
        <div class="coordinate-field">
            <label for="location_lng" class="coordinate-label">
                <!-- <i class="fas fa-globe-americas"></i> -->
                Longitude
            </label>
            <input type="text" 
                   id="location_lng" 
                   placeholder="Longitude" 
                   name="location_lng" 
                   value="<?= esc_attr($longitude); ?>" 
                   class="coordinate-input" 
                   readonly>
        </div>
    </div>

    <!-- Map Container -->
    <div class="map-section">
        <div id="map" class="location-map"></div>
        <p class="map-instruction">
            <i class="fas fa-info-circle"></i>
            Click on the map to set a precise location or search for an address above.
        </p>
    </div>
</div>

<!-- Include Google Maps API and your JS -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places"></script> -->
<script src="<?= plugin_dir_url(__FILE__) . '../../../assets/js/location.js' ?>"></script>

<style>
/* .location-picker-container {
    background: #fff;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    border: 1px solid #e5e7eb;
} */

/* Location Input Styles */
.location-input-section {
    margin-bottom: 20px;
}

.location-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    color: #374151;
    margin-bottom: 8px;
    font-size: 14px;
}

/* .location-label i {
    color: #00807f;
} */

.input-with-icon {
    position: relative;
    width: 100%;
}

.location-input {
    width: 100%;
    padding: 20px 16px 20px 40px;
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
    background: #fafafa;
}

.location-input:focus {
    outline: none;
    border-color: #00807f;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(0, 128, 127, 0.1);
}

.input-icon {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #9ca3af;
}

/* Coordinates Styles */
.coordinates-container {
    display: grid;
    grid-template-rows: 1fr 1fr;
    gap: 16px;
    margin-bottom: 24px;
    background: #f8fafc;
    padding: 16px;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.coordinate-field {
    display: flex;
    flex-direction: column;
}

.coordinate-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    color: #6b7280;
    margin-bottom: 6px;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.coordinate-label i {
    color: #00807f;
    font-size: 10px;
}

.coordinate-input {
    padding: 10px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 13px;
    background: #fff;
    color: #374151;
    font-family: monospace;
}

.coordinate-input:focus {
    outline: none;
    border-color: #00807f;
}

/* Map Section Styles */
.map-section {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
}

.map-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 20px;
    background: #f8fafc;
    border-bottom: 1px solid #e5e7eb;
}

.map-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 16px;
    font-weight: 600;
    color: #374151;
    margin: 0;
}

.map-title i {
    color: #00807f;
}

.map-actions {
    display: flex;
    gap: 8px;
}

.map-action-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    background: #fff;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 12px;
    color: #374151;
    cursor: pointer;
    transition: all 0.2s ease;
}

.map-action-btn:hover {
    background: #00807f;
    color: #fff;
    border-color: #00807f;
}

.map-action-btn i {
    font-size: 10px;
}

.location-map {
    height: 400px;
    width: 100%;
    background: #f8fafc;
}

.map-instruction {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 20px;
    margin: 0;
    background: #f0f9ff;
    border-top: 1px solid #e1f5fe;
    font-size: 12px;
    color: #0369a1;
}

.map-instruction i {
    color: #00807f;
}

/* Responsive Design */
@media (max-width: 768px) {
    .location-picker-container {
        padding: 16px;
    }
    
    .coordinates-container {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .map-header {
        flex-direction: column;
        gap: 12px;
        align-items: flex-start;
    }
    
    .map-actions {
        width: 100%;
        justify-content: flex-start;
    }
    
    .location-map {
        height: 300px;
    }
}

/* Loading State */
.location-input.loading {
    background-image: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%2300807f"><path d="M12 2a1 1 0 0 1 1 1v3a1 1 0 1 1-2 0V3a1 1 0 0 1 1-1zm0 15a1 1 0 0 1 1 1v3a1 1 0 1 1-2 0v-3a1 1 0 0 1 1-1zm8.66-10a1 1 0 0 1-.366 1.366l-2.598 1.5a1 1 0 1 1-1-1.732l2.598-1.5A1 1 0 0 1 20.66 7zM7.67 14.5a1 1 0 0 1-.366 1.366l-2.598 1.5a1 1 0 1 1-1-1.732l2.598-1.5a1 1 0 0 1 1.366.366zM20.66 17a1 1 0 0 1-1.366.366l-2.598-1.5a1 1 0 0 1 1-1.732l2.598 1.5A1 1 0 0 1 20.66 17zM7.67 9.5a1 1 0 0 1-1.366.366l-2.598-1.5a1 1 0 1 1 1-1.732l2.598 1.5A1 1 0 0 1 7.67 9.5z"/></svg>');
    background-size: 16px;
    background-position: calc(100% - 12px) center;
    background-repeat: no-repeat;
    padding-right: 40px;
}
</style>