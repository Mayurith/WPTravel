<?php
/**
 * Top Sight Meta Box Template
 *
 * This template is used to render the meta box for marking a location as a top sight.
 *
 * @package Tour_Manager_From_Codzbee
 */

if (!defined('ABSPATH')) {
    exit;
}

$is_popular = get_post_meta($post->ID, '_is_top_sight', true);

?>


<div>
    <div><label for="tm_top_site">Select as top sights</label></div>
    <div>
        <div>
            <input type="radio" id="tm_top_site_yes" name="tm_top_site" value="yes" <?php checked( $is_popular, 'yes' ); ?> />
            <label for="tm_top_site_yes">Yes</label>
        </div>
        <div>
            <input type="radio" id="tm_top_site_no" name="tm_top_site" value="no" <?php checked( $is_popular, 'no' ); ?> />
            <label for="tm_top_site_no">No</label>
        </div>
    </div>
</div>