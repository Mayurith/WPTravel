<?php
/**
 * Location Gallery Meta Box Template
 */
// Get saved gallery images
$location_gallery = get_post_meta($post->ID, '_location_gallery', true);
$gallery_ids = !empty($location_gallery) ? explode(',', $location_gallery) : array();

// Security nonce
wp_nonce_field('save_gallery_data', 'gallery_meta_nonce');
?>

<div class="location-gallery-metabox">
    <input type="hidden" name="tm_location_gallery" id="tm_location_gallery"
        value="<?= esc_attr(implode(',', $gallery_ids)); ?>" />

    <div class="gallery-actions">
        <button type="button" class="button button-primary" id="location_gallery_upload">
            <?php _e('Add Gallery Images', 'tour-manager'); ?>
        </button>
        <button type="button" class="button" id="location_gallery_remove_all">
            <?php _e('Remove All Images', 'tour-manager'); ?>
        </button>
    </div>

    <div class="gallery-preview" id="location_gallery_preview">
        <?php if (!empty($gallery_ids)): ?>
            <?php foreach ($gallery_ids as $image_id): ?>
                <?php if ($image_url = wp_get_attachment_image_url($image_id, 'thumbnail')): ?>
                    <div class="gallery-image" data-image-id="<?php echo esc_attr($image_id); ?>">
                        <img src="<?php echo esc_url($image_url); ?>" alt="" />
                        <span class="remove-image">×</span>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-images"><?php _e('No gallery images selected.', 'tour-manager'); ?></p>
        <?php endif; ?>
    </div>
</div>



<!-- 
<style>
    .location-meta-fields .form-field {
        margin-bottom: 15px;
    }

    .location-meta-fields label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .location-meta-fields select,
    .location-meta-fields textarea {
        width: 100%;
        max-width: 500px;
    }

    .location-meta-fields textarea {
        resize: vertical;
        min-height: 80px;
    }

    /* Gallery Styles */
    .location-gallery-metabox {
        margin: 15px 0;
    }

    .gallery-actions {
        margin-bottom: 15px;
    }

    .gallery-preview {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 15px;
    }

    .gallery-image {
        position: relative;
        width: 100px;
        height: 100px;
        border: 1px solid #ddd;
        border-radius: 3px;
        overflow: hidden;
    }

    .gallery-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .gallery-image .remove-image {
        position: absolute;
        top: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        color: white;
        width: 20px;
        height: 20px;
        text-align: center;
        line-height: 20px;
        cursor: pointer;
        font-size: 16px;
    }

    .gallery-image .remove-image:hover {
        background: #dc3232;
    }

    .no-images {
        color: #666;
        font-style: italic;
        margin: 10px 0;
    }
</style> -->

<style>
    .location-meta-fields .form-field {
        margin-bottom: 15px;
    }

    .location-meta-fields label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .location-meta-fields select,
    .location-meta-fields textarea {
        width: 100%;
        max-width: 500px;
    }

    .location-meta-fields textarea {
        resize: vertical;
        min-height: 80px;
    }

    /* Gallery Styles */
    .location-gallery-metabox {
        margin: 15px 0;
    }

    .gallery-actions {
        margin-bottom: 15px;
    }

    .gallery-preview {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 15px;
    }

    .gallery-image {
        position: relative;
        width: 100px;
        height: 100px;
        border: 1px solid #ddd;
        border-radius: 3px;
        overflow: hidden;
    }

    .gallery-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .gallery-image .remove-image {
        position: absolute;
        top: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        color: white;
        width: 20px;
        height: 20px;
        text-align: center;
        line-height: 20px;
        cursor: pointer;
        font-size: 16px;
    }

    .gallery-image .remove-image:hover {
        background: #dc3232;
    }

    .no-images {
        color: #666;
        font-style: italic;
        margin: 10px 0;
    }
</style>


<script>
    jQuery(document).ready(function ($) {
        // Gallery functionality
        var locationGalleryFrame;
        var locationGalleryIds = $('#tm_location_gallery').val() ? $('#tm_location_gallery').val().split(',') : [];

        // Open media frame for gallery
        $('#location_gallery_upload').on('click', function (e) {
            e.preventDefault();

            if (locationGalleryFrame) {
                locationGalleryFrame.open();
                return;
            }

            locationGalleryFrame = wp.media({
                title: location_manager.title,
                button: {
                    text: location_manager.button_text
                },
                multiple: true,
                library: {
                    type: 'image'
                }
            });

            // Pre-select existing images when opening the media frame
            locationGalleryFrame.on('open', function () {
                var selection = locationGalleryFrame.state().get('selection');
                locationGalleryIds.forEach(function (id) {
                    var attachment = wp.media.attachment(id);
                    attachment.fetch();
                    selection.add(attachment ? [attachment] : []);
                });
            });

            locationGalleryFrame.on('select', function () {
                var attachments = locationGalleryFrame.state().get('selection').toJSON();
                var galleryPreview = $('#location_gallery_preview');

                $.each(attachments, function (i, attachment) {
                    // Check if image is not already in the gallery
                    if ($.inArray(attachment.id.toString(), locationGalleryIds) === -1) {
                        locationGalleryIds.push(attachment.id.toString());

                        galleryPreview.append(
                            '<div class="gallery-image" data-image-id="' + attachment.id + '">' +
                            '<img src="' + attachment.sizes.thumbnail.url + '" alt="" />' +
                            '<span class="remove-image">×</span>' +
                            '</div>'
                        );
                    }
                });

                $('#tm_location_gallery').val(locationGalleryIds.join(','));

                // Remove "no images" message if images were added
                if (locationGalleryIds.length > 0) {
                    galleryPreview.find('.no-images').remove();
                }
            });

            locationGalleryFrame.open();
        });

        // Remove single image
        $(document).on('click', '.gallery-image .remove-image', function () {
            var imageDiv = $(this).closest('.gallery-image');
            var imageId = imageDiv.data('image-id').toString();

            locationGalleryIds = locationGalleryIds.filter(function (id) {
                return id !== imageId;
            });

            imageDiv.remove();
            $('#tm_location_gallery').val(locationGalleryIds.join(','));

            if (locationGalleryIds.length === 0) {
                $('#location_gallery_preview').append('<p class="no-images">' + location_manager.no_images + '</p>');
            }
        });

        // Remove all images
        $('#location_gallery_remove_all').on('click', function () {
            locationGalleryIds = [];
            $('#tm_location_gallery').val('');
            $('#location_gallery_preview').html('<p class="no-images">' + location_manager.no_images + '</p>');
        });

        // AJAX for loading cities based on country selection
        $('#tm_location_country').on('change', function () {
            var country = $(this).val();
            var citySelect = $('#tm_location_city');

            if (!country) {
                citySelect.html('<option value="">Select a City</option>');
                return;
            }

            // Show loading
            citySelect.html('<option value="">Loading cities...</option>');

            $.ajax({
                url: location_manager.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_cities_by_country_for_location',
                    country: country,
                    nonce: location_manager.nonce
                },
                success: function (response) {
                    if (response.success) {
                        citySelect.html(response.data);

                        // Set the previously selected city if it exists
                        var savedCityId = $('#tm_location_city').data('saved-value');
                        if (savedCityId) {
                            citySelect.val(savedCityId);
                        }
                    } else {
                        citySelect.html('<option value="">Error loading cities</option>');
                        console.error(response.data);
                    }
                },
                error: function () {
                    citySelect.html('<option value="">Error loading cities</option>');
                }
            });
        });

        // Initialize - remove "no images" message if there are images
        if (locationGalleryIds.length > 0) {
            $('#location_gallery_preview').find('.no-images').remove();
        }
    });
</script>

<!-- <script>
    jQuery(document).ready(function ($) {
        // Gallery functionality
        var locationGalleryFrame;
        var locationGalleryIds = $('#tm_location_gallery').val() ? $('#tm_location_gallery').val().split(',') : [];

        // Open media frame for gallery
        $('#location_gallery_upload').on('click', function (e) {
            e.preventDefault();

            if (locationGalleryFrame) {
                locationGalleryFrame.open();
                return;
            }

            locationGalleryFrame = wp.media({
                title: location_manager.title,
                button: {
                    text: location_manager.button_text
                },
                multiple: true,
                library: {
                    type: 'image'
                }
            });

            // Pre-select existing images
            locationGalleryFrame.on('open', function () {
                var selection = locationGalleryFrame.state().get('selection');
                locationGalleryIds.forEach(function (id) {
                    var attachment = wp.media.attachment(id);
                    attachment.fetch();
                    selection.add(attachment ? [attachment] : []);
                });
            });

            locationGalleryFrame.on('select', function () {
                var attachments = locationGalleryFrame.state().get('selection').toJSON();
                var galleryPreview = $('#location_gallery_preview');

                // Clear existing preview but keep the array for new selection
                galleryPreview.empty();
                locationGalleryIds = [];

                $.each(attachments, function (i, attachment) {
                    locationGalleryIds.push(attachment.id.toString());

                    galleryPreview.append(
                        '<div class="gallery-image" data-image-id="' + attachment.id + '">' +
                        '<img src="' + attachment.sizes.thumbnail.url + '" alt="" />' +
                        '<span class="remove-image">×</span>' +
                        '</div>'
                    );
                });

                $('#tm_location_gallery').val(locationGalleryIds.join(','));

                if (locationGalleryIds.length === 0) {
                    galleryPreview.append('<p class="no-images">' + location_manager.no_images + '</p>');
                }
            });

            locationGalleryFrame.open();
        });

        // Remove single image
        $(document).on('click', '.gallery-image .remove-image', function () {
            var imageDiv = $(this).closest('.gallery-image');
            var imageId = imageDiv.data('image-id').toString();

            locationGalleryIds = locationGalleryIds.filter(function (id) {
                return id !== imageId;
            });

            imageDiv.remove();
            $('#tm_location_gallery').val(locationGalleryIds.join(','));

            if (locationGalleryIds.length === 0) {
                $('#location_gallery_preview').append('<p class="no-images">' + location_manager.no_images + '</p>');
            }
        });

        // Remove all images
        $('#location_gallery_remove_all').on('click', function () {
            locationGalleryIds = [];
            $('#tm_location_gallery').val('');
            $('#location_gallery_preview').html('<p class="no-images">' + location_manager.no_images + '</p>');
        });
    });
</script> -->