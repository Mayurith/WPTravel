<?php
/** includes/templates/archive-tour.php */

get_header();

/** Get search parameters from the widget **/
$selected_country = isset($_GET['country']) ? sanitize_text_field($_GET['country']) : '';
$selected_city = isset($_GET['city']) ? sanitize_text_field($_GET['city']) : '';
$selected_duration = isset($_GET['duration']) ? sanitize_text_field($_GET['duration']) : '';
$selected_category = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$selected_months = isset($_GET['months']) ? sanitize_text_field($_GET['months']) : '';

// Debug: Check what parameters we're receiving
error_log("Search Parameters - Country: {$selected_country}, Months: {$selected_months}, Category: {$selected_category}");

// Check if this is a search request (any parameter is set)
$is_search = !empty($selected_country) || !empty($selected_city) || !empty($selected_duration) ||
    !empty($selected_category) || !empty($selected_months);

/** If no search parameters, show all tours */
if (!$is_search) {
    $args = array(
        'post_type' => 'tour',
        'posts_per_page' => -1,
        'post_status' => 'publish'
    );
    $tour_query = new WP_Query($args);
}
/** If search parameters exist, apply filters */ else {
    /** VALIDATION: Country is required for search */
    if (empty($selected_country)) {
        // If no country selected but other parameters exist, show empty results
        $args = array(
            'post_type' => 'tour',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'post__in' => array(0)
        );
        $tour_query = new WP_Query($args);
    } else {
        /** STEP 1: Get tours by destination (country) */
        $tour_ids_by_country = tm_get_tours_by_country($selected_country);
        error_log("Tours found for country '{$selected_country}': " . count($tour_ids_by_country));

        if (empty($tour_ids_by_country)) {
            // No tours found for this country
            $args = array(
                'post_type' => 'tour',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'post__in' => array(0)
            );
            $tour_query = new WP_Query($args);
        } else {
            $filtered_tour_ids = $tour_ids_by_country;

            /** STEP 2: Apply month filter if selected */
            if (!empty($selected_months)) {
                $month_values = explode(',', $selected_months);
                error_log("Month values from URL: " . implode(', ', $month_values));

                $tour_ids_by_months = tm_get_tours_by_months($month_values);
                error_log("Tours found for months: " . count($tour_ids_by_months));

                if (!empty($tour_ids_by_months)) {
                    $filtered_tour_ids = array_intersect($filtered_tour_ids, $tour_ids_by_months);
                    error_log("After month filter intersection: " . count($filtered_tour_ids));
                } else {
                    $filtered_tour_ids = array();
                    error_log("No tours found for the selected months");
                }
            }

            /** STEP 3: Apply category filter if selected - FIXED */
            if (!empty($selected_category) && !empty($filtered_tour_ids)) {
                error_log("Applying category filter for: '{$selected_category}'");

                // First, try to get category by name (what the widget sends)
                $category = get_term_by('name', $selected_category, 'tour_category');

                if ($category) {
                    error_log("Found category by name: {$category->slug}");
                    $tour_ids_by_category = tm_get_tours_by_category($category->slug);
                } else {
                    // If not found by name, try by slug
                    $category = get_term_by('slug', $selected_category, 'tour_category');
                    if ($category) {
                        error_log("Found category by slug: {$category->slug}");
                        $tour_ids_by_category = tm_get_tours_by_category($category->slug);
                    } else {
                        error_log("Category not found: '{$selected_category}'");
                        $tour_ids_by_category = array();
                    }
                }

                error_log("Tours found for category '{$selected_category}': " . count($tour_ids_by_category));

                if (!empty($tour_ids_by_category)) {
                    $filtered_tour_ids = array_intersect($filtered_tour_ids, $tour_ids_by_category);
                    error_log("After category filter intersection: " . count($filtered_tour_ids));
                } else {
                    $filtered_tour_ids = array();
                    error_log("No tours found for the selected category");
                }
            }


            // Final query
            if (!empty($filtered_tour_ids)) {
                $args = array(
                    'post_type' => 'tour',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'post__in' => $filtered_tour_ids,
                    'orderby' => 'post__in'
                );
                error_log("Final tour count: " . count($filtered_tour_ids));
            } else {
                $args = array(
                    'post_type' => 'tour',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'post__in' => array(0)
                );
                error_log("No tours found after all filters");
            }

            $tour_query = new WP_Query($args);
        }
    }
}
?>

<!-- hero section -->
<section class="relative z-10 -mt-28 h-[850px]">
    <?php
    // Check if current page/post has a featured image
    if (has_post_thumbnail()) {
        $hero_bg = get_the_post_thumbnail_url(get_the_ID(), 'full');
    } else {
        // Default image fallback
        $hero_bg = get_template_directory_uri() . '/assets/images/hero-section-bg-2.jpeg';
    }
    ?>
    <div class="relative h-[850px] bg-no-repeat bg-center bg-cover flex flex-col items-center justify-center"
        style="background-image: url('<?= esc_url($hero_bg); ?>');">
        <!-- Overlay with fade-in animation -->
        <div class="absolute inset-0 bg-darkblue/40 z-5 opacity-0 animate-fadeIn"></div>
        <div class="relative text-center z-20 w-full">
            <h1 class="text-white text-xl sm:text-4xl font-medium">Relive the Journey</h1>
            <div class="text-white mt-4">Unforgettable journeys from around the globe.</div>
        </div>
        <div class="container mx-auto sm:px-24 px-4 relative text-center z-20 w-full">
            <div class="" style="margin: 100px; 100px 0 100px">
                <?= do_shortcode('[tm_tour_search_widget_globelodger]'); ?>
            </div>
        </div>
    </div>
</section>

<!-- Tours -->
<section class="container mx-auto mt-20 sm:px-24 px-4">

    <?php if ($tour_query->have_posts()): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
            <?php while ($tour_query->have_posts()):
                $tour_query->the_post();
                $post_id = get_the_ID();
                $itinerary = get_post_meta($post_id, '_trip_itinerary', true);
                $available_months = get_post_meta($post_id, '_available_months', true);
                $available_months = is_array($available_months) ? $available_months : [];

                // Calculate duration
                $total_days = !empty($itinerary) && is_array($itinerary) ? count($itinerary) : 0;
                $total_nights = max(0, $total_days - 1);
                $duration_days = $total_days ? "$total_nights Nights - $total_days Days" : 'Duration not specified';
                ?>

                <!-- Card -->
                <div
                    class="rounded-sm overflow-hidden hover:shadow-lg transition-shadow duration-300 group flex flex-col h-full max-h-[500px]">
                    <?php if (has_post_thumbnail()): ?>
                        <a href="<?php the_permalink(); ?>"
                            class="block rounded-lg overflow-hidden hover:shadow-lg transition duration-300">
                            <?php the_post_thumbnail('post-thumbnail', [
                                'class' => 'w-full h-64 object-cover rounded-lg transform transition-transform duration-300 group-hover:scale-105'
                            ]); ?>
                        </a>
                    <?php endif; ?>

                    <div class="p-4 mt-3 flex flex-col flex-grow">
                        <div class="text-primary text-lg leading-[1.6rem] font-semibold mt-3">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </div>

                        <div class="mt-2 text-secondary text-md">
                            <?= esc_html($duration_days); ?>
                        </div>

                        <div class="text-dark text-md mt-3 mb-4 px-1 flex-grow">
                            <?php
                            $excerpt = wp_trim_words(get_the_excerpt(), 15, '...');
                            echo esc_html($excerpt);
                            ?>
                        </div>

                        <div class="mt-auto">
                            <a href="<?php the_permalink(); ?>">
                                <button
                                    class="flex items-center text-secondary bg-secondary/10 hover:text-white hover:bg-secondary py-2 px-8 rounded-sm cursor-pointer justify-center transition">
                                    <span class="text-sm font-medium">More</span>
                                    <i class="lni lni-arrow-angular-top-right text-secondary ml-2 text-2xl"></i>
                                </button>
                            </a>
                        </div>
                    </div>
                </div>

            <?php endwhile; ?>
        </div>
        <?php wp_reset_postdata(); ?>

    <?php else: ?>
        <div class="items-center justify-center min-h-[300px] w-full text-center">
            <div class="text-dark mb-4">
                <?php if ($is_search): ?>
                    No tours found matching your search criteria.
                <?php else: ?>
                    No tours available at the moment.
                <?php endif; ?>
            </div>
            <a href="<?= esc_url(get_post_type_archive_link('tour')); ?>"
                class="inline-block bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-dark transition duration-300">
                View All Tours
            </a>
        </div>
    <?php endif; ?>
</section>

<?php
// Helper function to get tours by country
function tm_get_tours_by_country($country_name)
{
    $tours = get_posts(array(
        'post_type' => 'tour',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'fields' => 'ids'
    ));

    $matching_tour_ids = array();

    foreach ($tours as $tour_id) {
        $itinerary = get_post_meta($tour_id, '_trip_itinerary', true);

        if (!empty($itinerary) && is_array($itinerary)) {
            foreach ($itinerary as $day) {
                if (!empty($day['country']) && stripos($day['country'], $country_name) !== false) {
                    $matching_tour_ids[] = $tour_id;
                    break;
                }
            }
        }
    }

    return array_unique($matching_tour_ids);
}

// Helper function to get tours by months
function tm_get_tours_by_months($month_values)
{
    error_log("Month values received in function: " . implode(', ', $month_values));

    // Map month abbreviations to full month names
    $month_mapping = [
        'Janu' => 'January',
        'Feb' => 'February',
        'Mar' => 'March',
        'Apr' => 'April',
        'May' => 'May',
        'June' => 'June',
        'July' => 'July',
        'Aug' => 'August',
        'Sep' => 'September',
        'Oct' => 'October',
        'Nov' => 'November',
        'Dec' => 'December'
    ];

    $tours = get_posts(array(
        'post_type' => 'tour',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'fields' => 'ids'
    ));

    $matching_tour_ids = array();
    $found_count = 0;

    foreach ($tours as $tour_id) {
        $available_months = get_post_meta($tour_id, '_available_months', true);
        $available_months = is_array($available_months) ? $available_months : [];

        error_log("Tour {$tour_id} available months: " . implode(', ', $available_months));

        // Convert search month values to full month names
        $search_month_names = array();
        foreach ($month_values as $month_value) {
            if (isset($month_mapping[$month_value])) {
                $search_month_names[] = $month_mapping[$month_value];
            } else {
                // If it's already a full name, use it directly
                $search_month_names[] = $month_value;
            }
        }

        error_log("Searching for months: " . implode(', ', $search_month_names));

        // Check if any of the search months exist in available months
        $found_match = false;
        foreach ($search_month_names as $search_month) {
            if (in_array($search_month, $available_months)) {
                $matching_tour_ids[] = $tour_id;
                $found_count++;
                $found_match = true;
                error_log("✓ Tour {$tour_id} matches month: {$search_month}");
                break; // No need to check other months for this tour
            }
        }

        if (!$found_match && !empty($available_months)) {
            error_log("✗ Tour {$tour_id} doesn't match any search months");
        }
    }

    error_log("Total tours matching months: {$found_count}");
    return array_unique($matching_tour_ids);
}

// Helper function to get tours by Category
function tm_get_tours_by_category($category_slug)
{
    error_log("Searching for category slug: '{$category_slug}'");

    $tours = get_posts(array(
        'post_type' => 'tour',
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'fields' => 'ids',
        'tax_query' => array(
            array(
                'taxonomy' => 'tour_category',
                'field' => 'slug',
                'terms' => $category_slug
            )
        )
    ));

    error_log("Found " . count($tours) . " tours for category slug: '{$category_slug}'");
    return $tours;
}
?>

<?php
get_footer();