<?php
/** includes/templates/tour-book.php */

get_header();

// Initialize variables
$tour_id = $tour_title = $arrival_date = $adults = $children = $total_price = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'book_tour') {
    // Sanitize and validate POST data
    $tour_id = sanitize_text_field($_POST['tour_id']);
    $tour_title = sanitize_text_field($_POST['tour_name']);
    $tour_slug = sanitize_text_field($_POST['tour_slug']);
    $arrival_date = sanitize_text_field($_POST['check-in-date']);
    $adults = intval($_POST['adults']);
    $children = intval($_POST['children']);
    $total_price = floatval($_POST['total_price']);

    // Get tour data for verification
    $adult_rate = floatval(get_post_meta($tour_id, '_adult_rate', true));
    $child_rate = floatval(get_post_meta($tour_id, '_child_rate', true));

    // Verify the calculated price matches
    $calculated_price = ($adults * $adult_rate) + ($children * $child_rate);

} else {
    // If not POST, redirect back to tour page
    wp_redirect(home_url('/tours/'));
    exit;
}

/**
 * @var mixed
 * Path to the JSON file containing country data.
 */
$countries_json_path = plugin_dir_path(__DIR__) . '/../assets/data/countries.json';

$countries = [];
if (file_exists($countries_json_path)) {
    $countries = json_decode(file_get_contents($countries_json_path), true);
}

?>

<!-- page banner -->
<section class="relative z-10 -mt-28 h-[350px] sm:h-[750px]">
    <div class="relative h-[350px] sm:!h-[750px] bg-no-repeat bg-center bg-cover flex items-center justify-center"
        style="background-image: url('<?= get_template_directory_uri() ?>/assets/images/hero-section-bg-2.jpeg');">
        <div class="relative text-center z-10">
            <h2 class="!text-white font-semibold">Inquiry Confirmation</h2>
            <div class="!text-white mt-4 font-medium"><?= get_the_title($tour_id); ?></div>
        </div>
        <!-- Overlay -->
        <div class="absolute inset-0 bg-darkblue/50 z-5"></div>
    </div>
</section>

<section class="container mx-auto mt-20 sm:px-24 px-4 lg:mt-20">
    <div class="grid grid-cols-1 grid-cols-2 border border-secondary rounded-lg">

        <!-- left side -->
        <div class="bg-secondary text-center flex flex-col items-center justify-center">
            <a href="<?= esc_url(home_url('/')); ?>">
                <img src="<?= get_template_directory_uri(); ?>/assets/images/logo.png" alt="logo"
                    class="w-auto h-14 object-contain" />
            </a>
            <div class="text-2xl font-semibold text-white mt-6"><?= get_the_title($tour_id); ?></div>
        </div>

        <!-- right side -->
        <div class="py-6 px-10">
            <form action="" id="tour-booking-form" method="POST" class="tour-booking-form">
                <?php wp_nonce_field('tour_booking_nonce', 'tour_booking_security'); ?>
                <input type="hidden" name="tour_title" value="<?= esc_attr(get_the_title($tour_id)); ?>">
                <input type="hidden" name="action" value="submit_tour_booking">

                <!-- contact details -->
                <div class="text-2xl font-semibold text-primary mb-3">Contact Details</div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <input type="text" name="full_name" id="full_name" placeholder="Full Name"
                            class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 mb-4 focus:outline-none focus:ring-2 focus:ring-secondary" />
                        <!-- <input type="text" name="phone" placeholder="Phone Number"
                            class="w-full border border-gray-200 rounded-md p-2 mb-4 focus:outline-none focus:ring-2 focus:ring-secondary"
                            required /> -->
                        <input type="tel" id="phone" name="phone"
                            class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate tm-phone-input">
                    </div>
                    <div>
                        <input type="email" name="email" id="email" placeholder="Email"
                            class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary" />
                        <input type="text" name="country" id="country" placeholder="Country"
                            class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 mt-4 focus:outline-none focus:ring-2 focus:ring-secondary" />
                    </div>
                </div>
                <div>
                    <textarea name="message" id="message" cols="30" rows="20" placeholder="message"
                        class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 mt-4 focus:outline-none focus:ring-2 focus:ring-secondary"></textarea>
                </div>

                <!-- booking details -->
                <div class="text-2xl font-semibold text-primary mt-3 mb-3">Booking Details</div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <!-- check-in-date -->
                        <label for="check-in-date"
                            class="block mb-2 text-sm font-medium text-gray-600 dark:text-white">Arrival Date</label>
                        <input type="text" readonly value="<?= esc_attr($arrival_date); ?>"
                            class="w-full bg-secondary/10 rounded-md p-2 mb-1 sm:mb-4" />

                        <!-- total price -->
                        <!-- <label for="total-price"
                            class="block mb-2 text-sm font-medium text-gray-600 dark:text-white">Total
                            Amount</label>
                        <input type="text" readonly value="USD <?= number_format($total_price, 2); ?>"
                            class="w-full bg-secondary/10 rounded-md p-2 mb-4" /> -->
                    </div>
                    <div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="adults"
                                    class="block mb-2 text-sm font-medium text-gray-600 dark:text-white">Adults</label>
                                <input type="text" readonly value="<?= esc_attr($adults); ?> A"
                                    class="w-full bg-secondary/10 rounded-md p-2 mb-1 sm:mb-4" />
                            </div>
                            <div>
                                <label for="children"
                                    class="block mb-2 text-sm font-medium text-gray-600 dark:text-white">Children</label>
                                <input type="text" readonly value="<?= esc_attr($children); ?> C"
                                    class="w-full bg-secondary/10 rounded-md p-2 mb-1 sm:mb-4" />
                            </div>
                        </div>
                    </div>
                </div>

                <!-- to pass these values to the final booking -->
                <input type="hidden" name="tour_id" value="<?= esc_attr($tour_id); ?>">
                <input type="hidden" name="arrival_date" value="<?= esc_attr($arrival_date); ?>">
                <input type="hidden" name="adults" value="<?= esc_attr($adults); ?>">
                <input type="hidden" name="children" value="<?= esc_attr($children); ?>">
                <input type="hidden" name="total_price" value="<?= esc_attr($total_price); ?>">

                <!-- buttons -->
                <div class="py-4 flex gap-4 justify-end ">
                    <div>
                        <button
                            class="border border-lightblue text-secondary px-6 py-2 rounded-sm transition-all w-full text-center font-semibold cursor-pointer"
                            onclick="window.history.back();" class="tm-back-btn">
                            Back
                        </button>
                    </div>
                    <div>
                        <button id="tour-booking-btn"
                            class="border bg-secondary text-white px-6 py-2 rounded-sm hover:bg-primary transition-all w-full text-center font-semibold cursor-pointer">
                            Book Now
                        </button>
                    </div>
                </div>
            </form>
            <div id="tm-booking-modal"
                class="tm-modal fixed inset-0 flex bg-black/50 backdrop-blur-sm mx-auto items-center justify-center"
                style="display: none; background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(0px);">
                <!-- <div class="tm-modal-overlay"></div> -->
                <div class="tm-modal-content text-center bg-white rounded-lg px-8 py-4 shadow-xl animate-fade-slide relative"
                    style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);">
                    <!-- <div class="tm-modal-header">
                        <h3 class="tm-modal-title"></h3>
                        <button type="button" class="tm-modal-close">&times;</button>
                    </div> -->
                    <div class="tm-modal-body mb-4">
                        <p class="tm-modal-message text-gray-700 text-center text-base mr-2 p-2"></p>
                    </div>
                    <div class="tm-modal-footer">
                        <!-- <button type="button" class="tm-modal-close bg-primary text-white py-2 px-4 rounded cursor-pointer">OK</button> -->
                        <?php if (isset($type) && $type === 'success'): ?>
                            <button type="button"
                                class="tm-modal-ok bg-primary text-white py-2 px-4 rounded cursor-pointer">
                                OK
                            </button>
                        <?php else: ?>
                            <button type="button"
                                class="tm-modal-close bg-primary text-white py-2 px-4 rounded cursor-pointer">
                                OK
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php

function enqueue_tour_booking_assets()
{
    wp_enqueue_style(
        'tour-booking-form-style',
        plugin_dir_url(__FILE__) . '../../assets/css/inquiry-booking-form.css',
        array(),
        filemtime(plugin_dir_path(__FILE__) . '../../assets/css/inquiry-booking-form.css')
    );

    // /** intl-tel-input CSS */
    // wp_enqueue_style(
    //     'intl-tel-input',
    //     'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css',
    //     array(),
    //     '17.0.8'
    // );

    // Main booking form JS
    wp_enqueue_script(
        'tour-booking-form-script',
        plugin_dir_url(__FILE__) . '../../assets/js/inquiry-form.js',
        ['jquery'],
        filemtime(plugin_dir_path(__FILE__) . '../../assets/js/inquiry-form.js'),
        true
    );

    // /** intl-tel-input JS */
    // wp_enqueue_script(
    //     'intl-tel-input',
    //     'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js',
    //     array(),
    //     '17.0.8',
    //     true
    // );

    // Localize script data
    wp_localize_script(
        'tour-booking-form-script',
        'tourInquiryData',
        [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tour_booking_ajax_nonce'),
            'tour_url' => esc_url(home_url('/tour/')),
            // 'countries' => get_countries_list()
        ]
    );
}
add_action('wp_enqueue_scripts', 'enqueue_tour_booking_assets');

function get_countries_list()
{
    $countries_json_path = plugin_dir_path(__DIR__) . '/../assets/data/countries.json';

    if (file_exists($countries_json_path)) {
        $countries_data = json_decode(file_get_contents($countries_json_path), true);

        if (is_array($countries_data) && !empty($countries_data)) {
            if (is_string($countries_data[0])) {
                return $countries_data;
            } else {
                $country_names = [];
                foreach ($countries_data as $country) {
                    if (isset($country['name'])) {
                        $country_names[] = $country['name'];
                    }
                }
                return $country_names;
            }
        }
    }

    // Fallback to hardcoded list if JSON file doesn't exist or is invalid
    return array(
        'Afghanistan',
        'Albania',
        'Algeria',
        'Andorra',
        'Angola',
        'Zambia',
        'Zimbabwe'
    );
}

get_footer();