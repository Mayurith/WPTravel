
<?php
/** includes/templates/single-hotel.php */

/**
 * @file single-hotel.php
 * @description Display the details for a hotel.
 * @return void return the hotel by hotel details
 */


get_header();

global $wp_query;
$hotel_post = $wp_query->get_queried_object();
$hotel_id = $hotel_post->ID;

/** Get the tour slug and the related tour ID (for hotel details) */
$tour_slug = sanitize_title(basename(dirname($_SERVER['REQUEST_URI'])));
$tour = get_page_by_path($tour_slug, OBJECT, 'tour');
$tour_id = $tour ? $tour->ID : 0;

/**  Fetch hotel metadata */
$selected_hotels = get_post_meta($tour_id, '_selected_hotels', true);
$hotel_thumbnail = get_the_post_thumbnail($hotel_id, 'post-thumbnail');
$hotel_location = get_post_meta($hotel_id, '_hotel_city_name', true);
$hotel_gallery = get_post_meta($hotel_id, '_hotel_image_gallery', true);
$hotel_excerpt = get_the_excerpt($hotel_id);


?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<main class="tm-page-container">
    <section class="tm-hotel-details">
        <div class="header">
            <div class="animated-hotel-thumbnail">
                <?= $hotel_thumbnail; ?>
            </div>
            <div class="tm-hotel-second-section">
                <h3><?= esc_html($hotel_post->post_title); ?></h3>
                <div class="tm-hotel-location">
                    <h4><i class='fas fa-map-marker-alt'></i>
                        <?= !empty($hotel_location) ? esc_html($hotel_location) : 'Location not available'; ?>
                    </h4>
                </div>
                <?php
                $tour_id = 0;
                $itinerary = [];
                $tour_query = new WP_Query([
                    'post_type' => 'tour',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                ]);
                foreach ($tour_query->posts as $tour_post) {
                    $it = get_post_meta($tour_post->ID, '_trip_itinerary', true);
                    if (!empty($it['days'])) {
                        foreach ($it['days'] as $day) {
                            if (!empty($day['hotel_id']) && $day['hotel_id'] == $hotel_id) {
                                $tour_id = $tour_post->ID;
                                $itinerary = $it;
                                break 2;
                            }
                        }
                    }
                }
                wp_reset_postdata();
                ?>
                <div class="tm-hotel-meal-plan">
                    <?php
                    $has_meal_plan = false;
                    if (!empty($itinerary['days'])) {
                        foreach ($itinerary['days'] as $day_index => $day) {
                            if (!empty($day['hotel_id']) && $day['hotel_id'] == $hotel_id) {
                                $has_meal_plan = true;
                                ?>
                                <div class="hotel-meal-plan-day">
                                    <?php echo !empty($day['meal_plan']) ?
                                        "<h4><i class='fa-solid fa-utensils'></i>" . wp_kses_post($day['meal_plan']) . "</h4>" : ''; ?>
                                </div>
                                <?php
                            }
                        }
                    }
                    if (!$has_meal_plan) {
                        echo "<p>No meal plan description available for this hotel.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="tm-hotel-data">
            <p><?= wp_kses_post($hotel_post->post_content); ?></p>
        </div>

        <h2 class="gallery-heading">Explore the images of the hotel..</h2>
    </section>

    <section>
        <div class="tm-hotel-gallery-grid">
            <?php
            if (!empty($hotel_gallery)) {
                $hotel_gallery_images = explode(',', $hotel_gallery);
                $sizes = [
                    'large' => [2, 2], // spans 2 columns and 2 rows
                    'medium' => [2, 1], // spans 2 columns and 1 row
                    'tall' => [1, 2], // spans 1 column and 2 rows
                    'normal' => [1, 1], // default size
                ];
                $size_classes = ['large', 'medium', 'tall', 'normal'];
                $i = 0;
                foreach ($hotel_gallery_images as $gallery_id) {
                    $image_url = wp_get_attachment_url($gallery_id);
                    if ($image_url) {
                        // Cycle through different size classes
                        $size_class = $size_classes[$i % count($size_classes)];
                        $span = $sizes[$size_class];
                        echo "<div class='tm-gallery-grid-item {$size_class}' style='grid-column: span {$span[0]}; grid-row: span {$span[1]};'><img src='" . esc_url($image_url) . "' alt='Gallery Image'></div>";
                        $i++;
                    }
                }
            } else {
                echo "<p>No gallery images available.</p>";
            }
            ?>

    </section>
</main>


<?php get_footer(); ?>