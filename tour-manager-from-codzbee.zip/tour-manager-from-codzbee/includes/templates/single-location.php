<?php
/**
 * Single Location Template
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

global $post;

// Get the location post object
$location = get_queried_object();

if ($location && $location->post_type === 'location') {
    setup_postdata($location);

    // Get custom field data
    $location_id = $location->ID;
    $location_title = get_the_title($location_id);
    $location_description = get_the_content();
    $location_excerpt = get_the_excerpt();

    $location_thumbnail = get_the_post_thumbnail($location_id, 'thumbnail_large');
    $location_thumbnail_url = get_the_post_thumbnail_url($location_id, 'post-thumbnail');
    $default_bg = get_template_directory_uri() . '/assets/images/hero-bg-6.webp';
    $bg_image = $location_thumbnail_url ? $location_thumbnail_url : $default_bg;

    $gallery = get_post_meta($location_id, '_location_gallery', true);
    $gallery_ids = !empty($gallery) ? explode(',', $gallery) : [];

    $location_country = get_post_meta($location_id, '_location_country', true);
    $location_city = get_post_meta($location_id, '_location_city', true);

}

?>

<!-- page banner -->
<section class="relative z-10 -mt-28 h-[350px] sm:h-[750px]">
    <div class="relative !h-[350px] sm:!h-[750px] bg-no-repeat bg-center bg-cover flex items-center justify-center"
        style="background-image: url('<?= esc_url($bg_image); ?>');">
        <!-- Overlay with fade-in animation -->
        <div class="absolute inset-0 bg-darkblue/40 z-5 opacity-0 animate-fadeIn"></div>
        <div class="relative text-center z-20 w-full">
            <h2 class="!text-white font-semibold"><?= esc_html($location_title); ?></h2>
            <div class="!text-white mt-4 font-medium"><?= $location_country; ?></div>
        </div>
    </div>
</section>


<!-- description -->
<section class="container mx-auto mt-20 sm:px-24 px-4 location-description">
    <p class="text-md text-justify"><?= wpautop($location_description); ?></p>
</section>


<!-- gallery -->
<section class="container mx-auto mt-20 sm:px-24 px-4">
    <h3 class="text-primary text-3xl font-semibold">Gallery</h3>
    <!-- <div class="text-dark text-md mt-3">These popular destinations have a lot to offer</div> -->

    <?php if (!empty($gallery_ids)): ?>
        <div class="swiper mySwiper mt-6 h-[300px]">
            <div class="swiper-wrapper">
                <?php foreach ($gallery_ids as $img_id):
                    $img_url = wp_get_attachment_image_url($img_id, 'post-thumbnail');
                    if ($img_url): ?>
                        <div class="swiper-slide">
                            <img src="<?= esc_url($img_url); ?>" alt="" class="rounded-sm w-64 h-64" />
                        </div>
                    <?php endif;
                endforeach; ?>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
        </div>
    <?php else: ?>
        <div class="mt-6 text-gray-500">No gallery images found.</div>
    <?php endif; ?>
</section>

<!-- custom cursor -->
<div id="custom-cursor">
    <span id="cursor-label"> Drag </span>
</div>

<?php
get_footer();