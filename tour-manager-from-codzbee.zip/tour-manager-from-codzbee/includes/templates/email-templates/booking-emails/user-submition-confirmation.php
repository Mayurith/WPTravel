<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Submission Confirmation</title>
    <!--[if mso]>
    <style type="text/css">
        body, table, td, div, p, a {
            font-family: Arial, sans-serif !important;
        }
        .email-wrapper {
            width: 600px !important;
        }
        table {
            mso-cellspacing: 0;
            mso-padding-alt: 0;
            border-collapse: collapse !important;
        }
    </style>
    <![endif]-->
    <style type="text/css">
        /* Common styles for all email clients */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333333;
            background-color: #f5f5f5;
        }

        /* For email clients that support web fonts */
        @media screen and (-webkit-min-device-pixel-ratio:0) {
            body {
                font-family: 'Jost', Arial, sans-serif !important;
            }
        }

        /* Email wrapper */
        .email-wrapper {
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
            background-color: #ffffff;
        }

        /* Header */
        .email-header {
            background-color: #f8f9fa;
            text-align: center;
            border-bottom: 3px solid #00807f;
        }

        /* Content */
        .email-content {
            padding: 20px;
        }

        /* Field styling */
        .info-field {
            background-color: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .field-label {
            font-weight: bold;
            color: #00807f;
            display: block;
        }

        /* Footer */
        .email-footer {
            background-color: #00807f;
            color: #ffffff;
            text-align: center;
            font-size: 12px;
            border-top: 1px solid #ddd;
        }

        /* Confirmation banner */
        .confirmation-banner {
            background-color: #00807f;
            color: #ffffff;
            text-align: center;
            font-weight: bold;
            /* margin-bottom: 20px; */
        }

        a {
            color: #ffffff !important;
        }

        /* Responsive */
        @media only screen and (max-width: 600px) {
            .email-wrapper {
                width: 100% !important;
            }

            .email-content {
                padding: 15px !important;
            }
        }
    </style>
</head>

<body style="margin:0; padding:0; background-color:#f5f5f5; font-family:Arial, sans-serif;">

    <!--[if mso]>
    <center>
    <table width="600" align="center" cellpadding="0" cellspacing="0" border="0" style="width:600px;">
    <tr><td style="padding:20px;">
    <![endif]-->

    <div class="email-wrapper" style="max-width:600px; width:100%; margin:0 auto; background-color:#ffffff;">

        <!-- Header -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-header"
                    style="background-color: #e5f2f2; text-align:center; border-bottom:3px solid #00807f; padding:20px;">
                    <h2 style="margin:0 0 10px 0; color:#333333; font-family:Arial, sans-serif;">Booking Submission
                        Confirmation</h2>
                    <p style="margin:0; color:#333333;">Thank you for choosing <?php echo get_bloginfo('name'); ?>!</p>
                </td>
            </tr>
        </table>

        <!-- Confirmation Banner -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="confirmation-banner"
                    style="background-color:#00807f; color:#ffffff; text-align:center;padding:10px; font-weight:bold;">
                    Your Booking Reference: #<?php echo $post_id; ?>
                </td>
            </tr>
        </table>

        <!-- Content Area -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-content" style="padding:20px; font-family:Arial, sans-serif;">

                    <p style="margin:0 0 15px 0;">Dear <?php echo esc_html($data['full_name']); ?>,</p>

                    <p style="margin:0 0 20px 0;">We have successfully received your booking request with the following
                        details:</p>

                    <!-- Tour Package -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="background-color:#f8f9fa; border-radius:5px; padding:10px;">
                                <span class="field-label"
                                    style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Tour
                                    Package:</span>
                                <span style="color:#333333;"><?php echo esc_html($data['tour_title']); ?></span>
                            </td>
                        </tr>
                    </table>

                    <!-- Booking Details -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="background-color:#f8f9fa; border-radius:5px; padding:10px;">
                                <span class="field-label"
                                    style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Booking
                                    Details:</span>
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                    <tr>
                                        <td style="padding:5px 0;">Arrival Date:</td>
                                        <td style="padding:5px 0;">
                                            <strong><?php echo esc_html($data['arrival_date']); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td style="padding:5px 0;">Number of Guests:</td>
                                        <td style="padding:5px 0;">
                                            <strong><?php echo $data['adults']; ?> Adults,
                                                <?php echo $data['children']; ?> Children</strong>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>

                    <!-- Customer Message -->
                    <?php if (!empty($data['message'])): ?>
                        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:20px;">
                            <tr>
                                <td class="info-field" style="background-color:#f8f9fa; border-radius:5px; padding:10px;">
                                    <span class="field-label"
                                        style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Your
                                        Message:</span>
                                    <div
                                        style="margin-top:8px; padding:10px; background-color:#ffffff; border-radius:3px; border:1px solid #e0e0e0;">
                                        <?php echo nl2br(esc_html($data['message'])); ?>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    <?php endif; ?>

                    <!-- Closing Messages -->
                    <p style="margin:20px 0 10px 0; font-weight:bold;">
                        We're thrilled you've booked with us, get ready for an exciting journey!
                    </p>

                    <p style="margin:10px 0 20px 0; font-weight:bold;">
                        Our team will review the details carefully and contact you shortly to confirm your booking and
                        provide any additional information you may need.
                    </p>

                </td>
            </tr>
        </table>

        <!-- Footer -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-footer"
                    style="background-color:#00807f; color:#ffffff; text-align:center; font-size:12px; padding:20px; border-top:1px solid #ddd;">
                    <p style="margin:0 0 10px 0; font-size:13px; font-weight:bold;">Best regards,</p>
                    <p style="margin:0 0 10px 0;;">The Team at <?php echo get_bloginfo('name'); ?></p>
                    <p style="margin:0 0 5px 0;">
                        Email: <?php echo get_option('admin_email'); ?>
                    </p>
                    <p style="margin:0;">
                        Website: <?php echo home_url(); ?>
                    </p>
                </td>
            </tr>
        </table>

    </div>

    <!--[if mso]>
    </td></tr></table>
    </center>
    <![endif]-->

</body>

</html>