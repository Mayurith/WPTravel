<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Tour Booking Received</title>
    <!--[if mso]>
    <style type="text/css">
        body, table, td, div, p, a {
            font-family: Arial, sans-serif !important;
        }
        .container-table {
            width: 600px !important;
        }
        table {
            mso-cellspacing: 0;
            mso-padding-alt: 0;
        }
    </style>
    <![endif]-->
    <style type="text/css">
        /* Common styles for all email clients */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333333;
            background-color: #f5f5f5;
            font-size: 12px;
        }
        
        /* For email clients that support web fonts */
        /* @media screen and (-webkit-min-device-pixel-ratio:0) {
            body {
                font-family: 'Jost', Arial, sans-serif !important;
            }
        } */
        
        /* Container for the email */
        .email-container {
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
            background-color: #ffffff;
        }
        
        /* Header styles */
        .email-header {
            background-color: #f8f9fa;
            text-align: center;
            border-bottom: 3px solid #00807f;
        }
        
        /* Content area */
        .email-content {
            padding: 20px;
        }
        
        /* Field styling */
        .info-field {
            background-color: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 15px;
            padding: 12px;
        }
        
        .field-label {
            font-weight: bold;
            color: #00807f;
            display: block;
            margin-bottom: 5px;
        }
        
        /* Footer */
        .email-footer {
            background-color: #00807f;
            color: #ffffff;
            text-align: center;
            /* font-size: 12px; */
        }
        
        /* Confirmation banner */
        .confirmation-banner {
            background-color: #00807f;
            color: #ffffff;
            text-align: center;
            padding: 15px;
            font-weight: bold;
        }
        
        /* Note styling */
        .note-box {
            color: #f16f6f;
            font-style: italic;
            background-color: #fff8f8;
            border-left: 4px solid #f16f6f;
            padding: 15px;
            margin: 20px 0;
        }
        
        /* Responsive */
        @media only screen and (max-width: 600px) {
            .email-container {
                width: 100% !important;
            }
            .email-content {
                padding: 15px !important;
            }
        }
    </style>
</head>
<body style="margin:0; padding:0; background-color:#f5f5f5;">

    <!--[if mso]>
    <center>
    <table width="600" align="center" cellpadding="0" cellspacing="0" border="0" style="width:600px;">
    <tr><td style="padding:20px;">
    <![endif]-->

    <div class="email-container" style="max-width:600px; width:100%; margin:0 auto; background-color:#ffffff;">
        
        <!-- Header -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-header" style="font-size:12px; background-color:#f8f9fa; text-align:center; border-bottom:3px solid #00807f; padding:20px;">
                    <!-- <a href="https://globelodger.codzbee.com/" style="text-decoration:none;">
                        <img src="https://globelodger.codzbee.com/wp-content/themes/globe-lodger/assets/images/logo.webp" 
                             alt="Globe Lodger Logo" width="200" height="56" style="display:block; margin:0 auto; max-width:200px; height:auto;">
                    </a> -->
                    <h2 style="margin:15px 0 0 0; color:#333333; font-family:Arial, sans-serif;">New Tour Booking Received</h2>
                </td>
            </tr>
        </table>

        <!-- Booking ID -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="confirmation-banner" style="background-color:#00807f; font-size:12px; color:#ffffff; font-weight:bold; text-align:center; padding:10px;">
                    Booking ID: #<?php echo $post_id; ?>
                </td>
            </tr>
        </table>

        <!-- Content Area -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-content" style="font-size:12px; padding:20px; font-family:Arial, sans-serif;">
                    <p style="margin:0 0 15px 0;">A new tour booking has been submitted with the following details:</p>

                    <!-- Tour Information -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="font-size:12px; background-color:#f8f9fa; border-radius:5px; padding:12px;">
                                <span class="field-label" style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Tour:</span>
                                <span style="color:#333333;"><?php echo esc_html($data['tour_title']); ?></span>
                            </td>
                        </tr>
                    </table>

                    <!-- Customer Information -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="background-color:#f8f9fa; border-radius:5px; padding:12px;">
                                <span class="field-label" style="font-size:12px; font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Customer Information:</span>
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                    <tr>
                                        <td width="80" style="width:80px; padding:2px 0;">Name:</td>
                                        <td style="padding:2px 0;"><strong><?php echo esc_html($data['full_name']); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td width="80" style="width:80px; padding:2px 0;">Email:</td>
                                        <td style="padding:2px 0;"><?php echo esc_html($data['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <td width="80" style="width:80px; padding:2px 0;">Phone:</td>
                                        <td style="padding:2px 0;"><?php echo esc_html($data['phone']); ?></td>
                                    </tr>
                                    <tr>
                                        <td width="80" style="width:80px; padding:2px 0;">Country:</td>
                                        <td style="padding:2px 0;"><?php echo esc_html($data['country']); ?></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>

                    <!-- Booking Details -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="font-size:12px; background-color:#f8f9fa; border-radius:5px; padding:12px;">
                                <span class="field-label" style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Booking Details:</span>
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                    <tr>
                                        <td width="100" style="width:100px; padding:2px 0;">Arrival Date:</td>
                                        <td style="padding:2px 0;"><strong><?php echo esc_html($data['arrival_date']); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td width="100" style="width:100px; padding:2px 0;">Guests:</td>
                                        <td style="padding:2px 0;">
                                            <?php echo $data['adults']; ?> Adults, <?php echo $data['children']; ?> Children
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>

                    <!-- Customer Message -->
                    <?php if (!empty($data['message'])): ?>
                    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">
                        <tr>
                            <td class="info-field" style="font-size:12px; background-color:#f8f9fa; border-radius:5px; padding:12px;">
                                <span class="field-label" style="font-weight:bold; color:#00807f; display:block; margin-bottom:5px;">Customer Message:</span>
                                <div style="margin-top:8px; padding:10px; background-color:#ffffff; border-radius:3px; border:1px solid #e0e0e0;">
                                    <?php echo nl2br(esc_html($data['message'])); ?>
                                </div>
                            </td>
                        </tr>
                    </table>
                    <?php endif; ?>

                    <!-- Note -->
                    <table width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tr>
                            <td class="note-box" style="font-size:12px; color:#f16f6f; font-style:italic; background-color:#fff8f8; border-left:4px solid #f16f6f; padding:15px; margin:20px 0;">
                                Please review this booking in your admin panel and contact the customer to confirm availability and proceed with payment.
                            </td>
                        </tr>
                    </table>

                </td>
            </tr>
        </table>

        <!-- Footer -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td class="email-footer" style="background-color:#00807f; color:#ffffff; text-align:center; font-size:12px; padding:20px;">
                    <p style="margin:0; font-family:Arial, sans-serif;">
                        This email was automatically sent from <?php echo get_bloginfo('name'); ?> on <?php echo date('F j, Y \a\t g:i A'); ?>
                    </p>
                </td>
            </tr>
        </table>

    </div>

    <!--[if mso]>
    </td></tr></table>
    </center>
    <![endif]-->

</body>
</html>