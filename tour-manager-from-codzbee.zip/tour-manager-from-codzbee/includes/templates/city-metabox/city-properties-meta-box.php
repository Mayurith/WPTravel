<?php
/** includes/templates/city-metabox/city-properties-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$city_property = get_post_meta($post->ID, '_city_property', true);

?>


<div>
    <label for="tm_city_property">Property</label>
    <input type="text" name="tm_city_property" id="tm_city_property" value="<?= esc_attr($city_property); ?>" placeholder="14 Hotel - 22 Cars - 18 Tours - 95 Activity" style="width: 100%; padding: 8px;" />
    <small style="font-style: italic; color: #858383;">Enter the number of properties</small>
</div>