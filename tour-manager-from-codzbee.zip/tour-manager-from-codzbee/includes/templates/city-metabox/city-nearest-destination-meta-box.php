<?php
/** includes/templates/nearest-destinations-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$api_key = get_option('tm_google_map_api', get_bloginfo('map_api'));
$city_latitude = get_post_meta($post->ID, '_city_latitude', true);
$city_longitude = get_post_meta($post->ID, '_city_longitude', true);
$city_address = get_post_meta($post->ID, '_city_address', true);
?>

<!-- Address Input for Autocomplete -->
<div style="margin: 20px 0;">
    <label for="address" style="display: block; margin-bottom: 8px; font-weight: bold;">Search City on Map</label>
    <input id="address" type="text" placeholder="Type to search for a city..." 
           value="<?= esc_attr($city_address); ?>" 
           style="width: 100%; padding: 10px; font-size: 16px;" />
    <small style="font-style: italic; color: #858383;">Start typing to search and pin the city on the map.</small>
</div>

<!-- Hidden Fields for Saving -->
<input type="hidden" name="city_address" id="city_address_input" value="<?= esc_attr($city_address); ?>" />
<input type="hidden" name="city_latitude" id="city_latitude_input" value="<?= esc_attr($city_latitude); ?>" />
<input type="hidden" name="city_longitude" id="city_longitude_input" value="<?= esc_attr($city_longitude); ?>" />

<!-- Coordinates Display -->
<div class="coordinates" style="margin: 10px 0; padding: 10px; background: #f9f9f9; border-radius: 4px;">
    <strong>Latitude:</strong> <span id="lat"><?= esc_html($city_latitude ?: '-'); ?></span><br>
    <strong>Longitude:</strong> <span id="lng"><?= esc_html($city_longitude ?: '-'); ?></span>
</div>

<!-- Google Map -->
<div id="map"></div>

<script>
    let map, marker, autocomplete;

    function loadGoogleMaps() {
        if (!window.google) {
            const script = document.createElement('script');
            script.src = `https://maps.googleapis.com/maps/api/js?key=<?= $api_key ?>&libraries=places&loading=async&callback=initMap`;
            script.async = true;
            script.defer = true;
            script.onerror = gm_authFailure;
            document.head.appendChild(script);
        } else {
            initMap();
        }
    }

    function initMap() {
        const defaultLat = parseFloat("<?= esc_attr($city_latitude ?: '7.8731'); ?>");
        const defaultLng = parseFloat("<?= esc_attr($city_longitude ?: '80.7718'); ?>");
        const defaultLocation = { lat: defaultLat, lng: defaultLng };

        map = new google.maps.Map(document.getElementById("map"), {
            center: defaultLocation,
            zoom: 7,
            mapTypeControl: true,
            streetViewControl: true,
            fullscreenControl: true,
        });

        // Add marker (draggable)
        marker = new google.maps.Marker({
            map: map,
            position: defaultLocation,
            draggable: true,
            title: "Drag to adjust location",
        });

        // Update on drag end
        marker.addListener('dragend', function () {
            const position = marker.getPosition();
            updateCoordinates(position.lat(), position.lng());
            reverseGeocode(position.lat(), position.lng());
        });

        // Click map to move marker
        map.addListener('click', function (event) {
            marker.setPosition(event.latLng);
            updateCoordinates(event.latLng.lat(), event.latLng.lng());
            reverseGeocode(event.latLng.lat(), event.latLng.lng());
        });

        // Initialize autocomplete
        setTimeout(initAutocomplete, 100);
    }

    function initAutocomplete() {
        const input = document.getElementById("address");
        const autocomplete = new google.maps.places.Autocomplete(input, {
            types: ['(cities)'],
            fields: ['geometry', 'formatted_address']
        });

        autocomplete.addListener('place_changed', function () {
            const place = autocomplete.getPlace();
            if (!place.geometry) return;

            const location = place.geometry.location;
            map.setCenter(location);
            map.setZoom(10);
            marker.setPosition(location);

            updateCoordinates(location.lat(), location.lng());
            document.getElementById("city_address_input").value = place.formatted_address;
        });

        const defaultLat = parseFloat("<?= esc_attr($city_latitude ?: '7.8731'); ?>");
        const defaultLng = parseFloat("<?= esc_attr($city_longitude ?: '80.7718'); ?>");
        if (defaultLat && defaultLng) updateCoordinates(defaultLat, defaultLng);
    }

    function updateCoordinates(lat, lng) {
        document.getElementById("lat").innerText = lat.toFixed(6);
        document.getElementById("lng").innerText = lng.toFixed(6);
        document.getElementById("city_latitude_input").value = lat.toFixed(6);
        document.getElementById("city_longitude_input").value = lng.toFixed(6);
    }

    function reverseGeocode(lat, lng) {
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            if (status === "OK" && results[0]) {
                document.getElementById("address").value = results[0].formatted_address;
                document.getElementById("city_address_input").value = results[0].formatted_address;
            }
        });
    }

    function gm_authFailure() {
        document.getElementById('map').innerHTML = `
            <div style="display:flex;align-items:center;justify-content:center;height:400px;background:#f8f9fa;color:#6c757d;text-align:center;">
                <p>Unable to load Google Maps. Check your API key.</p>
            </div>
        `;
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadGoogleMaps);
    } else {
        loadGoogleMaps();
    }
</script>

<style>
    #map {
        height: 400px;
        width: 100%;
        margin-top: 20px;
        border-radius: 8px;
        border: 1px solid #ddd;
    }

    #address {
        width: 100%;
        padding: 12px;
        font-size: 16px;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
    }

    #address:focus {
        outline: none;
        border-color: #007cba;
        box-shadow: 0 0 0 1px #007cba;
    }

    .coordinates {
        margin-top: 15px;
        padding: 12px;
        background: #f8f9fa;
        border-radius: 4px;
        border-left: 4px solid #007cba;
    }

    label {
        font-weight: 600;
        color: #1d2327;
    }

    .pac-container {
        z-index: 100000 !important;
    }
</style>
