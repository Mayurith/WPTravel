<?php
if (!defined('ABSPATH')) {
    exit;
}

$city_subtitle = get_post_meta($post->ID, '_city_subtitle', true);
$genral_info_title = get_post_meta($post->ID, '_general_info_title', true);
$genral_info_time_zone = get_post_meta($post->ID, '_general_info_time_zone', true);
$genral_info_sub_title = get_post_meta($post->ID, '_general_info_sub_title', true);
$genral_info_title_2 = get_post_meta($post->ID, '_general_info_title_2', true);
$genral_info_time_zone_2 = get_post_meta($post->ID, '_general_info_time_zone_2', true);
$genral_info_sub_title_2 = get_post_meta($post->ID, '_general_info_sub_title_2', true);
$genral_info_title_3 = get_post_meta($post->ID, '_general_info_title_3', true);
$genral_info_time_zone_3 = get_post_meta($post->ID, '_general_info_time_zone_3', true);
$genral_info_sub_title_3 = get_post_meta($post->ID, '_general_info_sub_title_3', true);
$genral_info_time_zone_4 = get_post_meta($post->ID, '_general_info_time_zone_4', true);
$genral_info_sub_title_4 = get_post_meta($post->ID, '_general_info_sub_title_4', true);

?>

<style>
    .tab-content {
        display: none;
        padding-top: 10px;
    }

    input[name="section-toggle"]:checked + label {
        font-weight: bold;
        /* text-decoration: underline; */
        background-color: #f0f0f0;
    }

    input[name="section-toggle"] {
        display: none;
    }

    #page-banner:checked ~ .tab-contents #page-banner-content,
    #general-info:checked ~ .tab-contents #general-info-content {
        display: block;
    }

    .tab-label {
        margin-right: 20px;
        cursor: pointer;
        padding: 5px 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .tab-switcher {
        margin: 20px 0;
    }
</style>

<div class="form-field">

    <!-- Tab Switcher -->
    <div class="tab-switcher">
        <input type="radio" name="section-toggle" id="page-banner" checked>
        <label for="page-banner" class="tab-label">Page Banner</label>

        <input type="radio" name="section-toggle" id="general-info">
        <label for="general-info" class="tab-label">General Info</label>
    </div>

    <!-- Tab Contents -->
    <div class="tab-contents">

        <!-- Page Banner Section -->
        <div id="page-banner-content" class="tab-content">
            <h3>Page Banner</h3>
            <div>
                <label for="tm_subtitle">Subtitle</label>
                <input type="text" name="tm_subtitle" id="tm_subtitle"
                    value="<?= esc_attr(get_post_meta($post->ID, '_city_subtitle', true)); ?>">
                <small style="font-style: italic; color: #858383;">Show on banner in the single page</small>
            </div>
        </div>

        <!-- General Info Section -->
        <div id="general-info-content" class="tab-content">
            <h3>General Info</h3>
            <table>
                <tr>
                    <td>First Column</td>
                    <td><input type="text" name="general_info_title"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_title', true)); ?>"
                            placeholder="Time Zone"></td>
                    <td><input type="text" name="general_info_zone"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_time_zone', true)); ?>"
                            placeholder="GMT +00:00"></td>
                    <td><input type="text" name="general_info_sub_title"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_sub_title', true)); ?>"
                            placeholder="3 hours behind"></td>
                </tr>

                <tr>
                    <td>Second Column</td>
                    <td><input type="text" name="general_info_title_2"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_title_2', true)); ?>"
                            placeholder="Currency"></td>
                    <td><input type="text" name="general_info_zone_2"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_time_zone_2', true)); ?>"
                            placeholder="British Pound"></td>
                    <td><input type="text" name="general_info_sub_title_2"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_sub_title_2', true)); ?>"
                            placeholder="1USD = 0.76GBP"></td>
                </tr>

                <tr>
                    <td>Third Column</td>
                    <td><input type="text" name="general_info_title_3"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_title_3', true)); ?>"
                            placeholder="Best time to visit"></td>
                    <td><input type="text" name="general_info_zone_3"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_time_zone_3', true)); ?>"
                            placeholder="JUN"></td>
                    <td><input type="text" name="general_info_sub_title_3"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_sub_title_3', true)); ?>"
                            placeholder="The Queen's Birthday"></td>
                    <td><input type="text" name="general_info_zone_4"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_time_zone_4', true)); ?>"
                            placeholder="JUN"></td>
                    <td><input type="text" name="general_info_sub_title_4"
                            value="<?= esc_attr(get_post_meta($post->ID, '_general_info_sub_title_4', true)); ?>"
                            placeholder="The Queen's Birthday"></td>
                </tr>
            </table>
        </div>

    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const labels = document.querySelectorAll('.tab-label');
        const contents = document.querySelectorAll('.tab-content');

        labels.forEach(label => {
            label.addEventListener('click', function () {
                contents.forEach(content => content.style.display = 'none');
                const target = this.getAttribute('for') + '-content';
                document.getElementById(target).style.display = 'block';
            });
        });
    });
</script>
