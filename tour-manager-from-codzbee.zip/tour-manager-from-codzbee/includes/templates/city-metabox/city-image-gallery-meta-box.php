<?php
/** includes/templates/city-metabox/city-image-gallery-meta-box.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/** Get existing values */
$image_gallery = get_post_meta($post->ID, '_city_image_gallery', true);
$image_ids = !empty($image_gallery) ? explode(',', $image_gallery) : [];
?>

<!-- Image gallery -->
<div class="image-gallery-meta-box-container">
    <input type="hidden" id="city_image_gallery" name="city_image_gallery" value="<?= esc_attr($image_gallery); ?>" />

    <a href="#" id="city_image_gallery_button">
        <?php esc_html_e('Add Gallery Images', 'text-domain'); ?>
    </a>

    <div id="city_image_gallery_preview" style="margin-top:10px;">
        <?php
        if (!empty($image_ids)) {
            foreach ($image_ids as $img_id) {
                $img_url = wp_get_attachment_image_url($img_id, 'thumbnail');
                if ($img_url) {
                    echo '<div class="gallery-item" data-id="' . esc_attr($img_id) . '" style="display:inline-block; position:relative; margin-right:20px; margin-bottom:20px;">';
                    echo '<img src="' . esc_url($img_url) . '" style="max-width:100px; margin-right:5px;" />';
                    echo '<span class="remove-image" style="position:absolute; top:0; right:0; background:#c0392b; color:#fff; padding:2px 5px; cursor:pointer; transition:background 0.2s;">×</span>';
                    echo '</div>';
                }
            }
        }
        ?>
    </div>
</div>

<?php
/** Enqueue media scripts */
add_action('admin_enqueue_scripts', function() {
    if (is_admin()) {
        wp_enqueue_media();
    }
});
?>

<!-- Media library -->
<script>
    jQuery(document).ready(function($) {
        var frame;

        function updateGalleryInput() {
            var ids = [];
            $('#city_image_gallery_preview .gallery-item').each(function() {
                ids.push($(this).data('id'));
            });
            $('#city_image_gallery').val(ids.join(','));
        }

        $('#city_image_gallery_button').on('click', function(e) {
            e.preventDefault();

            // Always create a new frame to ensure multiple selection works
            var frame = wp.media({
                title: '<?php esc_html_e('Select Gallery Images', 'text-domain'); ?>',
                button: {
                    text: '<?php esc_html_e('Add to Gallery', 'text-domain'); ?>'
                },
                multiple: true, // This enables multiple selection
                library: {
                    type: 'image'
                }
            });

            // Pre-select existing images
            frame.on('open', function() {
                var selection = frame.state().get('selection');
                var current_ids = $('#city_image_gallery').val().split(',').map(Number).filter(id => id);
                if (current_ids.length) {
                    current_ids.forEach(function(id) {
                        var attachment = wp.media.model.Attachment.get(id);
                        attachment.fetch();
                        selection.add(attachment);
                    });
                }
            });

            frame.on('select', function() {
                var selection = frame.state().get('selection');
                var existing_ids = $('#city_image_gallery').val().split(',').map(Number).filter(id => id);
                var ids = existing_ids.slice(); // Start with existing IDs

                selection.each(function(attachment) {
                    if (ids.indexOf(attachment.id) === -1) {
                        ids.push(attachment.id); // Add new IDs only
                    }
                });

                $('#city_image_gallery_preview').empty();

                ids.forEach(function(id) {
                    var attachment = wp.media.model.Attachment.get(id);
                    attachment.fetch().then(function() {
                        var thumb = attachment.attributes.sizes && attachment.attributes.sizes.thumbnail ? attachment.attributes.sizes.thumbnail.url : attachment.attributes.url;
                        $('#city_image_gallery_preview').append(
                            '<div class="gallery-item" data-id="' + id +
                            '" style="display:inline-block; position:relative; margin-right:20px; margin-bottom:20px;">' +
                            '<img src="' + thumb + '" style="max-width:100px; margin-right:5px;" />' +
                            '<span class="remove-image" style="position:absolute; top:0; right:0; background:#c0392b; color:#fff; padding:2px 5px; cursor:pointer; transition:background 0.2s;">×</span>' +
                            '</div>'
                        );

                        // Add hover CSS for .remove-image
                        if ($('#city-image-gallery-meta-box-hover-style').length === 0) {
                            $('head').append(
                                '<style id="city-image-gallery-meta-box-hover-style">' +
                                '.gallery-item .remove-image:hover { background: #e74c3c !important; }' +
                                '</style>'
                            );
                        }
                    });
                });

                $('#city_image_gallery').val(ids.join(','));
            });

            frame.open();
        });

        $('#city_image_gallery_preview').on('click', '.remove-image', function(e) {
            e.preventDefault();
            $(this).closest('.gallery-item').remove();
            updateGalleryInput();
        });
    });
</script>
