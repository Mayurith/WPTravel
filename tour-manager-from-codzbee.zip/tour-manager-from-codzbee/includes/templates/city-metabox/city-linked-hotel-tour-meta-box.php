<?php
/** includes/templates/city-metabox/city-linked-hotel-tour-meta-box.php */
if (!defined('ABSPATH')) {
    exit;
}

// Get existing values
$hotel_url = get_post_meta($post->ID, '_tm_city_hotel_url', true);
$tour_url = get_post_meta($post->ID, '_tm_city_tour_url', true);
?>

<div class="tm-meta-box-container">
    <div class="tm-field-group">
        <label for="tm_city_hotel_url" style="display: block; margin-bottom: 5px; font-weight: bold;">
            <?php _e('Hotel URL', 'text-domain'); ?>
        </label>
        <input type="url" id="tm_city_hotel_url" name="tm_city_hotel_url" value="<?php echo esc_url($hotel_url); ?>"
            placeholder="https://example.com/hotels" style="width: 100%; padding: 8px; margin-bottom: 15px;"
            pattern="https?://.+">
        <p class="description">
            <?php _e('Enter the URL for linked hotels', 'text-domain'); ?>
        </p>
    </div>

    <div class="tm-field-group">
        <label for="tm_city_tour_url" style="display: block; margin-bottom: 5px; font-weight: bold;">
            <?php _e('Tour URL', 'text-domain'); ?>
        </label>
        <input type="url" id="tm_city_tour_url" name="tm_city_tour_url" value="<?php echo esc_url($tour_url); ?>"
            placeholder="https://example.com/tours" style="width: 100%; padding: 8px; margin-bottom: 15px;"
            pattern="https?://.+">
        <p class="description">
            <?php _e('Enter the URL for linked tours', 'text-domain'); ?>
        </p>
    </div>
</div>

<style>
    .tm-meta-box-container {
        padding: 15px 0;
    }

    .tm-field-group {
        margin-bottom: 20px;
    }

    .tm-field-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
</style>

<script>
    jQuery(document).ready(function ($) {
        $('#tm_city_hotel_url, #tm_city_tour_url').on('blur', function (e) {
            var $input = $(this);
            var url = $input.val().trim();

            if (url && !url.match(/^https?:\/\//)) {
                // Prevent the blur from completing temporarily
                e.preventDefault();

                // Show error message
                alert('Please enter a valid URL starting with http:// or https://');

                // Refocus after a short delay to allow the alert to close
                setTimeout(function () {
                    $input.focus();
                }, 100);

                return false;
            }

            // Clear any previous error if valid
            $input.removeClass('tm-url-error');
        });

        // Better approach: Validate on form submission
        $('#post').on('submit', function (e) {
            var hasError = false;

            $('#tm_city_hotel_url, #tm_city_tour_url').each(function () {
                var url = $(this).val().trim();
                if (url && !url.match(/^https?:\/\//)) {
                    alert('Please enter a valid URL starting with http:// or https:// for ' + $(this).attr('name'));
                    $(this).addClass('tm-url-error').focus();
                    hasError = true;
                    return false; // Break out of each loop
                }
            });

            if (hasError) {
                e.preventDefault();
                return false;
            }
        });

        // Add visual error styling
        $('<style>.tm-url-error { border: 2px solid #dc3232 !important; }</style>').appendTo('head');
    });
</script>