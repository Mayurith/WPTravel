<?php
// Get existing FAQs
$faqs = get_post_meta($post->ID, '_city_faqs', true);
$faqs = is_array($faqs) ? $faqs : array();

// Add nonce for security
wp_nonce_field('save_city_faq', 'tm_faq_nonce');
?>

<div class="city-faq-metabox">
    <div id="faq-items">
        <?php if (!empty($faqs)): ?>
            <?php foreach ($faqs as $index => $faq): ?>
                <div class="faq-item" data-index="<?= $index; ?>">
                    <div class="faq-header">
                        <h4><?php _e('FAQ Item', 'city-manager'); ?></h4>
                        <button type="button" class="button remove-faq"><?php _e('Remove', 'city-manager'); ?></button>
                    </div>
                    <p>
                        <label for="faq_question_<?= $index; ?>"><?php _e('Question:', 'city-manager'); ?></label>
                        <input type="text" name="faq_questions[]" id="faq_question_<?= $index; ?>"
                            value="<?= esc_attr($faq['question']); ?>" class="widefat">
                    </p>
                    <p>
                        <label for="faq_answer_<?= $index; ?>"><?php _e('Answer:', 'city-manager'); ?></label>
                        <textarea name="faq_answers[]" id="faq_answer_<?= $index; ?>" class="widefat"
                            rows="5"><?= esc_textarea($faq['answer']); ?></textarea>
                    </p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="faq-item" data-index="0">
                <div class="faq-header">
                    <h4><?php _e('FAQ Item', 'city-manager'); ?></h4>
                    <button type="button" class="button remove-faq"><?php _e('Remove', 'city-manager'); ?></button>
                </div>
                <p>
                    <label for="faq_question_0"><?php _e('Question:', 'city-manager'); ?></label>
                    <input type="text" name="faq_questions[]" id="faq_question_0" value="" class="widefat">
                </p>
                <p>
                    <label for="faq_answer_0"><?php _e('Answer:', 'city-manager'); ?></label>
                    <textarea name="faq_answers[]" id="faq_answer_0" class="widefat" rows="5"></textarea>
                </p>
            </div>
        <?php endif; ?>
    </div>

    <button type="button" id="add-faq" class="button button-primary"><?php _e('Add FAQ', 'city-manager'); ?></button>
</div>

<style>
    .city-faq-metabox .faq-item {
        border: 1px solid #ccd0d4;
        padding: 10px;
        margin-bottom: 15px;
        background: #fff;
    }

    .city-faq-metabox .faq-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        border-bottom: 1px solid #f1f1f1;
        padding-bottom: 10px;
    }

    .city-faq-metabox .faq-header h4 {
        margin: 0;
    }

    .city-faq-metabox label {
        font-weight: 600;
        display: block;
        margin-bottom: 5px;
    }

    .city-faq-metabox input[type="text"],
    .city-faq-metabox textarea {
        margin-bottom: 10px;
    }
</style>

<script>
    jQuery(document).ready(function ($) {
        var faqIndex = <?= !empty($faqs) ? count($faqs) : 1; ?>;

        // Add new FAQ item
        $('#add-faq').on('click', function () {
            var newItem = $('.faq-item:first').clone();
            newItem.attr('data-index', faqIndex);
            newItem.find('input, textarea').val('');
            newItem.find('input').attr('id', 'faq_question_' + faqIndex);
            newItem.find('textarea').attr('id', 'faq_answer_' + faqIndex);

            // Update the name attributes with the new index
            newItem.find('input[name="faq_questions[]"]').attr('name', 'faq_questions[]');
            newItem.find('textarea[name="faq_answers[]"]').attr('name', 'faq_answers[]');

            newItem.find('.remove-faq').show();

            $('#faq-items').append(newItem);
            faqIndex++;
        });

        // Remove FAQ item
        $(document).on('click', '.remove-faq', function () {
            if ($('.faq-item').length > 1) {
                $(this).closest('.faq-item').remove();
            } else {
                $(this).closest('.faq-item').find('input, textarea').val('');
                $(this).hide();
            }
        });
    });
</script>