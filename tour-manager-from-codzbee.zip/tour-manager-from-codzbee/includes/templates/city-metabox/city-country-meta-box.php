<?php
/** includes/templates/city-metabox/city-country-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$city_country = get_post_meta($post->ID, '_city_country', true);

?>


<div>
    <input type="text" name="tm_city_country" id="tm_city_country" value="<?= esc_attr($city_country); ?>" style="width: 100%" />
</div>