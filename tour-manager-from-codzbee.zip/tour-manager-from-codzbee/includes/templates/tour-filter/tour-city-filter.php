<?php
// includes/helpers/tour-helpers.php

// Make sure this file is only loaded once
if (!function_exists('tm_get_tours_by_city')) :

/**
 * Get tour IDs that include a specific city
 */

function tm_get_tours_by_city($city_id) {
    // Bypass cache during debugging - remove when working
    // $tour_ids = false; 
    
    $cache_key = "tour-location{$city_id}";
    $tour_ids = get_transient($cache_key);
    
    if (false !== $tour_ids) {
        return $tour_ids;
    }
    
    $tour_ids = [];
    $all_tours = get_posts([
        'post_type' => 'tour',
        'posts_per_page' => -1,
        'fields' => 'ids',
        'post_status' => 'publish',
    ]);

foreach ($all_tours as $tour_id) {
    $itinerary = get_post_meta($tour_id, '_trip_itinerary', true);

    if (!empty($itinerary['days']) && is_array($itinerary['days'])) {
        foreach ($itinerary['days'] as $day) {
            if (!empty($day['cities']) && is_array($day['cities'])) {
                foreach ($day['cities'] as $city) {
                    if (!empty($city['city_id']) && (int)$city['city_id'] === (int)$city_id) {
                        $tour_ids[] = $tour_id;
                        break 2; 
                    }
                }
            }
        }
    }
}

    
    // Cache results for 12 hours
    set_transient($cache_key, $tour_ids, 12 * HOUR_IN_SECONDS);
    
    return $tour_ids;
}

/**
 * Clear city tour cache when tours are updated
 */
// function tm_clear_city_tour_cache($post_id) {
//     if ('tour' !== get_post_type($post_id)) return;
    
//     global $wpdb;
//     $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_tours_for_city_%'");
//     $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_timeout_tours_for_city_%'");
    

// }
// add_action('save_post', 'tm_clear_city_tour_cache');

endif; // function_exists