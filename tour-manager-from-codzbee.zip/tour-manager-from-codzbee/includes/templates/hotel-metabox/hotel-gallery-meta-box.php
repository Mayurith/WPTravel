<style>
    .hotel-meta-fields .form-field {
        margin-bottom: 15px;
    }

    .hotel-meta-fields label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .hotel-meta-fields select,
    .hotel-meta-fields textarea {
        width: 100%;
        max-width: 500px;
    }

    .hotel-meta-fields textarea {
        resize: vertical;
        min-height: 80px;
    }

    /* Gallery Styles */
    .hotel-gallery-metabox {
        margin: 15px 0;
    }

    .gallery-actions {
        margin-bottom: 15px;
    }

    .gallery-preview {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 15px;
    }

    .gallery-image {
        position: relative;
        width: 100px;
        height: 100px;
        border: 1px solid #ddd;
        border-radius: 3px;
        overflow: hidden;
    }

    .gallery-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .gallery-image .remove-image {
        position: absolute;
        top: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        color: white;
        width: 20px;
        height: 20px;
        text-align: center;
        line-height: 20px;
        cursor: pointer;
        font-size: 16px;
    }

    .gallery-image .remove-image:hover {
        background: #dc3232;
    }

    .no-images {
        color: #666;
        font-style: italic;
        margin: 10px 0;
    }
</style>

<div class="hotel-gallery-metabox">
    <input type="hidden" name="tm_hotel_gallery" id="tm_hotel_gallery"
        value="<?php echo esc_attr(implode(',', $gallery_ids)); ?>" />

    <div class="gallery-actions">
        <button type="button" class="button button-primary" id="hotel_gallery_upload">
            <?php _e('Add Gallery Images', 'text-domain'); ?>
        </button>
        <button type="button" class="button" id="hotel_gallery_remove_all">
            <?php _e('Remove All Images', 'text-domain'); ?>
        </button>
    </div>

    <div class="gallery-preview" id="hotel_gallery_preview">
        <?php if (!empty($gallery_ids)): ?>
            <?php foreach ($gallery_ids as $image_id): ?>
                <?php if ($image_url = wp_get_attachment_image_url($image_id, 'thumbnail')): ?>
                    <div class="gallery-image" data-image-id="<?php echo esc_attr($image_id); ?>">
                        <img src="<?php echo esc_url($image_url); ?>" alt="" />
                        <span class="remove-image">×</span>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-images"><?php _e('No gallery images selected.', 'text-domain'); ?></p>
        <?php endif; ?>
    </div>
</div>


<script>
    jQuery(document).ready(function ($) {
        // When country selection changes
        $('#tm_hotel_country').on('change', function () {
            var country = $(this).val();
            var citySelect = $('#tm_hotel_city');

            if (country) {
                // Show loading
                citySelect.html('<option value="">Loading cities...</option>');

                // AJAX request to get cities
                $.ajax({
                    url: hotel_manager.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'get_cities_by_country',
                        country: country,
                        nonce: hotel_manager.nonce
                    },
                    success: function (response) {
                        citySelect.html(response);
                    },
                    error: function () {
                        citySelect.html('<option value="">Error loading cities</option>');
                    }
                });
            } else {
                citySelect.html('<option value="">Select a Country First</option>');
            }
        });

        // Hotel gallery functionality
        var hotelGalleryFrame;
        var hotelGalleryIds = $('#tm_hotel_gallery').val() ? $('#tm_hotel_gallery').val().split(',') : [];

        // Open media frame for gallery
        $('#hotel_gallery_upload').on('click', function (e) {
            e.preventDefault();

            if (hotelGalleryFrame) {
                hotelGalleryFrame.open();
                return;
            }

            hotelGalleryFrame = wp.media({
                title: hotel_manager.title,
                button: {
                    text: hotel_manager.button_text
                },
                multiple: true,
                library: {
                    type: 'image'
                }
            });

            hotelGalleryFrame.on('select', function () {
                var attachments = hotelGalleryFrame.state().get('selection').toJSON();
                var galleryPreview = $('#hotel_gallery_preview');

                $.each(attachments, function (i, attachment) {
                    if ($.inArray(attachment.id.toString(), hotelGalleryIds) === -1) {
                        hotelGalleryIds.push(attachment.id.toString());

                        galleryPreview.append(
                            '<div class="gallery-image" data-image-id="' + attachment.id + '">' +
                            '<img src="' + attachment.sizes.thumbnail.url + '" alt="" />' +
                            '<span class="remove-image">×</span>' +
                            '</div>'
                        );
                    }
                });

                $('#tm_hotel_gallery').val(hotelGalleryIds.join(','));
                galleryPreview.find('.no-images').remove();
            });

            hotelGalleryFrame.open();
        });

        // Remove single image
        $(document).on('click', '.gallery-image .remove-image', function () {
            var imageDiv = $(this).closest('.gallery-image');
            var imageId = imageDiv.data('image-id').toString();

            hotelGalleryIds = hotelGalleryIds.filter(function (id) {
                return id !== imageId;
            });

            imageDiv.remove();
            $('#tm_hotel_gallery').val(hotelGalleryIds.join(','));

            if (hotelGalleryIds.length === 0) {
                $('#hotel_gallery_preview').append('<p class="no-images">' + hotel_manager.no_images + '</p>');
            }
        });

        // Remove all images
        $('#hotel_gallery_remove_all').on('click', function () {
            hotelGalleryIds = [];
            $('#tm_hotel_gallery').val('');
            $('#hotel_gallery_preview').html('<p class="no-images">' + hotel_manager.no_images + '</p>');
        });
    });
</script>