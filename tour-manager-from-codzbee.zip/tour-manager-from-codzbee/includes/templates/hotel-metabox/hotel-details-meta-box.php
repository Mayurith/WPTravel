<?php

?>

<style>
    .hotel-meta-fields {
        display: flex;
        gap: 100px;
        flex-wrap: wrap;
    }

    .form-fields {
        flex: 1;
        min-width: 300px;
    }

    .form-field {
        margin-bottom: 20px;
    }

    .form-field label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .form-field input[type="text"],
    .form-field input[type="url"],
    .form-field input[type="currency"],
    .form-field input[type="number"],

    .form-field select {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }
</style>

<div class="hotel-meta-fields">
    <div class="form-fields">
        <div class="form-field">
            <label for="tm_hotel_country">Country:</label>
            <select name="tm_hotel_country" id="tm_hotel_country" required>
                <option value="">Select a Country</option>
                <?php foreach ($countries as $country): ?>
                    <option value="<?= esc_attr($country); ?>" <?php selected($hotel_country, $country); ?>>
                        <?= esc_html($country); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-field">
            <label for="tm_hotel_city">City:</label>
            <select name="tm_hotel_city" id="tm_hotel_city" required>
                <option value="">Select a Country First</option>
                <?php if (!empty($cities)): ?>
                    <?php foreach ($cities as $city): ?>
                        <option value="<?= esc_attr($city->ID); ?>" <?php selected($hotel_city, $city->ID); ?>>
                            <?= esc_html($city->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </div>

        <div class="form-field">
            <label for="tm_hotel_location">Location:</label>
            <input type="text" name="tm_hotel_location" id="tm_hotel_location" placeholder="Westminster Borough, London"
                value="<?= esc_attr($hotel_location); ?>">
        </div>

        <div class="form-field">
            <label for="tm_hotel_top_badge">Top Badge:</label>
            <input type="text" name="tm_hotel_top_badge" id="tm_hotel_top_badge" placeholder="Breakfast Included"
                value="<?= esc_attr($hotel_top_badge); ?>">
        </div>
    </div>

    <div class="form-fields">
        <div class="form-field">
            <label for="tm_hotel_reviews">Reviews:</label>
            <input type="number" name="tm_hotel_reviews" id="tm_hotel_reviews" placeholder="3015"
                value="<?= esc_attr($hotel_reviews); ?>">
        </div>

        <div class="form-field">
            <label for="tm_hotel_start_rate">Start from:</label>
            <input type="text" name="tm_hotel_start_rate" id="tm_hotel_start_rate" placeholder="US$72"
                value="<?= esc_attr($hotel_start_rate); ?>">
        </div>

        <div class="form-field">
            <label for="tm_hotel_url">Hotel URL:</label>
            <input type="url" name="tm_hotel_url" id="tm_hotel_url" placeholder="https://www.example.com"
                value="<?= esc_url($hotel_url); ?>"> 
        </div>
    </div>
</div>


<script>
    jQuery(document).ready(function ($) {
        // When country selection changes
        $('#tm_hotel_country').on('change', function () {
            var country = $(this).val();
            var citySelect = $('#tm_hotel_city');

            if (country) {
                // Show loading
                citySelect.html('<option value="">Loading cities...</option>');

                // AJAX request to get cities
                $.ajax({
                    url: hotel_manager.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'get_cities_by_country',
                        country: country,
                        nonce: hotel_manager.nonce
                    },
                    success: function (response) {
                        citySelect.html(response);
                    },
                    error: function () {
                        citySelect.html('<option value="">Error loading cities</option>');
                    }
                });
            } else {
                citySelect.html('<option value="">Select a Country First</option>');
            }
        });
    });
</script>