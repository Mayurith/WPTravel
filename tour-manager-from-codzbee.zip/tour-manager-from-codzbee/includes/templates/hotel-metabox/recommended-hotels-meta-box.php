<?php
/** includes/templates/recommended-hotels-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$is_recommended = get_post_meta($post->ID, '_recommended_hotels', true);

?>


<div>
    <div><label for="tm_recommended_hotels">Select as recommended hotels</label></div>
    <div>
        <div>
            <input type="radio" id="tm_recommended_hotels_yes" name="tm_recommended_hotels" value="yes" <?php checked( $is_recommended, 'yes' ); ?> />
            <label for="tm_recommended_hotels_yes">Yes</label>
        </div>
        <div>
            <input type="radio" id="tm_recommended_hotels_no" name="tm_recommended_hotels" value="no" <?php checked( $is_recommended, 'no' ); ?> />
            <label for="tm_recommended_hotels_no">No</label>
        </div>
    </div>
</div>