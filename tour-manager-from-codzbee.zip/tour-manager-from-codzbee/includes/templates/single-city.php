<?php
/**
 * Single City Template
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

global $post;

/** Get the city post object */
$city = get_queried_object();

if ($city && $city->post_type === 'city') {
    setup_postdata($city);

    /** Get custom field data */
    $city_id = $city->ID;
    $city_title = get_the_title($city_id);
    $city_description = get_the_content();
    $city_excerpt = get_the_excerpt();
    $city_thumbnail = get_the_post_thumbnail($city_id, 'thumbnail_large');

    $city_country = get_post_meta($city_id, '_city_country', true);
    $city_population = get_post_meta($city_id, '_city_population', true);
    $city_property = get_post_meta($city_id, '_city_property', true);
    $city_subtitle = get_post_meta($city_id, '_city_subtitle', true);
    $city_gallery = get_post_meta($city_id, '_city_image_gallery', true);

    /** Convert gallery string to array */
    $gallery_image_ids = !empty($city_gallery) ? explode(',', $city_gallery) : [];

    $city_thumbnail_url = get_the_post_thumbnail_url($city_id, 'post-thumbnail');
    $default_bg = get_template_directory_uri() . '/assets/images/hero-bg-6.webp';
    $bg_image = $city_thumbnail_url ? $city_thumbnail_url : $default_bg;

    /** Prepare gallery data for JavaScript */
    $gallery_data = [];
    if (!empty($gallery_image_ids)) {
        foreach ($gallery_image_ids as $image_id) {
            $image_url = wp_get_attachment_url($image_id);
            $image_caption = wp_get_attachment_caption($image_id) ?: 'City Image';
            if ($image_url) {
                $gallery_data[] = [
                    'src' => $image_url,
                    'caption' => $image_caption
                ];
            }
        }
    }

    /** General info */
    $genral_info_title = get_post_meta($city_id, '_general_info_title', true);
    $genral_info_time_zone = get_post_meta($city_id, '_general_info_time_zone', true);
    $genral_info_sub_title = get_post_meta($city_id, '_general_info_sub_title', true);
    $genral_info_title_2 = get_post_meta($city_id, '_general_info_title_2', true);
    $genral_info_time_zone_2 = get_post_meta($city_id, '_general_info_time_zone_2', true);
    $genral_info_sub_title_2 = get_post_meta($city_id, '_general_info_sub_title_2', true);
    $genral_info_title_3 = get_post_meta($city_id, '_general_info_title_3', true);
    $genral_info_time_zone_3 = get_post_meta($city_id, '_general_info_time_zone_3', true);
    $genral_info_sub_title_3 = get_post_meta($city_id, '_general_info_sub_title_3', true);
    $genral_info_time_zone_4 = get_post_meta($city_id, '_general_info_time_zone_4', true);
    $genral_info_sub_title_4 = get_post_meta($city_id, '_general_info_sub_title_4', true);

    /** faqs */
    $faqs = get_post_meta($city_id, '_city_faqs', true);
    $faqs = is_array($faqs) ? $faqs : array();

    /** API key */
    $api_key = get_option('tm_google_map_api', get_bloginfo('map_api'));

    /** nearest destination */
    // $is_nearest = get_post_meta($city_id, '_is_nearest_destination', true);
    $city_latitude = get_post_meta($city_id, '_city_latitude', true);
    $city_longitude = get_post_meta($city_id, '_city_longitude', true);


    /**
     * Check if a tour itinerary contains a specific city
     * @param array $itinerary The tour itinerary data
     * @param string $city_name The city name to search for
     * @return bool
     */
    function tour_contains_city($itinerary, $city_name)
    {
        if (!is_array($itinerary)) {
            return false;
        }

        foreach ($itinerary as $day) {
            if (isset($day['cities']) && is_array($day['cities'])) {
                foreach ($day['cities'] as $city) {
                    if (isset($city['name']) && stripos($city['name'], $city_name) !== false) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /** Create a new WP_Query instance */
    $tours_query = new WP_Query($args);

    /** hotels */
    $args = array(
        'post_type' => 'hotel',
        'posts_per_page' => 8,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_recommended_hotels',
                'value' => 'yes',
                'compare' => '='
            ),
            array(
                'key' => '_hotel_city',
                'value' => $city_id,
                'compare' => '=',
            ),
        )
    );

    /** Create a new WP_Query instance */
    $hotels_query = new WP_Query($args);

    /** locations (Activity, Attraction) */
    $args = array(
        'post_type' => 'location',
        'posts_per_page' => 4,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                // 'key' => '_is_top_sight',
                'key' => '_is_top_sight',
                'value' => 'yes',
                'compare' => '=',
            ),
            array(
                'key' => '_location_city',
                'value' => $city_id,
                'compare' => '=',
            ),
        )
    );

    $location_query = new WP_Query($args);

    ?>


    <!-- page banner -->
    <section class="relative z-10 -mt-28 h-[350px] sm:h-[750px]">
        <div class="relative !h-[350px] sm:!h-[750px] bg-no-repeat bg-center bg-cover"
            style="background-image: url('<?= esc_url($bg_image); ?>');">
            <div class="single-city-header">
                <div class="single-city-header-title">Explore <?= esc_html($city_title); ?></div>
                <div class="single-city-header-subtitle"><?= $city_subtitle; ?></div>
                <div class="single-city-header-button">
                    <button type="button" id="see-photos-btn"
                        class="bg-white hover:bg-secondary text-black hover:text-white rounded-sm px-6 py-3 cursor-pointer mb-4">
                        See All Photos
                    </button>
                </div>
            </div>
        </div>
        <div class="absolute inset-0 bg-darkblue/40 z-5"></div>
    </section>


    <!-- city description with map -->
    <section class="container mx-auto mt-20 sm:px-24 px-4">
        <h3 class="text-primary text-3xl font-semibold mb-5 city-map-title">What to know before visiting
            <?= esc_html($city_title); ?>
        </h3>
        <div class="city-description-with-map">
            <!-- Left column: Description -->
            <div class="city-description">
                <?php
                // Function to limit words and preserve paragraph breaks
                function limit_words_with_paragraphs($string, $word_limit)
                {
                    // Split by paragraphs
                    $paragraphs = preg_split('/\r\n|\r|\n/', $string);
                    $output = '';
                    $words_counted = 0;
                    foreach ($paragraphs as $para) {
                        $words = preg_split('/\s+/', trim($para));
                        if (empty($para))
                            continue;
                        if ($words_counted + count($words) > $word_limit) {
                            $remaining = $word_limit - $words_counted;
                            $output .= '<p>' . implode(' ', array_slice($words, 0, $remaining)) . '...</p>';
                            break;
                        } else {
                            $output .= '<p>' . implode(' ', $words) . '</p>';
                            $words_counted += count($words);
                        }
                    }
                    return $output;
                }

                // Set word limit
                $word_limit = 130;
                $short_description = limit_words_with_paragraphs($city_description, $word_limit);
                $is_truncated = str_word_count(strip_tags($city_description)) > $word_limit;
                ?>
                <div class="text-15 text-dark-100">
                    <!-- Short and Full versions -->
                    <div id="shortDescription" class="transition-all duration-500"><?= $short_description; ?></div>
                    <div id="fullDescription" class="transition-all duration-500 hidden"><?= wpautop($city_description); ?>
                    </div>
                    <?php if ($is_truncated): ?>
                        <!-- Show button only if description is longer -->
                        <button id="toggleBtn" class="mt-4 text-secondary text-600 underline">Show More</button>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Right column: Map -->
            <div class="city-map">
                <?php
                // Query all locations for this city
                $argslocation = array(
                    'post_type' => 'location',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'meta_query' => array(
                        array(
                            'key' => '_location_city',
                            'value' => $city_id,
                            'compare' => '=',
                        ),
                    )
                );

                $location_map_query = new WP_Query($argslocation);

                // Prepare array of coordinates for JS
                $location_coords = [];
                if ($location_map_query->have_posts()):
                    while ($location_map_query->have_posts()):
                        $location_map_query->the_post();
                        $lat = get_post_meta(get_the_ID(), '_location_lat', true);
                        $lng = get_post_meta(get_the_ID(), '_location_lng', true);
                        $title = get_the_title();
                        if ($lat && $lng) {
                            $location_coords[] = [
                                'lat' => floatval($lat),
                                'lng' => floatval($lng),
                                'title' => $title,
                                'url' => get_permalink(),
                            ];
                        }
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
                <!-- map -->
                <div id="map" style="width: 100%; height: 250px;"></div>
                <script>
                    let map;
                    let markers = [];

                    function initLocationMap() {
                        // Get coordinates from PHP
                        const locations = <?= json_encode($location_coords); ?>;

                        // Default center: first location or fallback
                        let center = { lat: 37.7749, lng: -122.4194 };
                        if (locations.length > 0) {
                            // If only one location, center on it
                            if (locations.length === 1) {
                                center = { lat: locations[0].lat, lng: locations[0].lng };
                            } else {
                                // Calculate average lat/lng for all locations
                                let sumLat = 0, sumLng = 0;
                                locations.forEach(function (loc) {
                                    sumLat += loc.lat;
                                    sumLng += loc.lng;
                                });
                                center = {
                                    lat: sumLat / locations.length,
                                    lng: sumLng / locations.length
                                };
                            }
                        }

                        map = new google.maps.Map(document.getElementById('map'), {
                            center: center,
                            zoom: 7,
                            mapTypeControl: false,      // Hide map/satellite tabs
                            streetViewControl: false,   // Hide Pegman
                            fullscreenControl: true    // fullscreen button
                        });

                        // Add markers for each location with small icon
                        locations.forEach(function (loc) {
                            const marker = new google.maps.Marker({
                                position: { lat: loc.lat, lng: loc.lng },
                                map: map,
                                title: loc.title,
                                icon: {
                                    url: "https://maps.gstatic.com/mapfiles/api-3/images/spotlight-poi2_hdpi.png", // default Google marker
                                    scaledSize: new google.maps.Size(12, 20) // small size
                                }
                            });

                            // Info window
                            const infowindow = new google.maps.InfoWindow({
                                content: `<a href="${loc.url}" target="_blank">${loc.title}</a>`
                            });

                            marker.addListener('click', function () {
                                infowindow.open(map, marker);
                            });

                            markers.push(marker);
                        });
                    }
                </script>
                <!-- Google Maps Script with callback to initLocationMap -->
                <script src="https://maps.googleapis.com/maps/api/js?key=<?= $api_key ?>&callback=initLocationMap" async
                    defer></script>
            </div>
        </div>
    </section>

    <!-- General Info -->
    <section class="container mx-auto mt-20 sm:px-24 px-4">
        <?php if ($genral_info_title && $genral_info_time_zone && $genral_info_sub_title && $genral_info_title_2 && $genral_info_sub_title_2 && $genral_info_title_3 && $genral_info_sub_title_3): ?>
        <div class="border-t border-b border-gray-200 py-8">
            <h4 class="text-primary text-3xl font-medium mb-8 mt-5">General Info</h4>

            <!-- 3 columns layout -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10 mb-5">

                <!-- Column 1: Time Zone -->
                <div>
                    <div class="text-dark text-lg font-medium mb-1"><?= $genral_info_title; ?></div>
                    <div class="text-primary font-semibold"><?= $genral_info_time_zone; ?></div>
                    <div class="text-gray-500 text-sm mt-1"><?= $genral_info_sub_title; ?></div>
                </div>

                <!-- Column 2: Currency -->
                <div>
                    <div class="text-dark text-lg font-medium mb-1"><?= $genral_info_title_2; ?></div>
                    <div class="text-primary font-semibold"><?= $genral_info_sub_title_2; ?></div>
                    <div class="text-gray-500 text-sm mt-1"><?= $genral_info_time_zone_2; ?></div>
                </div>

                <!-- Column 3: Best time to visit -->
                <div>
                    <div class="text-dark text-lg font-medium mb-1"><?= $genral_info_title_3; ?></div>

                    <!-- Two columns inside this block -->
                    <div class="grid grid-cols-2 gap-x-4 mt-2">
                        <div>
                            <div class="text-primary font-semibold"><?= $genral_info_time_zone_3; ?></div>
                            <div class="text-gray-500 text-sm"><?= $genral_info_sub_title_3; ?></div>
                        </div>
                        <div>
                            <div class="text-primary font-semibold"><?= $genral_info_time_zone_4; ?></div>
                            <div class="text-gray-500 text-sm"><?= $genral_info_sub_title_4; ?></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php endif; ?>
    </section>

    <!-- recommended hotels -->
    <section class="container mx-auto mt-20 sm:px-24 px-3">
        <?php if ($hotels_query->have_posts()): ?>
        <div class="sm:flex justify-between mb-10">
            <div class="text-left">
                <h3 class="text-primary text-3xl font-semibold">
                    Recommended Hotels
                </h3>
                <p class="text-dark text-md mt-3">
                    Top-rated stays for comfort, convenience, and value.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-5 cursor-pointer overflow-hidden">
            <?php if ($hotels_query->have_posts()): ?>
                <?php while ($hotels_query->have_posts()):

                    $hotels_query->the_post();
                    // Get hotel URL for current hotel post
                    $hotel_url = get_post_meta(get_the_ID(), '_hotel_url', true);
                    ?>
                    <div class="relative rounded-lg !h-[400px] overflow-hidden">
                        <?php if (has_post_thumbnail()): ?>
                            <!-- Use the actual hotel URL -->
                            <a href="<?= esc_url($hotel_url ?: '#'); ?>" class="relative overflow-hidden block" aria-label="hotel"
                                <?= $hotel_url ? 'target="_blank"' : '' ?>>
                                <div class="w-full !h-[280px] bg-cover bg-no-repeat bg-center transform transition-transform duration-500 group-hover:scale-115"
                                    style="background-image: url('<?= the_post_thumbnail_url(); ?>')">
                                </div>
                                <div class="text-start sm:text-left lg:text-left">
                                    <div class="hotel-card-title text-primary text-md leading-[1.6rem] font-semibold mt-3">
                                        <?= get_the_title(); ?>
                                    </div>
                                </div>
                                <div class="text-dark text-sm mt-2">
                                    <?= $hotel_locations = get_post_meta($post->ID, '_hotel_location', true); ?>
                                </div>
                                <!-- hotel_reviews -->
                                <?php
                                $hotel_reviews = get_post_meta($post->ID, '_hotel_reviews', true);
                                if (!empty($hotel_reviews)):
                                    ?>
                                    <div class="text-dark text-sm mt-2">
                                        <?= $hotel_reviews = get_post_meta($post->ID, '_hotel_reviews', true); ?> reviews
                                    </div>
                                <?php endif; ?>
                                <!-- Start rate -->
                                <?php
                                $hotel_start_rate = get_post_meta($post->ID, '_hotel_start_rate', true);
                                if (!empty($hotel_start_rate)):
                                    ?>
                                    <div class="text-primary text-sm mt-2"> Starting from <span
                                            class="text-secondary text-xl font-meduim"><?= $hotel_start_rate = get_post_meta($post->ID, '_hotel_start_rate', true); ?></span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                        <!-- Top badge -->
                        <?php
                        $hotel_top_badge = get_post_meta($post->ID, '_hotel_top_badge', true);
                        if (!empty($hotel_top_badge)):
                            ?>
                            <div
                                class="absolute top-6 left-0 text-white text-xs uppercase py-2 px-4 bg-primary rounded-r-sm transition duration-300 z-10">
                                <?= esc_html($hotel_top_badge); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            <?php else: ?>
                <p>No hotels found.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </section>

    <!-- most popular tours -->
    <section class="container mx-auto mt-20 sm:px-24 px-4">
        <?php if ($tours_query->have_posts()): ?>
        <!-- header -->
        <div class="grid lg:grid-cols-2">
            <div class="order-md-2">
                <h3 class="text-primary text-3xl font-semibold">Most Popular Tours</h3>
                <div class="text-dark text-md mt-3 mb-4">Unforgettable experiences, handpicked for you.</div>
            </div>
            <div class="flex lg:justify-end order-md-1">
                <a href="/tour">
                    <button
                        class="flex items-center text-secondary bg-secondary/10 hover:text-white hover:bg-secondary py-2 px-8 rounded-sm cursor-pointer">
                        <div class="text-sm font-medium"><span class="ml-2">More</div>
                        <div class="text-3xl flex items-center">
                            <i class="lni lni-arrow-angular-top-right text-secondary ml-2"></i>
                        </div>
                    </button>
                </a>
            </div>
        </div>
        <!-- content -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-5 cursor-pointer overflow-hidden">
            <?php
            // Get all popular tours
            $args = array(
                'post_type' => 'tour',
                'posts_per_page' => -1, // Get all initially to filter
                'post_status' => 'publish',
                'meta_query' => array(
                    array(
                        'key' => '_tour_population',
                        'value' => 'yes',
                        'compare' => '='
                    )
                )
            );

            $all_tours_query = new WP_Query($args);
            $filtered_tours = array();

            if ($all_tours_query->have_posts()) {
                while ($all_tours_query->have_posts()) {
                    $all_tours_query->the_post();
                    $tour_id = get_the_ID();

                    // Check if this tour includes the current city in its itinerary
                    $itinerary = get_post_meta($tour_id, '_trip_itinerary', true);

                    // FIX: Remove $this-> and use the function directly
                    if (tour_contains_city($itinerary, $city_title)) {
                        $filtered_tours[] = $tour_id;
                    }
                }
                wp_reset_postdata();

                // Now query only the filtered tours (limit to 4)
                if (!empty($filtered_tours)) {
                    $filtered_args = array(
                        'post_type' => 'tour',
                        'posts_per_page' => 4,
                        'post_status' => 'publish',
                        'post__in' => $filtered_tours,
                        'orderby' => 'post__in'
                    );

                    $tours_query = new WP_Query($filtered_args);

                    if ($tours_query->have_posts()) {
                        while ($tours_query->have_posts()) {
                            $tours_query->the_post();
                            ?>
                            <div class="!h-[400px] rounded-sm group cursor-pointer overflow-hidden">
                                <div class="!h-[280px] relative rounded-sm overflow-hidden">
                                    <a href="<?php the_permalink(); ?>" class="block w-full h-full">
                                        <div class="w-full h-full bg-cover bg-no-repeat bg-center transform transition-transform duration-500 group-hover:scale-115"
                                            style="background-image: url('<?= the_post_thumbnail_url(); ?>')"></div>
                                    </a>
                                    <!-- Top Left Badge -->
                                    <?php
                                    $top_badge = get_post_meta($post->ID, '_tour_top_badge', true);
                                    if (!empty($top_badge)):
                                        ?>
                                        <div
                                            class="absolute top-6 left-0 text-white text-xs uppercase py-2 px-4 bg-primary rounded-r-sm transition duration-300 z-10">
                                            <?= esc_html($top_badge); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- content -->
                                <div class="text-start sm:text-left lg:text-left mt-3">
                                    <?php
                                    // FIX: Use consistent itinerary structure
                                    $itinerary = get_post_meta($post->ID, '_trip_itinerary', true);
                                    $total_days = is_array($itinerary) ? count($itinerary) : 0;
                                    $total_nights = max(0, $total_days - 1);
                                    $current_duration = $total_days ? "$total_nights Nights - $total_days Days" : 'Duration not specified';
                                    ?>
                                    <div class="text-dark text-sm"><?= $current_duration ?></div>
                                    <div class="hotel-card-title text-primary text-md leading-[1.6rem] font-semibold mt-3">
                                        <?= get_the_title(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        wp_reset_postdata();
                    } else {
                        echo '<p>No tours found for this city.</p>';
                    }
                } else {
                    echo '<p>No popular tours found for this city.</p>';
                }
            } else {
                echo '<p>No popular tours found.</p>';
            }
            ?>
        </div>
        <?php endif; ?>
    </section>

    <!-- top sights in city -->
    <section class="container mx-auto mt-20 mb-10 sm:px-24 px-4">
        <?php if ($location_query->have_posts()): ?>
        <!-- header -->
        <div class="top-sights-header text-start">
            <h3 class="text-primary text-left text-3xl font-semibold">Top sights in <?= esc_html($city_title); ?></h3>
            <div class="text-dark text-md mt-3">These popular destinations have a lot of offer</div>
        </div>
        <!-- content -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 mt-5 cursor-pointer overflow-hidden">
            <?php if ($location_query->have_posts()): ?>
                <?php while ($location_query->have_posts()):
                    $location_query->the_post(); ?>
                    <div class="border border-gray-200 rounded-md hover:shadow-lg transition-shadow duration-300 mt-4">
                        <div class="flex gap-8">
                            <!-- Left: Image (1/3 width) -->
                            <div class="" style="width: 200px; height: 200px;">
                                <?php if (has_post_thumbnail()): ?>
                                    <a href="<?= get_permalink(); ?>">
                                        <?= the_post_thumbnail('post-thumbnail', ['class' => 'w-full h-full object-cover']); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <!-- Right: Content (2/3 width) -->
                            <div class="w-2/3 overflow-y-auto">
                                <div class="text-lg font-semibold text-gray-800 mt-5 mb-3">
                                    <?= get_the_title(); ?>
                                </div>
                                <p class="text-dark text-sm pr-10 mb-3">
                                    <?php
                                    // Limit excerpt to 25 words
                                    $excerpt = get_the_excerpt();
                                    $words = explode(' ', $excerpt);
                                    $word_limit = 25;
                                    if (count($words) > $word_limit) {
                                        echo implode(' ', array_slice($words, 0, $word_limit)) . '...';
                                    } else {
                                        echo $excerpt;
                                    }
                                    ?>
                                </p>
                                <a href="<?= get_permalink(); ?>" class="text-secondary hover:underline text-sm font-medium">
                                    See More
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            <?php else: ?>
                <p>No locations found.</p>
            <?php endif; ?>
        </div>
        <!-- button -->
        <div class="flex justify-center mt-10">
            <a href="/location">
                <button
                    class="flex items-center text-secondary bg-secondary/10 hover:text-white hover:bg-secondary py-2 px-8 rounded-sm cursor-pointer">
                    <div class="text-sm font-medium"><span class="ml-2">Explore More</div>
                    <div class="text-3xl flex items-center">
                        <i class="lni lni-arrow-angular-top-right text-secondary ml-2"></i>
                    </div>
                </button>
            </a>
        </div>
        <?php endif; ?>
    </section>

    <!-- FAQs -->
    <section class="container mx-auto lg:mt-30 sm:mt-20 sm:px-24 px-4">
        <?php if (! empty($faqs)): ?>
        <div class="flex flex-col md:flex-row gap-8 md:gap-12 lg:gap-16">

            <!-- Left heading -->
            <div class="w-full md:w-1/4">
                <h3 class="text-primary text-2xl md:text-3xl font-medium mb-6 md:mb-0">
                    FAQs about <br>
                    <?= esc_html($city_title); ?>
                </h3>
            </div>

            <!-- Right content -->
            <div class="w-full md:w-3/4">
                <?php if (!empty($faqs)): ?>
                    <div class="space-y-4">
                        <?php foreach ($faqs as $index => $faq): ?>
                            <div class="border border-gray-200 rounded-md shadow-sm">
                                <button type="button"
                                    class="w-full flex items-center justify-between text-left text-gray-800 font-medium focus:outline-none py-4 px-5 md:px-8"
                                    onclick="toggleFaq('faq-<?= $index ?>')">
                                    <div class="flex items-center gap-2">
                                        <i id="icon-faq-<?= $index ?>"
                                            class="fa fa-plus transition-transform duration-300 text-primary bg-gray-200 rounded-full p-2 text-sm md:text-base"></i>
                                        <span class="text-base md:text-lg"><?= esc_html($faq['question']); ?></span>
                                    </div>
                                </button>
                                <div id="faq-<?= $index ?>"
                                    class="faq-answer text-dark text-sm md:text-base hidden px-5 md:px-12 py-2 mx-10">
                                    <?= esc_html($faq['answer']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </div>
        <?php endif; ?>
    </section>

    <!-- destinations near city -->
    <section class="container mx-auto lg:mt-20 mt-10 sm:px-24 px-4">
        <?php if (!empty($city_latitude) && !empty($city_longitude)): ?>
        <div>
            <h3 class="text-primary text-3xl font-semibold">Destinations near <?= esc_html($city_title); ?></h3>
            <div class="text-dark text-md mt-3">Explore nearby cities and popular destinations</div>
        </div>

        <!-- Destination Slider -->
        <div class="swiper-container destination-slider mt-10">
            <div class="swiper-wrapper">
                <?php
                // Get current city coordinates
                $current_city_lat = $city_latitude;
                $current_city_lng = $city_longitude;
                $current_city_id = $city_id;

                // Query all published "city" posts except the current city
                $args = array(
                    'post_type' => 'city',
                    'posts_per_page' => -1,
                    'post_status' => 'publish',
                    'post__not_in' => array($current_city_id),
                    'meta_query' => array(
                        'relation' => 'AND',
                        array(
                            'key' => '_city_latitude',
                            'compare' => 'EXISTS',
                        ),
                        array(
                            'key' => '_city_longitude',
                            'compare' => 'EXISTS',
                        )
                    )
                );

                $all_cities_query = new WP_Query($args);
                $nearby_cities = array();

                if ($all_cities_query->have_posts()):
                    while ($all_cities_query->have_posts()):
                        $all_cities_query->the_post();
                        $other_city_id = get_the_ID();

                        // Get other city coordinates
                        $other_city_lat = get_post_meta($other_city_id, '_city_latitude', true);
                        $other_city_lng = get_post_meta($other_city_id, '_city_longitude', true);

                        $city_property = get_post_meta($other_city_id, '_city_property', true);
                        // $is_nearest_other = get_post_meta($other_city_id, '_is_nearest_destination', true);
            
                        // Only process if coordinates exist
                        if (!empty($other_city_lat) && !empty($other_city_lng)) {
                            // Calculate distance
                            $distance = calculate_distance($current_city_lat, $current_city_lng, $other_city_lat, $other_city_lng, 'km');
                            $max_distance_km = 100;

                            // Add to nearby cities array with distance and nearest flag
                            // if ($distance <= $max_distance_km || $is_nearest_other === 'yes') {
                            if ($distance <= $max_distance_km) {
                                $nearby_cities[] = array(
                                    'id' => $other_city_id,
                                    'title' => get_the_title(),
                                    'thumbnail' => get_the_post_thumbnail_url($other_city_id, 'post-thumbnail'),
                                    'distance' => $distance,
                                    'property' => $city_property,
                                    // 'is_nearest' => $is_nearest_other === 'yes',
                                    'permalink' => get_permalink($other_city_id),
                                );
                            }
                        }
                    endwhile;

                    // usort($nearby_cities, function ($a, $b) {
                    //     if ($a['is_nearest'] && !$b['is_nearest'])
                    //         return -1;
                    //     if (!$a['is_nearest'] && $b['is_nearest'])
                    //         return 1;
                    //     return $a['distance'] - $b['distance'];
                    // });
            
                    $nearby_cities = array_slice($nearby_cities, 0, 10);

                    if (!empty($nearby_cities)):
                        foreach ($nearby_cities as $nearby_city):
                            // $badge_class = $nearby_city['is_nearest'] ? 'bg-secondary' : 'bg-primary';
                            // $badge_text = $nearby_city['is_nearest'] ? 'Nearest' : $nearby_city['distance'] . ' km';
                            ?>
                            <div class="swiper-slide" style="max-width: 170px; max-height: 270px; margin-right: 40px;">
                                <a href="<?= esc_url($nearby_city['permalink']); ?>" class="block h-full">
                                    <div class="destination-card flex flex-col relative h-full">
                                        <?php if ($nearby_city['thumbnail']): ?>
                                            <div class="flex items-center justify-center" style="height:170px;">
                                                <img src="<?= esc_url($nearby_city['thumbnail']); ?>"
                                                    alt="<?= esc_attr($nearby_city['title']); ?>"
                                                    class="object-cover w-full h-full aspect-square overflow-hidden rounded-md mb-2 bg-gray-100">
                                            </div>
                                        <?php else: ?>
                                            <div class="relative flex items-center justify-center bg-gray-200 overflow-hidden rounded-md mb-2 transform transition-transform duration-500 group-hover:scale-115"
                                                style="height:170px;">
                                                <img src="https://user-images.githubusercontent.com/20684618/31289519-9ebdbe1a-aae6-11e7-8f82-bf794fdd9d1a.png"
                                                    alt="No Image" class="object-cover w-full h-full aspect-square">
                                            </div>
                                        <?php endif; ?>

                                        <div class="text-xl font-normal"><?= esc_html($nearby_city['title']); ?></div>
                                        <!-- Display the city property -->
                                        <?php if (!empty($nearby_city['property'])): ?>
                                            <div class="text-dark text-sm"><?= esc_html($nearby_city['property']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                            <?php
                        endforeach;
                    else:
                        ?>
                        <div class="swiper-slide" style="width:150px; min-width:150px; max-width:150px;">
                            <div class="destination-card w-[150px] h-[150px] flex items-center justify-center">
                                <h4 class="text-xs">No nearby cities found.</h4>
                            </div>
                        </div>
                        <?php
                    endif;

                    wp_reset_postdata();
                else:
                    ?>
                    <div class="swiper-slide" style="width:150px; min-width:150px; max-width:150px;">
                        <div class="destination-card w-[150px] h-[150px] flex items-center justify-center">
                            <h4 class="text-xs">No other cities available.</h4>
                        </div>
                    </div>
                    <?php
                endif;
                ?>
            </div>

            <!-- Swiper Navigation -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-pagination"></div>
        </div>
        <?php endif; ?>
    </section>


    <!-- <div class="btn-container">
        <button id="see-photos-btn">See All Photos</button>
    </div>
    </div> -->

    <!-- Modal -->
    <div id="imageModal" class="modal">
        <span class="close">&times;</span>
        <div class="modal-navigation">
            <div class="modal-prev">&#10094;</div>
            <div class="modal-next">&#10095;</div>
        </div>
        <div class="modal-content">
            <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper modal-swiper">
                <div class="swiper-wrapper">
                    <?php foreach ($gallery_data as $image): ?>
                        <div class="swiper-slide">
                            <img src="<?php echo esc_url($image['src']); ?>" alt="">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="image-counter">
                <span id="current-slide">1</span> / <span id="total-slides"><?php echo count($gallery_data); ?></span>
            </div>
        </div>
        <div thumbsSlider="" class="swiper thumb-swiper">
            <div class="swiper-wrapper">
                <?php foreach ($gallery_data as $image): ?>
                    <div class="swiper-slide">
                        <img src="<?php echo esc_url($image['src']); ?>" alt="">
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Swiper JS -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script> -->

    <?php
    wp_reset_postdata();
} else {
    echo '<p>City not found.</p>';
}



/**
 * Calculate distance between two coordinates using Haversine formula
 * @param float $lat1 Latitude of first point
 * @param float $lon1 Longitude of first point
 * @param float $lat2 Latitude of second point
 * @param float $lon2 Longitude of second point
 * @param string $unit 'km' for kilometers, 'mi' for miles
 * @return float Distance in specified unit
 */
function calculate_distance($lat1, $lon1, $lat2, $lon2, $unit = 'km')
{
    $earth_radius = ($unit === 'mi') ? 3959 : 6371; // Radius in miles or kilometers

    $lat1 = floatval($lat1);
    $lon1 = floatval($lon1);
    $lat2 = floatval($lat2);
    $lon2 = floatval($lon2);

    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat / 2) * sin($dLat / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2) * sin($dLon / 2);

    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    $distance = $earth_radius * $c;

    return round($distance, 2);
}

get_footer();