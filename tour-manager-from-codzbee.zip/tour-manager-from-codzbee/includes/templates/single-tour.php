<?php
/** includes/templates/single-tour.php */

/**
 * Single Tour Template
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

global $post;

/** Get the tour post object */
$tour = get_queried_object();

if ($tour && $tour->post_type === 'tour') {
    setup_postdata($tour);

    /** get custom field data */
    $tour_id = $tour->ID;
    $tour_title = get_the_title($tour_id);
    $tour_slug = get_post_field('post_name', $tour_id);
    $tour_description = get_the_content();
    $tour_excerpt = get_the_excerpt();
    $tour_thumbnail = get_the_post_thumbnail($tour_id, 'thumbnail_large');
    $tour_thumbnail_url = get_the_post_thumbnail_url($tour_id, 'post-thumbnail');
    $default_bg = get_template_directory_uri() . '/assets/images/hero-bg-6.webp';
    $bg_image = $tour_thumbnail_url ? $tour_thumbnail_url : $default_bg;

    /** tour itinerary data */
    $itinerary = get_post_meta($tour_id, '_trip_itinerary', true);

    /** map key */
    $api_key = get_option('tm_google_map_api', get_bloginfo('map_api'));

    /** calculate duration for each tour */
    $total_days = !empty($itinerary) && is_array($itinerary) ? count($itinerary) : 0;
    $total_nights = max(0, $total_days - 1);
    $duration_days = $total_days ? "$total_nights Nights - $total_days Days" : 'Duration not specified';

    /** get available months for the tour */
    $available_months = get_post_meta($tour_id, '_available_months', true);
    $available_months = is_array($available_months) ? $available_months : array();

    /** guest data */
    $adult_min_count = get_post_meta($tour_id, '_adult_min_count', true);
    $adult_max_count = get_post_meta($tour_id, '_adult_max_count', true);
    $child_min_count = get_post_meta($tour_id, '_child_min_count', true);
    $child_max_count = get_post_meta($tour_id, '_child_max_count', true);

    $adult_rate = get_post_meta($tour_id, '_adult_rate', true);
    $child_rate = get_post_meta($tour_id, '_child_rate', true);

    /** tour guide data */
    $tour_guides = get_post_meta($tour_id, '_has_tour_guide', true);

    /** journey highlights data */
    $highlights = get_post_meta($tour_id, '_custom_highlights', true);

    /** faq data */
    $faqs = get_post_meta($tour_id, '_tour_faqs', true);
    $faqs = is_array($faqs) ? $faqs : array();

    /** get cities from the itinerary for the map */
    $all_cities = array();
    $city_coordinates = array();

    if (!empty($itinerary) && is_array($itinerary)) {
        foreach ($itinerary as $day) {
            if (!empty($day['cities'])) {
                foreach ($day['cities'] as $city_data) {
                    $city_name = esc_html($city_data['name']);

                    // Get city post by name to get coordinates
                    $city_post = get_page_by_title($city_name, OBJECT, 'city');

                    if ($city_post) {
                        $city_id = $city_post->ID;
                        $latitude = get_post_meta($city_id, '_city_latitude', true);
                        $longitude = get_post_meta($city_id, '_city_longitude', true);

                        if ($latitude && $longitude) {
                            $city_coordinates[$city_name] = array(
                                'lat' => floatval($latitude),
                                'lng' => floatval($longitude),
                                'id' => $city_id
                            );

                            // Add to all cities array for the route
                            if (!in_array($city_name, $all_cities)) {
                                $all_cities[] = $city_name;
                            }
                        }
                    }
                }
            }
        }
    }

    /** Get all activities and attractions */
    $all_activities_attractions = array();

    if (!empty($itinerary) && is_array($itinerary)) {
        foreach ($itinerary as $day_index => $day) {
            if (!empty($day['cities'])) {
                foreach ($day['cities'] as $city) {
                    // Process activities
                    if (!empty($city['activities'])) {
                        foreach ($city['activities'] as $activity_id) {
                            $activity_post = get_post($activity_id);
                            if ($activity_post && $activity_post->post_status === 'publish') {
                                $all_activities_attractions[] = array(
                                    'id' => $activity_id,
                                    'title' => $activity_post->post_title,
                                    'type' => 'activity',
                                    'city' => $city['name'],
                                    'day' => $day['day_number'],
                                    'country' => $day['country'],
                                    'thumbnail' => get_the_post_thumbnail_url($activity_id, 'post-thumbnail'),
                                    'excerpt' => $activity_post->post_excerpt,
                                    'permalink' => get_permalink($activity_id),
                                    'description' => $activity_post->post_content
                                );
                            }
                        }
                    }

                    // Process attractions
                    if (!empty($city['attractions'])) {
                        foreach ($city['attractions'] as $attraction_id) {
                            $attraction_post = get_post($attraction_id);
                            if ($attraction_post && $attraction_post->post_status === 'publish') {
                                $all_activities_attractions[] = array(
                                    'id' => $attraction_id,
                                    'title' => $attraction_post->post_title,
                                    'type' => 'attraction',
                                    'city' => $city['name'],
                                    'day' => $day['day_number'],
                                    'country' => $day['country'],
                                    'thumbnail' => get_the_post_thumbnail_url($attraction_id, 'post-thumbnail'),
                                    'excerpt' => $attraction_post->post_excerpt,
                                    'permalink' => get_permalink($attraction_id),
                                    'description' => $attraction_post->post_content
                                );
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * @var mixed $first_city_name
     */
    $first_city_name = '';

    if (!empty($itinerary) && is_array($itinerary)) {
        $first_day = reset($itinerary);
        if (!empty($first_day['cities']) && is_array($first_day['cities'])) {
            $first_city = reset($first_day['cities']);
            if (!empty($first_city['name'])) {
                $first_city_name = esc_html($first_city['name']);
            }
        }
    }


    /**
     * @var mixed $check_in_date
     */
    $check_in_date = isset($_POST['check-in-date']) ? sanitize_text_field($_POST['check-in-date']) : '';


}

?>

<!-- page banner -->
<section class="relative z-10 -mt-28 h-[850px]">
    <div class="relative h-[850px] bg-no-repeat bg-center bg-cover flex items-center justify-center"
        style="background-image: url('<?= esc_url($bg_image); ?>');">
        <!-- Overlay with fade-in animation -->
        <div class="absolute inset-0 bg-darkblue/40 z-5 opacity-0 animate-fadeIn"></div>
        <div class="relative text-center z-20 w-full">
            <h2 class="!text-white font-semibold"><?= esc_html($tour_title); ?></h2>
            <div class="!text-white mt-4 font-medium">Your Journey Starts Here</div>
        </div>
    </div>
</section>

<!-- description -->
<section class="container mx-auto mt-20 sm:px-24 px-4 lg:mt-20">
    <p class="tour-description flex text-justify"><?= wpautop($tour_description); ?></p>
</section>

<!-- Activity, Attraction container -->
<section class="container mx-auto mt-20 sm:px-24 px-4 lg:mt-20">
    <h3 class="text-primary text-3xl font-medium mb-5">Places You'll See</h3>

    <!-- Swiper Container -->
    <div class="swiper activity-attraction-carousel" id="activity-attraction-carousel">
        <div class="swiper-wrapper">
            <?php foreach ($all_activities_attractions as $activity_attraction): ?>
                <div class="swiper-slide">
                    <div class="activity-attraction-card">
                        <a href="<?= esc_url($activity_attraction['permalink']); ?>">
                            <img src="<?= esc_url($activity_attraction['thumbnail']); ?>"
                                alt="<?= esc_attr($activity_attraction['title']); ?>"
                                class="w-full h-64 object-cover rounded-sm">
                        </a>
                        <div class="activity-attraction-card-content">
                            <div class="text-md font-medium mt-3">
                                <a href="<?= esc_url($activity_attraction['permalink']); ?>">
                                    <?= esc_html($activity_attraction['title']); ?>
                                </a>
                            </div>
                            <div class="text-sm text-dark mb-2">
                                <?= esc_html($activity_attraction['city']); ?>,
                                <?= esc_html($activity_attraction['country']); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- map & tour overview -->
<section class="container mx-auto my-20 sm:px-24 px-3 ">
    <!-- <div> -->
    <div class="w-full grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2">

        <!-- Map -->
        <div class="md:px-10">
            <div id="tour-map" class="tm-google-map-route md:mr-20" style="width: 100%; height: 720px;"></div>
        </div>

        <!-- Tour Overview -->
        <div class="md:px-10">
            <div class="tour-overview p-6 rounded-lg shadow-sm space-y-6" style="border: #e5f2f2 1px solid;">

                <!-- Heading -->
                <div class="tour-overview-header">
                    <div class="tour-overview-header-title text-3xl font-medium mb-5 mx-3">TOUR OVERVIEW</div>
                    <table class="w-full text-sm" style="color: #051036;">
                        <tr class="border-b border-white">
                            <td class="py-2 font-medium">Duration</td>
                            <td class="py-2 text-right">
                                <?= $duration_days; ?>
                            </td>
                        </tr>
                        <tr class="border-b border-white">
                            <td class="py-2 font-medium">Group Size</td>
                            <td class="py-2 text-right">Min - <?= $adult_min_count; ?>A <?= $child_min_count; ?>C, Max -
                                <?= $adult_max_count; ?>A <?= $child_max_count; ?>C
                            </td>
                        </tr>
                        <tr class="border-b border-white">
                            <td class="py-2 font-medium">Start</td>
                            <td class="py-2 text-right"><?= $first_city_name ?></td>
                        </tr>
                        <tr>
                            <td class="py-2 font-medium">Tour Guide</td>
                            <td class="py-2 text-right">
                                <?= $tour_guides ? 'Guided tour available!' : 'Self-guided tour'; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- In the tour overview section -->
                <form method="POST" action="<?= esc_url(site_url("/tour/$tour_slug/book/")); ?>">
                    <input type="hidden" name="action" value="book_tour">
                    <input type="hidden" name="tour_id" value="<?= esc_attr($tour_id); ?>">
                    <input type="hidden" name="tour_name" value="<?= esc_attr($tour_slug); ?>">

                    <!-- arrival Date -->
                    <div class="tour-overview-arrival">
                        <label for="check-in-date" class="block font-medium mb-2">Arrival Date</label>
                        <input type="text" id="check-in-date" name="check-in-date"
                            class="w-full rounded-md p-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-secondary"
                            value="<?= esc_attr($check_in_date); ?>" required readonly />
                        <small class="text-sm text-gray-500 mt-1 block" id="date-validation-message"></small>

                        <!-- Available months info -->
                        <?php if (!empty($available_months)): ?>
                            <div class="text-sm text-secondary rounded">
                                <strong>Available Months:</strong> <?= esc_html(implode(', ', $available_months)); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Passengers -->
                    <div class="tour-overview-passengers space-y-4">
                        <!-- Adults -->
                        <div class="grid md:grid-cols-2 pass-adult-mobile">
                            <div>
                                <label for="adult" class="block font-medium" style="color: #051036;">Adults</label>
                                <small class="text-sm text-gray-500">(18+)</small>
                            </div>
                            <div style="text-align: right;">
                                <div class="passenger-counter">
                                    <button type="button"
                                        class="decrement-adult px-3 py-1 border border-secondary text-secondary rounded cursor-pointer hover:bg-secondary hover:text-white"
                                        data-type="adult">-</button>
                                    <input readonly type="text" id="adults" name="adults"
                                        value="<?= esc_attr($adult_min_count ?: 1); ?>"
                                        class="w-8 text-center border border-white rounded"
                                        data-min="<?= esc_attr($adult_min_count); ?>"
                                        data-max="<?= esc_attr($adult_max_count); ?>" />
                                    <button type="button"
                                        class="increment-adult px-3 py-1 border border-secondary text-secondary rounded cursor-pointer hover:bg-secondary hover:text-white">+</button>
                                </div>
                            </div>
                        </div>

                        <!-- Children -->
                        <div class="grid md:grid-cols-2 pass-child-mobile">
                            <div>
                                <label for="child" class="block font-medium" style="color: #051036;">Children</label>
                                <small class="text-sm text-gray-500">(0–17)</small>
                            </div>
                            <div style="text-align: right;">
                                <div class="passenger-counter">
                                    <button type="button"
                                        class="decrement-child px-3 py-1 border border-secondary text-secondary rounded cursor-pointer hover:bg-secondary hover:text-white">-</button>
                                    <input readonly type="text" id="children" name="children"
                                        value="<?= esc_attr($child_min_count ?: 0); ?>"
                                        class="w-8 text-center border border-white rounded"
                                        data-min="<?= esc_attr($child_min_count); ?>"
                                        data-max="<?= esc_attr($child_max_count); ?>" />
                                    <button type="button"
                                        class="increment-child px-3 py-1 border border-secondary text-secondary rounded cursor-pointer hover:bg-secondary hover:text-white">+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        document.addEventListener('DOMContentLoaded', function () {
                            /***************************************************
                             * Passenger Counter
                             ***************************************************/
                            const adultInput = document.getElementById('adults');
                            const childInput = document.getElementById('children');
                            const decrementAdultBtn = document.querySelector('.decrement-adult');
                            const incrementAdultBtn = document.querySelector('.increment-adult');
                            const decrementChildBtn = document.querySelector('.decrement-child');
                            const incrementChildBtn = document.querySelector('.increment-child');

                            if (adultInput && childInput) {
                                // Get min and max values from data attributes with fallbacks
                                const adultMin = parseInt(adultInput.getAttribute('data-min')) || 1;
                                const adultMax = parseInt(adultInput.getAttribute('data-max')) || 50;
                                const childMin = parseInt(childInput.getAttribute('data-min')) || 0;
                                const childMax = parseInt(childInput.getAttribute('data-max')) || 50;

                                // Initialize values
                                let adultCount = parseInt(adultInput.value) || adultMin;
                                let childCount = parseInt(childInput.value) || childMin;

                                // Update button states
                                function updateButtonStates() {
                                    // Adult buttons
                                    if (decrementAdultBtn) decrementAdultBtn.disabled = adultCount <= adultMin;
                                    if (incrementAdultBtn) incrementAdultBtn.disabled = adultCount >= adultMax;

                                    // Child buttons
                                    if (decrementChildBtn) decrementChildBtn.disabled = childCount <= childMin;
                                    if (incrementChildBtn) incrementChildBtn.disabled = childCount >= childMax;

                                    // Visual feedback for disabled buttons
                                    [decrementAdultBtn, incrementAdultBtn, decrementChildBtn, incrementChildBtn].forEach(btn => {
                                        if (btn) {
                                            if (btn.disabled) {
                                                btn.classList.add('opacity-50', 'cursor-not-allowed');
                                                btn.classList.remove('hover:bg-secondary', 'hover:text-white');
                                            } else {
                                                btn.classList.remove('opacity-50', 'cursor-not-allowed');
                                                btn.classList.add('hover:bg-secondary', 'hover:text-white');
                                            }
                                        }
                                    });
                                }

                                // Adult increment function
                                function incrementAdult() {
                                    if (adultCount < adultMax) {
                                        adultCount++;
                                        adultInput.value = adultCount;
                                        updateButtonStates();
                                    }
                                }

                                // Adult decrement function
                                function decrementAdult() {
                                    if (adultCount > adultMin) {
                                        adultCount--;
                                        adultInput.value = adultCount;
                                        updateButtonStates();
                                    }
                                }

                                // Child increment function
                                function incrementChild() {
                                    if (childCount < childMax) {
                                        childCount++;
                                        childInput.value = childCount;
                                        updateButtonStates();
                                    }
                                }

                                // Child decrement function
                                function decrementChild() {
                                    if (childCount > childMin) {
                                        childCount--;
                                        childInput.value = childCount;
                                        updateButtonStates();
                                    }
                                }

                                // Add event listeners with error handling
                                try {
                                    if (incrementAdultBtn) incrementAdultBtn.addEventListener('click', incrementAdult);
                                    if (decrementAdultBtn) decrementAdultBtn.addEventListener('click', decrementAdult);
                                    if (incrementChildBtn) incrementChildBtn.addEventListener('click', incrementChild);
                                    if (decrementChildBtn) decrementChildBtn.addEventListener('click', decrementChild);
                                } catch (error) {
                                    console.error('Error adding event listeners:', error);
                                }

                                // Initialize button states
                                updateButtonStates();
                            }

                            /***************************************************
                             * Disable entire months based on available months
                             ***************************************************/
                            const input = document.getElementById("check-in-date");
                            const msg = document.getElementById("date-validation-message");

                            if (input && typeof flatpickr !== "undefined") {

                                const availableMonths = <?= json_encode($available_months ?: []); ?>;
                                const totalDays = <?= $total_days ?: 0; ?>;

                                // Map month names → 0–11
                                const monthMap = {
                                    January: 0, February: 1, March: 2, April: 3, May: 4, June: 5,
                                    July: 6, August: 7, September: 8, October: 9, November: 10, December: 11
                                };
                                const allowedMonthNums = availableMonths.map(m => monthMap[m]);

                                // Flatpickr initialization
                                const fp = flatpickr("#check-in-date", {
                                    dateFormat: "Y-m-d",
                                    minDate: new Date().fp_incr(1),

                                    /** Disable ENTIRE MONTHS here */
                                    enable: [
                                        function (date) {
                                            return allowedMonthNums.includes(date.getMonth());
                                        }
                                    ],

                                    onChange: (selectedDates, dateStr) => {
                                        validate(dateStr);
                                    },
                                });

                                /** Simple validation on frontend */
                                function validate(dateStr) {
                                    if (!msg) return;
                                    msg.textContent = "";
                                    msg.className = "text-sm text-gray-500 mt-1 block";

                                    if (!dateStr) return false;

                                    const start = new Date(dateStr);
                                    const end = new Date(start);
                                    end.setDate(end.getDate() + totalDays - 1);

                                    if (!allowedMonthNums.includes(start.getMonth())) {
                                        msg.textContent = `This month is not available for this tour.`;
                                        msg.className = "text-sm text-red-600 mt-1 block";
                                        return false;
                                    }

                                    if (!allowedMonthNums.includes(end.getMonth())) {
                                        msg.textContent = `Departure (${end.toDateString()}) is outside available months.`;
                                        msg.className = "text-sm text-red-600 mt-1 block";
                                        return false;
                                    }

                                    return true;
                                }

                            }

                        });
                    </script>

                    <!-- Hidden total price field -->
                    <!-- <input type="hidden" id="total-price-hidden" name="total_price" value=""> -->

                    <!-- Tour Price -->
                    <div class="tour-overview-price mt-6 mb-4 justify-end">
                        <!-- <div class="text-md">Per Person Rate</div> -->
                        <div id="total-price-display"
                            class="text-2xl bg-secondary/10 rounded-md py-2 px-4 text-secondary">
                            USD <?= $adult_rate ?: 0.00; ?><span class="text-sm"> /per person</span></div>
                    </div>

                    <!-- Booking Button -->
                    <div class="tour-overview-booking">
                        <button type="submit"
                            class="bg-secondary text-white px-6 py-3 rounded-md hover:bg-primary transition-all w-full text-center font-semibold cursor-pointer">
                            Book Now
                        </button>
                    </div>
                </form>

                <script>
                    // Enhanced tour map data with better structure
                    var tourRouteData = {
                        days: <?= wp_json_encode($itinerary) ?>,
                        cities: <?= wp_json_encode($all_cities) ?>,
                        coords: <?= wp_json_encode($city_coordinates) ?>,
                        apiKey: '<?= $api_key ?>'
                    };

                    function initTourMap() {
                        if (!tourRouteData.coords || Object.keys(tourRouteData.coords).length === 0) {
                            console.warn('No city coordinates available');
                            document.getElementById('tour-map').innerHTML = '<div class="flex items-center justify-center h-full bg-gray-100 text-gray-500">Map data not available</div>';
                            return;
                        }

                        try {
                            var map = new google.maps.Map(document.getElementById('tour-map'), {
                                zoom: 12,
                                center: { lat: 7.8731, lng: 80.7718 }, // Default center (Sri Lanka)
                                mapTypeControl: true,
                                streetViewControl: false,
                                fullscreenControl: true,
                                styles: [
                                    {
                                        featureType: 'poi',
                                        elementType: 'labels',
                                        stylers: [{ visibility: 'on' }]
                                    }
                                ]
                            });

                            // Initialize directions service and renderer
                            var directionsService = new google.maps.DirectionsService();
                            var directionsRenderer = new google.maps.DirectionsRenderer({
                                suppressMarkers: false, // Keep default markers (A, B, C)
                                preserveViewport: false,
                                polylineOptions: {
                                    strokeColor: '#dc2626',
                                    strokeOpacity: 0.8,
                                    strokeWeight: 5
                                }
                            });
                            directionsRenderer.setMap(map);

                            // Store city information for custom info windows
                            var cityInfoData = [];
                            var markerCounter = 1;

                            // Process itinerary day by day to collect city information
                            tourRouteData.days.forEach(function (day, dayIndex) {
                                if (!day.cities || !Array.isArray(day.cities)) return;

                                day.cities.forEach(function (cityData) {
                                    var cityName = cityData.name;
                                    var cityCoord = tourRouteData.coords[cityName];

                                    if (cityCoord) {
                                        // Store city information with marker counter
                                        cityInfoData.push({
                                            position: new google.maps.LatLng(cityCoord.lat, cityCoord.lng),
                                            cityName: cityName,
                                            dayNumber: day.day_number,
                                            country: day.country || '',
                                            markerNumber: markerCounter
                                        });

                                        markerCounter++;
                                    }
                                });
                            });

                            // Calculate and draw route if we have enough points
                            if (cityInfoData.length >= 2) {
                                var origin = cityInfoData[0].position;
                                var destination = cityInfoData[cityInfoData.length - 1].position;

                                // Create waypoints (all positions except first and last)
                                var waypoints = [];
                                for (var i = 1; i < cityInfoData.length - 1; i++) {
                                    waypoints.push({
                                        location: cityInfoData[i].position,
                                        stopover: true
                                    });
                                }

                                var request = {
                                    origin: origin,
                                    destination: destination,
                                    waypoints: waypoints,
                                    travelMode: google.maps.TravelMode.DRIVING,
                                    optimizeWaypoints: false // Keep the original itinerary order
                                };

                                directionsService.route(request, function (response, status) {
                                    if (status === 'OK') {
                                        directionsRenderer.setDirections(response);

                                        // Customize the default markers with our info windows
                                        // customizeDefaultMarkers(response, map, cityInfoData);

                                        // Adjust map bounds to show the entire route with some padding
                                        var routeBounds = new google.maps.LatLngBounds();
                                        response.routes[0].legs.forEach(function (leg) {
                                            routeBounds.extend(leg.start_location);
                                            routeBounds.extend(leg.end_location);
                                        });
                                        map.fitBounds(routeBounds, { top: 50, right: 50, bottom: 50, left: 50 });

                                    } else {
                                        console.warn('Directions request failed:', status);
                                        // Fallback: use custom markers if directions fail
                                        createCustomMarkersAsFallback(map, cityInfoData);
                                    }
                                });
                            } else {
                                // Not enough points for a route, use custom markers
                                createCustomMarkersAsFallback(map, cityInfoData);
                            }

                            // Update legend to reflect the change
                            addMapLegend(map, cityInfoData.length);

                        } catch (error) {
                            console.error('Error initializing tour map:', error);
                            document.getElementById('tour-map').innerHTML = '<div class="flex items-center justify-center h-full bg-gray-100 text-gray-500">Error loading map</div>';
                        }
                    }

                    // Function to customize default Google Maps markers with our info windows
                    // function customizeDefaultMarkers(response, map, cityInfoData) {
                    //     // Get the default markers from the directions renderer
                    //     var routeMarkers = [];

                    //     // We'll create our own markers at the same positions but with custom info windows
                    //     // response.routes[0].legs.forEach(function (leg, legIndex) {
                    //     //     // Process start location (origin or waypoint)
                    //     //     var startMarkerInfo = findCityInfoByPosition(cityInfoData, leg.start_location);
                    //     //     if (startMarkerInfo) {
                    //     //         // createCustomInfoWindowForMarker(map, leg.start_location, startMarkerInfo);
                    //     //     }

                    //     //     // Process end location (destination or waypoint)
                    //     //     var endMarkerInfo = findCityInfoByPosition(cityInfoData, leg.end_location);
                    //     //     if (endMarkerInfo && legIndex === response.routes[0].legs.length - 1) { // Only for final destination
                    //     //         // createCustomInfoWindowForMarker(map, leg.end_location, endMarkerInfo);
                    //     //     }
                    //     // });
                    // }

                    // Function to find city information by position
                    function findCityInfoByPosition(cityInfoData, position) {
                        var lat = position.lat();
                        var lng = position.lng();

                        for (var i = 0; i < cityInfoData.length; i++) {
                            var city = cityInfoData[i];
                            if (Math.abs(city.position.lat() - lat) < 0.001 && Math.abs(city.position.lng() - lng) < 0.001) {
                                return city;
                            }
                        }
                        return null;
                    }

                    // // Function to create custom info windows for default markers
                    // function createCustomInfoWindowForMarker(map, position, cityInfo) {
                    //     var infoWindow = new google.maps.InfoWindow({
                    //         content: `

                    //         `
                    //     });

                    //     // Add click listener to the map to open info window when clicking near the marker position
                    //     google.maps.event.addListener(map, 'click', function (event) {
                    //         var distance = google.maps.geometry.spherical.computeDistanceBetween(
                    //             position,
                    //             event.latLng
                    //         );

                    //         // If click is within 50 meters of the marker position, show info window
                    //         if (distance < 50) {
                    //             infoWindow.setPosition(position);
                    //             infoWindow.open(map);
                    //         }
                    //     });
                    // }

                    // Fallback function to create custom markers when directions fail
                    function createCustomMarkersAsFallback(map, cityInfoData) {
                        var bounds = new google.maps.LatLngBounds();

                        cityInfoData.forEach(function (cityInfo) {
                            bounds.extend(cityInfo.position);

                            // Create marker with default Google Maps icon (no custom numbering)
                            var marker = new google.maps.Marker({
                                position: cityInfo.position,
                                map: map,
                                title: cityInfo.cityName,
                                icon: {
                                    url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
                                }
                            });

                            // Create custom info window
                            // var infoWindow = new google.maps.InfoWindow({
                            //     content: `

                            //     `
                            // });

                            // marker.addListener('click', function () {
                            //     infoWindow.open(map, marker);
                            // });
                        });

                        map.fitBounds(bounds, { top: 50, right: 50, bottom: 50, left: 50 });
                    }

                    // Fallback route drawing with straight lines
                    function drawFallbackRoute(map, cityPositions) {
                        if (cityPositions.length < 2) return;

                        var routePath = [];
                        cityPositions.forEach(function (city) {
                            routePath.push(city.position);
                        });

                        // Draw the complete route path
                        var completeRoute = new google.maps.Polyline({
                            path: routePath,
                            geodesic: true,
                            strokeColor: '#dc2626',
                            strokeOpacity: 0.6,
                            strokeWeight: 4
                        });
                        completeRoute.setMap(map);

                        // Also draw individual segments with arrows
                        for (var i = 0; i < cityPositions.length - 1; i++) {
                            var line = new google.maps.Polyline({
                                path: [cityPositions[i].position, cityPositions[i + 1].position],
                                geodesic: false,
                                strokeColor: '#dc2626',
                                strokeOpacity: 0.8,
                                strokeWeight: 3,
                                icons: [{
                                    icon: {
                                        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW
                                    },
                                    offset: '100%',
                                    repeat: '100px'
                                }]
                            });
                            line.setMap(map);
                        }
                    }

                    // Add legend to the map
                    function addMapLegend(map, totalStops) {
                        var legend = document.createElement('div');
                        legend.className = 'map-legend bg-white p-4 rounded-lg shadow-lg';
                        legend.innerHTML = `
                            <div class="text-sm font-semibold text-[#051036] mb-2">Tour Route</div>
                            <div class="flex items-center space-x-2 mb-2">
                                <div class="relative">
                                    <img src="https://maps.google.com/mapfiles/ms/icons/red-dot.png" alt="Marker" class="w-6 h-6">
                                </div>
                                <span class="text-xs text-gray-600">${totalStops} Tour Stops</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-1 bg-[#dc2626]"></div>
                                <span class="text-xs text-gray-600">Travel Route</span>
                            </div>
                            <div class="text-xs text-gray-500 mt-2">Click on markers for stop details</div>
                        `;

                        legend.style.margin = '10px';
                        legend.style.maxWidth = '200px';
                        map.controls[google.maps.ControlPosition.LEFT_TOP].push(legend);
                    }

                    // Handle Google Maps API loading errors
                    function gm_authFailure() {
                        console.error('Google Maps API failed to load');
                        document.getElementById('tour-map').innerHTML = `
                            <div class="flex flex-col items-center justify-center h-full bg-gray-100 text-gray-500 p-4 text-center">
                                <svg class="w-16 h-16 mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path>
                                </svg>
                                <h3 class="text-lg font-semibold mb-2">Map Unavailable</h3>
                                <p class="text-sm">We're unable to load the tour map at the moment.</p>
                            </div>
                        `;
                    }

                    // Load Google Maps API with error handling
                    function loadGoogleMaps() {
                        if (!tourRouteData.apiKey) {
                            console.error('Google Maps API key is missing');
                            gm_authFailure();
                            return;
                        }

                        var script = document.createElement('script');
                        script.src = `https://maps.googleapis.com/maps/api/js?key=${tourRouteData.apiKey}&callback=initTourMap&libraries=geometry,places`;
                        script.async = true;
                        script.defer = true;
                        script.onerror = gm_authFailure;
                        document.head.appendChild(script);
                    }

                    // Start loading the map when DOM is ready
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', loadGoogleMaps);
                    } else {
                        loadGoogleMaps();
                    }
                </script>

            </div>
        </div>

    </div>
    <!-- </div> -->
</section>

<!-- Tour Itinerary -->
<section class="container mx-auto mt-20 sm:px-24 px-4" id="tour-itinerary">
    <?php if (!empty($itinerary) && is_array($itinerary)): ?>
        <?php foreach ($itinerary as $day_index => $day): ?>
            <!-- Accordion Item: Day <?= $day['day_number']; ?> -->
            <div class="accordion-item mb-10 border border-gray-300 rounded-md overflow-hidden">
                <!-- Accordion Header -->
                <button
                    class="accordion-header bg-secondary text-white px-6 py-3 w-full flex justify-between items-center font-semibold focus:outline-none">
                    Day <?= $day['day_number']; ?> - <?= esc_html($day['country']); ?>
                    <i class="fa fa-angle-down transition-transform duration-300 rotate-180"></i>
                </button>

                <!-- Accordion Content -->
                <div class="accordion-content px-6 py-4 bg-white text-gray-700 mt-4">
                    <div class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-10">
                        <!-- left side -->
                        <div>
                            <!-- cities inside the day -->
                            <?php if (!empty($day['cities'])): ?>
                                <div class="font-semibold mb-2 text-xl">
                                    <?php
                                    $city_names = array();
                                    foreach ($day['cities'] as $city) {
                                        $city_names[] = esc_html($city['name']);
                                    }
                                    echo implode(', ', $city_names);
                                    ?>
                                </div>
                            <?php endif; ?>

                            <!-- day description -->
                            <?php if (!empty($day['description'])): ?>
                                <div class="prose max-w-none text-justify">
                                    <?php
                                    $word_limit = 70;
                                    $full_text = $day['description'];
                                    $words = explode(' ', $full_text);

                                    if (count($words) > $word_limit) {
                                        $truncated_text = implode(' ', array_slice($words, 0, $word_limit)) . '...';
                                        echo '<div id="description-' . $day_index . '-short">' . wpautop($truncated_text) . '</div>';
                                        echo '<div id="description-' . $day_index . '-full" class="hidden">' . wpautop($full_text) . '</div>';
                                        echo '<div class="text-right not-prose">';
                                        echo '<button onclick="toggleDescription(' . $day_index . ')" class="see-more-btn text-secondary cursor-pointer font-medium text-sm hover:underline">See More</button>';
                                        echo '</div>';
                                    } else {
                                        echo wpautop($full_text);
                                    }
                                    ?>
                                </div>
                            <?php endif; ?>

                        </div>
                        <!-- right side - Carousel -->
                        <div class="relative">
                            <?php
                            // Get all activities and attractions for this day
                            $all_locations = array();

                            foreach ($day['cities'] as $city) {
                                // Process activities
                                if (!empty($city['activities'])) {
                                    foreach ($city['activities'] as $activity_id) {
                                        $activity_post = get_post($activity_id);
                                        if ($activity_post && $activity_post->post_status === 'publish') {
                                            $all_locations[] = array(
                                                'id' => $activity_id,
                                                'title' => $activity_post->post_title,
                                                'type' => 'activity',
                                                'city' => $city['name'],
                                                'thumbnail' => get_the_post_thumbnail_url($activity_id, 'post-thumbnail'),
                                                'excerpt' => $activity_post->post_excerpt,
                                                'permalink' => get_permalink($activity_id)
                                            );
                                        }
                                    }
                                }

                                // Process attractions
                                if (!empty($city['attractions'])) {
                                    foreach ($city['attractions'] as $attraction_id) {
                                        $attraction_post = get_post($attraction_id);
                                        if ($attraction_post && $attraction_post->post_status === 'publish') {
                                            $all_locations[] = array(
                                                'id' => $attraction_id,
                                                'title' => $attraction_post->post_title,
                                                'type' => 'attraction',
                                                'city' => $city['name'],
                                                'thumbnail' => get_the_post_thumbnail_url($attraction_id, 'post-thumbnail'),
                                                'excerpt' => $attraction_post->post_excerpt,
                                                'permalink' => get_permalink($attraction_id)
                                            );
                                        }
                                    }
                                }
                            }
                            ?>

                            <?php if (!empty($all_locations)): ?>
                                <!-- Carousel Container -->
                                <div class="location-carousel relative overflow-hidden rounded-lg">
                                    <div class="carousel-track flex transition-transform duration-500 ease-in-out"
                                        id="carousel-track-<?= $day['day_number']; ?>">

                                        <?php foreach ($all_locations as $location): ?>
                                            <div class="carousel-slide min-w-full md:min-w-1/2 px-2">
                                                <div class="relative bg-white overflow-hidden">
                                                    <!-- Location Thumbnail -->
                                                    <div class="aspect-w-16 aspect-h-9 w-full !h-[64px] object-cover">
                                                        <img src="<?= $location['thumbnail'] ? esc_url($location['thumbnail']) : esc_url(get_template_directory_uri() . '/assets/images/placeholder.jpg'); ?>"
                                                            alt="<?= esc_attr($location['title']); ?>"
                                                            class="w-full !h-[64px] object-cover">
                                                    </div>

                                                    <!-- Location Content -->
                                                    <div class="p-4">
                                                        <!-- Location Title -->
                                                        <div class="mt-2 text-primary text-md font-medium">
                                                            <?= esc_html($location['title']); ?>
                                                        </div>

                                                        <!-- City -->
                                                        <div class="text-dark mb-3 text-sm">
                                                            <?= esc_html($location['city']); ?>
                                                        </div>

                                                        <!-- Explore Button -->
                                                        <a href="<?= esc_url($location['permalink']); ?>"
                                                            class="inline-block px-4 py-2 text-secondary text-sm bg-secondary/10 hover:text-white hover:bg-secondary rounded-sm transition-colors duration-200">
                                                            Explore more
                                                        </a>

                                                        <!-- Top Badge -->
                                                        <div
                                                            class="absolute top-3 right-3 px-3 py-1 text-white rounded-full text-xs font-medium 
                                                        <?= $location['type'] === 'activity' ? 'bg-primary' : 'bg-accent'; ?>">
                                                            <?= ucfirst($location['type']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>

                                    <!-- Carousel Navigation -->
                                    <?php if (count($all_locations) > 2): ?>
                                        <button
                                            class="carousel-prev absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full w-8 h-8 flex items-center justify-center shadow-md transition-all duration-200"
                                            data-carousel="carousel-track-<?= $day['day_number']; ?>">
                                            ‹
                                        </button>
                                        <button
                                            class="carousel-next absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 rounded-full w-8 h-8 flex items-center justify-center shadow-md transition-all duration-200"
                                            data-carousel="carousel-track-<?= $day['day_number']; ?>">
                                            ›
                                        </button>

                                        <!-- Carousel Indicators -->
                                        <div class="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex space-x-2">
                                            <?php
                                            $totalGroups = ceil(count($all_locations) / 2);
                                            for ($i = 0; $i < $totalGroups; $i++):
                                                ?>
                                                <button
                                                    class="carousel-indicator w-2 h-2 rounded-full bg-white/50 hover:bg-white transition-colors duration-200 <?= $i === 0 ? 'bg-white' : ''; ?>"
                                                    data-carousel="carousel-track-<?= $day['day_number']; ?>"
                                                    data-slide="<?= $i; ?>"></button>
                                            <?php endfor; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-8 text-gray-500">
                                    No activities or attractions added for this day.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Accommodation -->
                    <div class="mb-8">
                        <?php
                        // Check if we have any hotel data for this day
                        $has_hotel1 = !empty($day['hotel1_title']) || !empty($day['hotel1_rating']);
                        $has_hotel2 = !empty($day['hotel2_title']) || !empty($day['hotel2_rating']);
                        $has_accommodation = $has_hotel1 || $has_hotel2;
                        ?>

                        <?php if ($has_accommodation): ?>
                            <div>
                                <div class="font-semibold text-primary mb-2">Accommodation</div>
                                <div class="prose">You will stay in one of the following accommodations:</div>

                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <!-- Hotel 1 -->
                                    <?php if ($has_hotel1): ?>
                                        <div class="bg-secondary/10 p-3 rounded-sm mt-4">
                                            <!-- <div class="font-medium text-secondary mb-2">Hotel 1</div> -->

                                            <?php if (!empty($day['hotel1_title'])): ?>
                                                <div class="text-sm font-semibold text-gray-800 mb-2">
                                                    <?= esc_html($day['hotel1_title']); ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (!empty($day['hotel1_rating'])): ?>
                                                <div class="flex items-center space-x-1">
                                                    <div class="text-sm text-gray-600 mr-2">Rating:</div>
                                                    <div class="font-semibold text-yellow-400" style="color: #d48f0eff;">
                                                        <?= str_repeat('★', intval($day['hotel1_rating'])); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Hotel 2 -->
                                    <?php if ($has_hotel2): ?>
                                        <div class="bg-secondary/10 p-3 rounded-sm mt-4">
                                            <!-- <div class="font-medium text-secondary mb-2">Hotel 2</div> -->

                                            <?php if (!empty($day['hotel2_title'])): ?>
                                                <div class="text-sm font-semibold text-gray-800 mb-2">
                                                    <?= esc_html($day['hotel2_title']); ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (!empty($day['hotel2_rating'])): ?>
                                                <div class="flex items-center space-x-1">
                                                    <div class="text-sm text-gray-600 mr-2">Rating:</div>
                                                    <div class="font-semibold text-yellow-400" style="color: #d48f0eff;">
                                                        <?= str_repeat('★', intval($day['hotel2_rating'])); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Fallback for old data structure (backward compatibility) -->
                                <?php if (!$has_hotel1 && !$has_hotel2 && (!empty($day['accommodation_rating']) || !empty($day['hotel_title']))): ?>
                                    <div class="bg-white p-3 rounded-md border border-gray-200">
                                        <?php if (!empty($day['hotel_title'])): ?>
                                            <div class="text-sm font-semibold text-gray-800 mb-2">
                                                <?= esc_html($day['hotel_title']); ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($day['accommodation_rating'])): ?>
                                            <div class="flex items-center space-x-1">
                                                <div class="text-sm text-gray-600 mr-2">Rating:</div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="text-center py-8 text-gray-500">
            No itinerary data available for this tour.
        </div>
    <?php endif; ?>
</section>

<!-- Journey Highlights and FAQs -->
<section class="container mx-auto mt-20 sm:px-24 px-4" id="tour-itinerary">

    <?php if (!empty($highlights) || !empty($faqs)): ?>
        <div class="mx-auto grid grid-cols-1 md:grid-cols-2 gap-10">

            <?php if (!empty($highlights)): ?>
                <div class="journey-highlights">
                    <h3 class="text-primary text-3xl font-medium mb-5">Journey Highlights</h3>
                    <div class="prose prose-sm text-dark text-justify">
                        <?= wp_kses_post($highlights); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($faqs)): ?>
                <div>
                    <h3 class="text-primary text-3xl font-medium mb-5">FAQs</h3>

                    <div class="space-y-4">
                        <?php foreach ($faqs as $index => $faq): ?>
                            <div class="border border-gray-200 rounded-md px-1 shadow-sm">
                                <button type="button"
                                    class="w-full text-left flex items-center text-gray font-medium focus:outline-none py-2 px-10"
                                    onclick="toggleFaq('faq-<?= $index ?>')">
                                    <i class="fa fa-plus mr-5 p-3 rounded-full bg-gray-200 text-primary"></i>
                                    <span><?= esc_html($faq['question']); ?></span>
                                </button>

                                <div id="faq-<?= $index ?>" class="faq-answer text-dark text-base my-3 hidden px-20 py-3"
                                    style="margin-left: 1rem;">
                                    <?= esc_html($faq['answer']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                </div>
            <?php endif; ?>

        </div>
    <?php endif; ?>

</section>

<!-- What's Included and What's Not Included -->
<section class="container mx-auto mt-20 sm:px-24 px-4">

    <?php
    // Load meta values first (once)
    $whats_included = get_post_meta($post->ID, '_whats_included', true);
    $whats_included = is_array($whats_included) ? $whats_included : [];

    $included_notes = get_post_meta($post->ID, '_whats_included_notes', true);
    $included_notes = is_array($included_notes) ? $included_notes : [];

    $whats_not_included = get_post_meta($post->ID, '_whats_not_included', true);
    $whats_not_included = is_array($whats_not_included) ? $whats_not_included : [];

    $not_included_notes = get_post_meta($post->ID, '_whats_not_included_notes', true);
    $not_included_notes = is_array($not_included_notes) ? $not_included_notes : [];
    ?>

    <?php if (!empty($whats_included) || !empty($whats_not_included)): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-10">

            <!-- What's Included -->
            <?php if (!empty($whats_included)): ?>
                <div>
                    <h3 class="text-primary text-3xl font-medium mb-5">What's Included</h3>
                    <div class="prose prose-sm text-dark">

                        <?php foreach ($whats_included as $item): ?>
                            <?php
                            $note = $included_notes[$item] ?? '';
                            $has_note = !empty($note);
                            $accordion_id = 'included-' . sanitize_title($item);
                            ?>
                            <div class="accordion-item border border-gray-200 rounded-md mb-2">

                                <button
                                    class="accordion-button w-full flex justify-between items-center text-left px-2 py-1 rounded-sm font-medium text-secondary bg-secondary/10 <?= $has_note ? 'cursor-pointer' : 'cursor-default'; ?>"
                                    <?php if ($has_note): ?> onclick="toggleAccordion('<?= $accordion_id; ?>')"
                                        aria-expanded="false" <?php endif; ?>>
                                    <div class="flex items-center space-x-3">
                                        <svg class="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                                            <path
                                                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293z">
                                            </path>
                                        </svg>
                                        <span><?= esc_html($item); ?></span>
                                    </div>

                                    <?php if ($has_note): ?>
                                        <svg id="icon-<?= $accordion_id; ?>"
                                            class="w-4 h-4 text-secondary transform transition-transform" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24">
                                            <path d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                    <?php endif; ?>
                                </button>

                                <?php if ($has_note): ?>
                                    <div id="<?= $accordion_id; ?>" class="accordion-content hidden mt-2 pl-8 px-10">
                                        <p class="text-gray-600 text-sm"><?= wp_kses_post($note); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            <?php endif; ?>

            <!-- What's Not Included -->
            <?php if (!empty($whats_not_included)): ?>
                <div>
                    <h3 class="text-primary text-3xl font-medium mb-5">What's Not Included</h3>
                    <div class="prose prose-sm text-dark">

                        <?php foreach ($whats_not_included as $item): ?>
                            <?php
                            $note = $not_included_notes[$item] ?? '';
                            $has_note = !empty($note);
                            $accordion_id = 'not-included-' . sanitize_title($item);
                            ?>
                            <div class="accordion-item border border-gray-200 rounded-md mb-2">

                                <button
                                    class="accordion-button w-full flex justify-between items-center text-left px-2 py-1 rounded-sm font-medium text-secondary bg-secondary/10 <?= $has_note ? 'cursor-pointer' : 'cursor-default'; ?>"
                                    <?php if ($has_note): ?> onclick="toggleAccordion('<?= $accordion_id; ?>')"
                                        aria-expanded="false" <?php endif; ?>>
                                    <div class="flex items-center space-x-3">
                                        <svg class="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                                            <path
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z">
                                            </path>
                                        </svg>
                                        <span><?= esc_html($item); ?></span>
                                    </div>

                                    <?php if ($has_note): ?>
                                        <svg id="icon-<?= $accordion_id; ?>"
                                            class="w-4 h-4 text-secondary transform transition-transform" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24">
                                            <path d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                    <?php endif; ?>
                                </button>

                                <?php if ($has_note): ?>
                                    <div id="<?= $accordion_id; ?>" class="accordion-content hidden mt-2 pl-8 px-10">
                                        <p class="text-gray-600 text-sm"><?= wp_kses_post($note); ?></p>
                                    </div>
                                <?php endif; ?>

                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            <?php endif; ?>

        </div>
    <?php endif; ?>

</section>

<!-- Inquiry now Button -->
<section class="container mx-auto mt-20 sm:px-24 px-4 py-16 bg-[#e5f2f2]">
    <div class="text-center space-y-4">
        <h2 class="text-3xl sm:text-4xl font-medium text-[#051036]">
            Make Your Journey Uniquely Yours
        </h2>
        <div class="text-md text-[#051036]">
            Have something special in mind?<br />
            Contact us to customize your tour today!
        </div>
        <button
            class="mt-6 px-6 py-2 text-secondary bg-secondary/10 hover:text-white hover:bg-secondary rounded-sm transition-colors duration-200">
            <a href="<?= get_permalink(get_page_by_path('/inquiry')); ?>">Inquire Now</a>
        </button>
    </div>
</section>

<!-- Cancellation Policy -->
<section class="container mx-auto mt-20 sm:px-24 px-4">
    <?php if ( !empty(get_post_meta(get_the_ID(), '_cancellation_policy', true)) ?: ''): ?>
    <div class="bg-lightblue rounded-md px-6 py-6">
        <div class="text-primary font-semibold text-3xl">Your Peace of Mind Options</div>
        <div class="text-primary font-medium text-lg mt-3">Cancellation Policy</div>
        <div class="text-dark mb-5">A Transparent Overview of Applicable fees.</div>
        <button
            class="bg-white px-3 py-2 rounded-md text-secondary font-medium cursor-pointer hover:bg-secondary hover:text-white"
            id="cancellation-policy" data-post-id="<?= get_the_ID(); ?>">Explore your options</button>
    </div>
    <?php endif; ?>
</section>

<!-- Cancellation policy : Modal Overlay -->
<div class="fixed inset-0 z-50 flex items-center justify-center modal-overlay hidden" id="modal-overlay">
    <!-- Modal Content -->
    <div class="bg-white rounded-lg shadow-xl mx-4 px-4 py-4 w-full max-w-2xl modal-content flex flex-col">
        <!-- Modal Header -->
        <div class="px-6 py-4 flex-shrink-0 relative">
            <div class="text-2xl font-semibold text-secondary text-center">Cancellation Policy</div>
            <button class="absolute top-0 right-0 py-2 px-2 text-secondary cursor-pointer" id="close-modal">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <?php
        // In your template file where the modal is outputted
        $cancellation_policy = get_post_meta(get_the_ID(), '_cancellation_policy', true);
        ?>

        <!-- Modal Body -->
        <div class="px-6 py-4 overflow-y-auto flex-grow">
            <?php if ($cancellation_policy): ?>
                <div class="prose max-w-none">
                    <?= wpautop($cancellation_policy); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php get_footer(); ?>