<?php
/** includes/templates/location-coordinates-metabox.php */

/** This template is used to display the location details. */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

?>

<div class="location-coordinates">
    <div class="form-field">
        <label for="location_search"><?php _e('Search Location:', 'tour-manager'); ?></label>
        <input type="text" name="location_search" id="location_search"
            value="<?= esc_attr(get_post_meta($post->ID, '_location_address', true)); ?>" class="widefat"
            placeholder="<?php _e('Search for a location...', 'tour-manager'); ?>">
    </div>

    <div class="form-field">
        <label for="location_lat"><?php _e('Latitude', 'tour-manager'); ?></label>
        <input type="text" name="location_lat" id="location_lat" value="<?= esc_attr($lat); ?>" class="widefat"
            readonly>
    </div>

    <div class="form-field">
        <label for="location_lng"><?php _e('Longitude', 'tour-manager'); ?></label>
        <input type="text" name="location_lng" id="location_lng" value="<?= esc_attr($lng); ?>" class="widefat"
            readonly>
    </div>

    <div id="location_map"
        style="height: 200px; width: 100%; margin-top: 10px;<?= empty($lat) ? ' display:none;' : '' ?>"></div>

    <!-- Hidden fields for storing data -->
    <input type="hidden" name="location_place_id" id="location_place_id"
        value="<?= esc_attr(get_post_meta($post->ID, '_location_place_id', true)); ?>">
</div>