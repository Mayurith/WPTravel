<?php
/** includes/templates/tour-metabox/city-page-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$is_popular = get_post_meta($post->ID, '_tour_population', true);
$top_badge = get_post_meta($post->ID, '_tour_top_badge', true);

?>

<!-- Popular tour -->

<?php wp_nonce_field('save_tour_data', 'tour_meta_nonce'); ?>

<div style="display: flex; gap: 20px; margin-top: 20px;">
    <div>
        <input type="radio" id="tm_tour_population_yes" name="tm_tour_population" value="yes" <?php checked($is_popular, 'yes'); ?> />
        <label for="tm_tour_population_yes">Yes</label>
    </div>
    <div>
        <input type="radio" id="tm_tour_population_no" name="tm_tour_population" value="no" <?php checked($is_popular, 'no'); ?> />
        <label for="tm_tour_population_no">No</label>
    </div>
</div>


<!-- Top Badge -->
<div style="margin-top: 10px;">
    <div style="margin-bottom: 5px;"><label for="tm_tour_top_badge">Top Badge</label></div>
    <div>
        <input type="text" id="tm_tour_top_badge" name="tm_tour_top_badge"
            value="<?= esc_attr(get_post_meta($post->ID, '_tour_top_badge', true)); ?>" placeholder="E.g., Top Rated"
            style="width: 100%;" />
    </div>

    <small style="font-style: italic; color: #858383; margin-top: 20px;">These information are displayed in the "Most Popular Tour" section
        on the single city page.</small>

</div>