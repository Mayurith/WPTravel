<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get existing not included items and notes
$whats_not_included = get_post_meta($post->ID, '_whats_not_included', true);
$whats_not_included = is_array($whats_not_included) ? $whats_not_included : array();

$not_included_notes = get_post_meta($post->ID, '_whats_not_included_notes', true);
$not_included_notes = is_array($not_included_notes) ? $not_included_notes : array();
?>

<?php wp_nonce_field('save_tour_data', 'tour_meta_nonce'); ?>

<div>
    <label for="tour_not_includes"><strong>Select What's NOT Included in this tour</strong></label>
    <div class="not-include-selection">
        <?php
        $not_included_options = array(
            'Accommodation',
            'Meals',
            'Transport',
            'Guide',
            'Additional Services',
            'Flights',
            'Insurance',
            'Optional'
        );

        foreach ($not_included_options as $index => $not_include):
            $checked = in_array($not_include, $whats_not_included) ? 'checked' : '';
            $textarea_id = 'textareanot_' . $index;
            $note_value = isset($not_included_notes[$not_include]) ? $not_included_notes[$not_include] : '';
            ?>
            <div class="not-include-item">
                <label>
                    <input 
                        type="checkbox" 
                        name="whats_not_included[]" 
                        value="<?= esc_attr($not_include); ?>" 
                        data-textarea-id="<?= $textarea_id; ?>"
                        <?= $checked; ?>
                    >
                    <?= esc_html($not_include); ?>
                </label>
                <textarea 
                    id="<?= $textarea_id; ?>" 
                    name="whats_not_included_notes[<?= esc_attr($not_include); ?>]" 
                    placeholder="Enter details for <?= esc_attr($not_include); ?>" 
                    style="display: <?= $checked ? 'block' : 'none'; ?>;"
                ><?= esc_textarea($note_value); ?></textarea>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .not-include-selection {
        display: flex;
        flex-direction: column;
        margin: 10px 0;
    }
    .not-include-item {
        margin-bottom: 10px;
    }
    .not-include-selection textarea {
        margin: 5px 0 0 20px;
        padding: 6px;
        width: 95%;
        resize: vertical;
        min-height: 60px;
        font-size: 14px;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkboxes = document.querySelectorAll('.not-include-selection input[type="checkbox"]');
        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('change', function () {
                const textareaId = checkbox.getAttribute('data-textarea-id');
                const textarea = document.getElementById(textareaId);
                if (textarea) {
                    textarea.style.display = checkbox.checked ? 'block' : 'none';
                }
            });
        });
    });
</script>