<?php

if (!defined('ABSPATH')) {
    exit;
}

$has_guide = get_post_meta($post->ID, '_has_tour_guide', true);

?>

<?php wp_nonce_field('save_tour_data', 'tour_meta_nonce'); ?>
<div class="tour-guide-meta">
    <div>This tour has a Guide</div>
    <div>
        <label>
            <input type="radio" name="has_tour_guide" value="1" <?php checked($has_guide, '1'); ?> />
            Yes
        </label>
    </div>
    <div>
        <label>
            <input type="radio" name="has_tour_guide" value="0" <?php checked($has_guide, '0'); ?> />
            No
        </label>
    </div>
</div>