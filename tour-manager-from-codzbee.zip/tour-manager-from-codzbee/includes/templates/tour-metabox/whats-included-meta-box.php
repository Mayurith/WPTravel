<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div>
    <label for="tour_includes"><strong>Select What's Included in this tour</strong></label>
    <div class="include-selection">
        <?php
        $included_options = array(
            'Accommodation',
            'Meals',
            'Transport',
            'Guide',
            'Additional Services',
            'Flights',
            'Insurance',
            'Optional'
        );

        foreach ($included_options as $index => $include):
            $checked = in_array($include, $whats_included) ? 'checked' : '';
            $textarea_id = 'textarea_' . $index;
            $note_value = isset($included_notes[$include]) ? $included_notes[$include] : '';
            ?>
            <div class="include-item">
                <label>
                    <input 
                        type="checkbox" 
                        name="whats_included[]" 
                        value="<?= esc_attr($include); ?>" 
                        data-textarea-id="<?= $textarea_id; ?>"
                        <?= $checked; ?>
                    >
                    <?= esc_html($include); ?>
                </label>
                <textarea 
                    id="<?= $textarea_id; ?>" 
                    name="whats_included_notes[<?= esc_attr($include); ?>]" 
                    placeholder="Enter details for <?= esc_attr($include); ?>" 
                    style="display: <?= $checked ? 'block' : 'none'; ?>;"
                ><?= esc_textarea($note_value); ?></textarea>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .include-selection {
        display: flex;
        flex-direction: column;
        margin: 10px 0;
    }
    .include-item {
        margin-bottom: 10px;
    }
    .include-selection textarea {
        margin: 5px 0 0 20px;
        padding: 6px;
        width: 95%;
        resize: vertical;
        min-height: 60px;
        font-size: 14px;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkboxes = document.querySelectorAll('.include-selection input[type="checkbox"]');
        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('change', function () {
                const textareaId = checkbox.getAttribute('data-textarea-id');
                const textarea = document.getElementById(textareaId);
                if (textarea) {
                    textarea.style.display = checkbox.checked ? 'block' : 'none';
                }
            });
        });
    });
</script>