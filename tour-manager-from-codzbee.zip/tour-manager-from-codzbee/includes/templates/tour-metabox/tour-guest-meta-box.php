<?php
if (!defined('ABSPATH')) {
    exit;
}

$adult_max_count = get_post_meta($post->ID, '_adult_max_count', true);
$adult_min_count = get_post_meta($post->ID, '_adult_min_count', true);
$adult_rate = get_post_meta($post->ID, '_adult_rate', true);
$child_max_count = get_post_meta($post->ID, '_child_max_count', true);
$child_min_count = get_post_meta($post->ID, '_child_min_count', true);
$child_rate = get_post_meta($post->ID, '_child_rate', true);
$sl_meta_box_sidebar = get_post_meta($post->ID, '_tm-meta-box-sidebar', true);

// Get existing available months
$available_months = get_post_meta($post->ID, '_available_months', true);
$available_months = is_array($available_months) ? $available_months : array();

wp_nonce_field('save_tour_data', 'tour_meta_nonce');
?>

<div class="tour-meta-box">
    <div class="guest-fields">
        <div class="field-group">
            <label for="adult_min_count">Min Adults</label>
            <input type="number" id="adult_min_count" name="adult_min_count" value="<?= esc_attr($adult_min_count); ?>"
                min="0" step="1">
        </div>

        <div class="field-group">
            <label for="adult_max_count">Max Adults</label>
            <input type="number" id="adult_max_count" name="adult_max_count" value="<?= esc_attr($adult_max_count); ?>"
                min="0" step="1">
        </div>

        <div class="field-group">
            <label for="adult-rate-field">Rate (USD)</label>
            <input type="number" id="adult-rate-field" name="adult_rate" value="<?= esc_attr($adult_rate); ?>"
                min="1.50" step="0.01" placeholder="e.g., 199.99">
            <small style="font-style: italic; color: #858383;">Enter per person rate (e.g., 199.99)</small>
        </div>
    </div>

    <div class="guest-fields">
        <div class="field-group">
            <label for="child_min_count">Min Children</label>
            <input type="number" id="child_min_count" name="child_min_count" value="<?= esc_attr($child_min_count); ?>"
                min="0" max="100" step="1">
        </div>

        <div class="field-group">
            <label for="child_max_count">Max Children</label>
            <input type="number" id="child_max_count" name="child_max_count" value="<?= esc_attr($child_max_count); ?>"
                min="0" max="100" step="1">
        </div>

        <div class="field-group">
            <label for="child_rate">Rate (USD)</label>
            <input type="number" id="child_rate" name="child_rate" value="<?= esc_attr($child_rate); ?>" min="1.50"
                step="0.01" placeholder="e.g., 99.99" disabled>
            <small style="font-style: italic; color: #858383;">Enter per person rate (e.g., 99.99)</small>
        </div>
    </div>

    <!-- Multiple Month Picker -->
    <div>
        <label for="month-picker">Select the months this tour is available</label>
        <div class="month-picker">
            <?php
            $months = array(
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
            );
            
            foreach ($months as $month): 
                $checked = in_array($month, $available_months) ? 'checked' : '';
            ?>
                <label>
                    <input type="checkbox" name="available_months[]" value="<?= esc_attr($month); ?>" <?= $checked; ?>>
                    <?= esc_html($month); ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<style>
    .month-picker {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        max-width: 400px;
        margin-top: 10px;
    }

    .month-picker label {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background: #f8f8f8;
        cursor: pointer;
        transition: all 0.2s;
    }

    .month-picker label:hover {
        background: #e8e8e8;
    }

    .month-picker input[type="checkbox"]:checked + span {
        font-weight: bold;
        color: #007cba;
    }

    .month-picker input[type="checkbox"] {
        margin: 0;
    }
</style>