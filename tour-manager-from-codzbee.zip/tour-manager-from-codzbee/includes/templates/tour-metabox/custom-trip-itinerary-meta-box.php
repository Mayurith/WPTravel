<?php
// includes/templates/tour-metabox/custom-trip-itinerary-meta-box.php

if (!defined('ABSPATH')) {
    exit;
}

/** Fetch custom post type: 'location' */
$locations = get_posts([
    'post_type' => 'location',
    'posts_per_page' => -1,
    'post_status' => 'publish',
]);

$locations_data = [];

foreach ($locations as $location) {
    // Get the city ID from post meta
    $city_id = get_post_meta($location->ID, '_location_city', true);

    // Get the city name from the city post
    $city_name = '';
    if ($city_id) {
        $city_post = get_post($city_id);
        if ($city_post) {
            $city_name = $city_post->post_title;
        }
    }

    $locations_data[] = [
        'id' => $location->ID,
        'title' => $location->post_title,
        'country' => get_post_meta($location->ID, '_location_country', true),
        'city' => $city_name,
        'city_id' => $city_id,
        'type' => get_post_meta($location->ID, '_location_type', true),
    ];
}

/**
 * Fetch custom post type: 'hotel'
 */
$hotels = get_posts([
    'post_type' => 'hotel',
    'posts_per_page' => -1,
    'post_status' => 'publish',
]);

// Prepare hotels data with additional meta if needed
$hotels_data = [];
foreach ($hotels as $hotel) {
    $hotels_data[] = [
        'id' => $hotel->ID,
        'title' => $hotel->post_title,
        'location' => get_post_meta($hotel->ID, '_hotel_location', true),
        'rating' => get_post_meta($hotel->ID, '_hotel_rating', true),
    ];
}

// Get existing itinerary data
$itinerary = get_post_meta($post->ID, '_trip_itinerary', true);
$itinerary = is_array($itinerary) ? $itinerary : [];

?>

<div id="trip-itinerary-container" style="margin-top: 20px;">
    <?php if (!empty($itinerary)): ?>
        <?php foreach ($itinerary as $day_index => $day): ?>
            <div class="itinerary-day" id="day_<?= $day_index + 1; ?>">
                <div class="day-header">
                    <h3 class="day-title">Day <?= $day_index + 1; ?></h3>
                    <button type="button" class="remove-day" data-day-index="<?= $day_index; ?>">Remove Day</button>
                </div>

                <div class="form-section">
                    <div class="section-title">Destination</div>
                    <label for="day_<?= $day_index + 1; ?>_country">Country:</label>
                    <select name="itinerary[<?= $day_index; ?>][country]" class="country-select" required>
                        <option value="">-- Select Country --</option>
                        <?php
                        $countries = array_unique(array_column($locations_data, 'country'));
                        sort($countries);
                        foreach ($countries as $country):
                            if (empty($country)) continue;
                            ?>
                            <option value="<?= esc_attr($country); ?>" <?php selected($day['country'] ?? '', $country); ?>>
                                <?= esc_html($country); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-section">
                    <div class="section-title">Cities to Visit</div>
                    <div class="city-container" id="cities_container_<?= $day_index; ?>">
                        <?php if (!empty($day['cities'])): ?>
                            <?php foreach ($day['cities'] as $city_index => $city): ?>
                                <?php $cityId = 'city_' . $day_index . '_' . $city_index; ?>
                                <div class="city-item" id="<?= $cityId; ?>">
                                    <div class="city-header">
                                        <div class="city-number"><?= $city_index + 1; ?></div>
                                        <button type="button" class="remove-city" data-day-index="<?= $day_index; ?>" data-city-index="<?= $city_index; ?>">× Remove</button>
                                    </div>
                                    <div class="form-section">
                                        <label>City:</label>
                                        <select name="itinerary[<?= $day_index; ?>][cities][<?= $city_index; ?>][name]" class="city-select" required>
                                            <option value="">-- Select City --</option>
                                            <?php
                                            $cities = array_filter($locations_data, function ($loc) use ($day) {
                                                return $loc['country'] === ($day['country'] ?? '') && !empty($loc['city']);
                                            });
                                            $city_names = array_unique(array_column($cities, 'city'));
                                            sort($city_names);
                                            foreach ($city_names as $city_name):
                                                if (empty($city_name)) continue;
                                                ?>
                                                <option value="<?= esc_attr($city_name); ?>" <?php selected($city['name'] ?? '', $city_name); ?>>
                                                    <?= esc_html($city_name); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="hidden" name="itinerary[<?= $day_index; ?>][cities][<?= $city_index; ?>][title]" value="<?= esc_attr($city['name'] ?? ''); ?>">
                                    </div>
                                    <div class="city-info-box">
                                        <div id="<?= $cityId; ?>_info">
                                            <?php
                                            if (isset($city['activities']) || isset($city['attractions'])) {
                                                // Get location data for this city
                                                $city_locations = array_filter($locations_data, function ($loc) use ($city, $day) {
                                                    return $loc['city'] === ($city['name'] ?? '') && $loc['country'] === ($day['country'] ?? '');
                                                });

                                                $activities = array_filter($city_locations, function ($loc) {
                                                    return $loc['type'] && strtolower($loc['type']) === 'activity';
                                                });

                                                $attractions = array_filter($city_locations, function ($loc) {
                                                    return $loc['type'] && strtolower($loc['type']) === 'attraction';
                                                });

                                                echo '<div class="activities-columns">';

                                                // Activities
                                                echo '<div class="activities-column"><strong>Activities:</strong><ul>';
                                                if (!empty($activities)) {
                                                    foreach ($activities as $activity) {
                                                        $checked = (isset($city['activities']) && in_array($activity['id'], $city['activities'])) ? 'checked' : '';
                                                        echo '<li><label><input type="checkbox" name="itinerary[' . $day_index . '][cities][' . $city_index . '][activities][]" value="' . $activity['id'] . '" ' . $checked . '> ' . $activity['title'] . '</label></li>';
                                                    }
                                                } else {
                                                    echo '<li>No activities found.</li>';
                                                }
                                                echo '</ul></div>';

                                                // Attractions
                                                echo '<div class="activities-column"><strong>Attractions:</strong><ul>';
                                                if (!empty($attractions)) {
                                                    foreach ($attractions as $attraction) {
                                                        $checked = (isset($city['attractions']) && in_array($attraction['id'], $city['attractions'])) ? 'checked' : '';
                                                        echo '<li><label><input type="checkbox" name="itinerary[' . $day_index . '][cities][' . $city_index . '][attractions][]" value="' . $attraction['id'] . '" ' . $checked . '> ' . $attraction['title'] . '</label></li>';
                                                    }
                                                } else {
                                                    echo '<li>No attractions found.</li>';
                                                }
                                                echo '</ul></div>';

                                                echo '</div>';
                                            } else {
                                                echo 'Please select a city to see available activities and attractions.';
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-cities-message">No cities added yet. Select a country first.</div>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="add-city-btn" data-day-index="<?= $day_index; ?>">+ Add City</button>
                </div>

                <div class="form-section">
                    <div class="section-title">Accommodation</div>
                    
                    <div class="accommodation-columns">
                        <!-- Hotel 1 -->
                        <div class="accommodation-column">
                            <div class="hotel-label">Hotel 1</div>
                            
                            <!-- Star Rating for Hotel 1 -->
                            <div class="accommodation-field">
                                <div class="field-header">
                                    <label>Star Rating:</label>
                                    <button type="button" class="clear-rating-btn" data-target="hotel1_rating_<?= $day_index; ?>">Clear</button>
                                </div>
                                <div class="star-rating-container checkbox-group" id="hotel1_rating_<?= $day_index; ?>">
                                    <?php for ($i = 1; $i <= 7; $i++): ?>
                                        <label class="star-radio">
                                            <input type="radio" 
                                                name="itinerary[<?= $day_index; ?>][hotel1_rating]" 
                                                value="<?= $i; ?>" 
                                                class="star-rating-radio"
                                                <?php checked($day['hotel1_rating'] ?? '', $i); ?>>
                                            <?= $i; ?> Star
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>

                            <!-- Hotel Selection for Hotel 1 -->
                            <div class="accommodation-field">
                                <div class="field-header">
                                    <label>Select Hotel:</label>
                                    <!-- <button type="button" class="clear-hotel-btn" data-target="hotel1_select_<?= $day_index; ?>">Clear</button> -->
                                </div>
                                <select name="itinerary[<?= $day_index; ?>][hotel1]" class="hotel-select scrollable-select" id="hotel1_select_<?= $day_index; ?>">
                                    <option value="">-- Select Hotel --</option>
                                    <?php foreach ($hotels_data as $hotel): ?>
                                        <option value="<?= esc_attr($hotel['id']); ?>" 
                                            <?php selected($day['hotel1'] ?? '', $hotel['id']); ?>
                                            data-title="<?= esc_attr($hotel['title']); ?>"
                                            data-rating="<?= esc_attr($hotel['rating'] ?? ''); ?>">
                                            <?= esc_html($hotel['title']); ?>
                                            <?php if (!empty($hotel['rating'])): ?>
                                                <span class="accommodation-stars">(<?= $hotel['rating']; ?> Star)</span>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" 
                                    name="itinerary[<?= $day_index; ?>][hotel1_title]" 
                                    class="hotel-title-input"
                                    value="<?= esc_attr($day['hotel1_title'] ?? ''); ?>">
                                
                                <div class="hotel-info" style="margin-top: 8px; font-size: 12px; color: #666; display: none;">
                                    <span class="selected-hotel-rating"></span>
                                    <span class="selected-hotel-location"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Hotel 2 -->
                        <div class="accommodation-column">
                            <div class="hotel-label">Hotel 2</div>
                            
                            <!-- Star Rating for Hotel 2 -->
                            <div class="accommodation-field">
                                <div class="field-header">
                                    <label>Star Rating:</label>
                                    <button type="button" class="clear-rating-btn" data-target="hotel2_rating_<?= $day_index; ?>">Clear</button>
                                </div>
                                <div class="star-rating-container checkbox-group" id="hotel2_rating_<?= $day_index; ?>">
                                    <?php for ($i = 1; $i <= 7; $i++): ?>
                                        <label class="star-radio">
                                            <input type="radio" 
                                                name="itinerary[<?= $day_index; ?>][hotel2_rating]" 
                                                value="<?= $i; ?>" 
                                                class="star-rating-radio"
                                                <?php checked($day['hotel2_rating'] ?? '', $i); ?>>
                                            <?= $i; ?> Star
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>

                            <!-- Hotel Selection for Hotel 2 -->
                            <div class="accommodation-field">
                                <div class="field-header">
                                    <label>Select Hotel:</label>
                                    <!-- <button type="button" class="clear-hotel-btn" data-target="hotel2_select_<?= $day_index; ?>">Clear</button> -->
                                </div>
                                <select name="itinerary[<?= $day_index; ?>][hotel2]" class="hotel-select scrollable-select" id="hotel2_select_<?= $day_index; ?>">
                                    <option value="">-- Select Hotel --</option>
                                    <?php foreach ($hotels_data as $hotel): ?>
                                        <option value="<?= esc_attr($hotel['id']); ?>" 
                                            <?php selected($day['hotel2'] ?? '', $hotel['id']); ?>
                                            data-title="<?= esc_attr($hotel['title']); ?>"
                                            data-rating="<?= esc_attr($hotel['rating'] ?? ''); ?>">
                                            <?= esc_html($hotel['title']); ?>
                                            <?php if (!empty($hotel['rating'])): ?>
                                                <span class="accommodation-stars">(<?= $hotel['rating']; ?> Star)</span>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" 
                                    name="itinerary[<?= $day_index; ?>][hotel2_title]" 
                                    class="hotel-title-input"
                                    value="<?= esc_attr($day['hotel2_title'] ?? ''); ?>">
                                
                                <div class="hotel-info" style="margin-top: 8px; font-size: 12px; color: #666; display: none;">
                                    <span class="selected-hotel-rating"></span>
                                    <span class="selected-hotel-location"></span>
                                </div>
                            </div>
                        </div>
                    </div>          
                </div>

                <div class="form-section">
                    <div class="section-title">Day Description</div>
                    <label for="day_<?= $day_index + 1; ?>_description">Description:</label>
                    <textarea name="itinerary[<?= $day_index; ?>][description]" class="day-description" placeholder="Describe the activities, sights, and experiences for this day..." style="min-height: 120px;"><?= esc_textarea($day['description'] ?? ''); ?></textarea>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Add Day Button at the bottom -->
<div style="text-align: center; margin: 30px 0; border-top: 1px solid #e1e5e9; padding-top: 20px;">
    <button type="button" id="add-day" class="button button-primary" style="padding: 2px 10px; font-size: 16px;">+ Add Day</button>
</div>

<style>
/* Your existing CSS is preserved and enhanced with new styles */

.accommodation-columns {
    display: flex;
    gap: 30px;
    margin-top: 15px;
}

.accommodation-column {
    flex: 1;
    padding: 15px;
    border: 1px solid #e1e5e9;
    border-radius: 6px;
    background: white;
}

.hotel-label {
    font-weight: 600;
    margin-bottom: 15px;
    color: #2c3e50;
    font-size: 14px;
    text-align: center;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 4px;
    border: 1px solid #e1e5e9;
}

.star-rating-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 8px;
}

.star-radio {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 13px;
    font-weight: normal;
}

.star-radio input[type="radio"] {
    margin: 0;
}

.scrollable-select {
    max-height: 150px;
    overflow-y: auto;
    border: 1px solid #dce1e6;
    border-radius: 4px;
    padding: 8px 12px;
    font-size: 14px;
    width: 100%;
}

.scrollable-select option {
    padding: 8px;
    border-bottom: 1px solid #eee;
}

.scrollable-select option:hover {
    background: #f0f8ff;
}

.accommodation-field {
    margin-bottom: 20px;
}

.hotel-info {
    padding: 5px;
    background: #f8f9fa;
    border-radius: 3px;
    margin-top: 8px;
}

.day-description {
    min-height: 120px;
    resize: vertical;
}

/* Fix for clear button positioning */
.field-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.field-header label {
    margin-bottom: 0;
    font-weight: 600;
    color: #2c3e50;
    font-size: 14px;
}

.clear-rating-btn,
.clear-hotel-btn {
    background: #6c757d;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.clear-rating-btn:hover,
.clear-hotel-btn:hover {
    background: #5a6268;
    transform: translateY(-1px);
}

/* Responsive design */
@media (max-width: 768px) {
    .accommodation-columns {
        flex-direction: column;
        gap: 20px;
    }
    
    .star-rating-container {
        gap: 5px;
    }
    
    .star-radio {
        font-size: 12px;
    }
    
    .field-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }
    
    .clear-rating-btn,
    .clear-hotel-btn {
        align-self: flex-end;
    }
}

/* Enhanced activities columns to match your existing style */
.activities-columns {
    display: flex;
    gap: 20px;
}

.activities-column {
    flex: 1;
}

.activities-column h5 {
    margin-top: 0;
    border-bottom: 1px solid #eee;
    padding-bottom: 5px;
    font-size: 13px;
}

.activities-column ul {
    list-style: none;
    padding-left: 0;
    margin: 5px 0;
}

.activities-column li {
    margin-bottom: 3px;
    color: #555;
}

.activities-column label {
    font-weight: normal;
    cursor: pointer;
}

.activities-column input[type="checkbox"] {
    margin-right: 5px;
}
</style>

<script>
    const locationsData = <?= json_encode($locations_data); ?>;
    const hotelsData = <?= json_encode($hotels_data); ?>;
    let dayCount = <?= !empty($itinerary) ? count($itinerary) : 0; ?>;
    let cityCounter = <?= !empty($itinerary) ? array_sum(array_map(function($day) { return count($day['cities'] ?? []); }, $itinerary)) : 0; ?>;

    document.addEventListener('DOMContentLoaded', function() {
        initializeEventListeners();
        initializeHotelSelects();
        initializeClearButtons();
    });

    function initializeEventListeners() {
        // Add day button
        document.getElementById('add-day').addEventListener('click', addNewDay);
        
        // Event delegation for dynamic elements
        document.addEventListener('click', function(e) {
            // Remove day button
            if (e.target.classList.contains('remove-day')) {
                e.preventDefault();
                const dayIndex = e.target.getAttribute('data-day-index');
                removeDay(dayIndex);
                return;
            }
            
            // Remove city button
            if (e.target.classList.contains('remove-city') || e.target.closest('.remove-city')) {
                e.preventDefault();
                const removeBtn = e.target.classList.contains('remove-city') ? e.target : e.target.closest('.remove-city');
                const dayIndex = removeBtn.getAttribute('data-day-index');
                const cityIndex = removeBtn.getAttribute('data-city-index');
                removeCity(dayIndex, cityIndex);
                return;
            }
            
            // Add city button
            if (e.target.classList.contains('add-city-btn') && e.target.hasAttribute('data-day-index')) {
                e.preventDefault();
                const dayIndex = parseInt(e.target.getAttribute('data-day-index'));
                addCityToDay(dayIndex);
                return;
            }
        });

        // Country change event delegation
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('country-select')) {
                handleCountryChange(e.target);
            }
            
            // City select change
            if (e.target.classList.contains('city-select')) {
                handleCityChange(e.target);
            }
            
            // Hotel selection change
            if (e.target.classList.contains('hotel-select')) {
                updateHotelInfo(e.target);
            }
            
            // Star rating validation
            if (e.target.classList.contains('star-rating-radio')) {
                validateStarRating(e.target);
            }
        });
    }

    function initializeClearButtons() {
        // Add event listeners to existing clear buttons
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('clear-rating-btn')) {
                e.preventDefault();
                console.log('Clear rating button clicked');
                clearRating(e.target);
            }
            if (e.target.classList.contains('clear-hotel-btn')) {
                e.preventDefault();
                console.log('Clear hotel button clicked');
                clearHotel(e.target);
            }
        });
    }

    function clearRating(button) {
        const targetId = button.getAttribute('data-target');
        console.log('Clearing rating for:', targetId);
        
        const ratingContainer = document.getElementById(targetId);
        
        if (ratingContainer) {
            const radioButtons = ratingContainer.querySelectorAll('input[type="radio"]');
            console.log('Found radio buttons:', radioButtons.length);
            
            radioButtons.forEach(radio => {
                radio.checked = false;
            });
            
            console.log('All ratings cleared');
        } else {
            console.log('Rating container not found:', targetId);
        }
    }

    function clearHotel(button) {
        const targetId = button.getAttribute('data-target');
        console.log('Clearing hotel for:', targetId);
        
        const hotelSelect = document.getElementById(targetId);
        
        if (hotelSelect) {
            hotelSelect.value = '';
            updateHotelInfo(hotelSelect);
            
            // Clear the hidden title input
            const accommodationField = hotelSelect.closest('.accommodation-field');
            const hotelTitleInput = accommodationField.querySelector('.hotel-title-input');
            if (hotelTitleInput) {
                hotelTitleInput.value = '';
            }
            
            console.log('Hotel selection cleared');
        } else {
            console.log('Hotel select not found:', targetId);
        }
    }

    function initializeHotelSelects() {
        document.querySelectorAll('.hotel-select').forEach(select => {
            updateHotelInfo(select);
        });
    }

    function addNewDay() {
        const container = document.getElementById('trip-itinerary-container');
        const dayIndex = dayCount;
        const dayId = `day_${dayCount + 1}`;

        const dayDiv = document.createElement('div');
        dayDiv.className = 'itinerary-day';
        dayDiv.id = dayId;

        dayDiv.innerHTML = `
            <div class="day-header">
                <h3 class="day-title">Day ${dayCount + 1}</h3>
                <button type="button" class="remove-day" data-day-index="${dayIndex}">Remove Day</button>
            </div>

            <div class="form-section">
                <div class="section-title">Destination</div>
                <label for="${dayId}_country">Country:</label>
                <select name="itinerary[${dayIndex}][country]" class="country-select" required>
                    <option value="">-- Select Country --</option>
                </select>
            </div>

            <div class="form-section">
                <div class="section-title">Cities to Visit</div>
                <div class="city-container" id="cities_container_${dayIndex}">
                    <div class="no-cities-message">No cities added yet. Select a country first.</div>
                </div>
                <button type="button" class="add-city-btn" data-day-index="${dayIndex}" disabled>+ Add City</button>
            </div>

            <div class="form-section">
                <div class="section-title">Accommodation</div>
                
                <div class="accommodation-columns">
                    <!-- Hotel 1 -->
                    <div class="accommodation-column">
                        <div class="hotel-label">Hotel 1</div>
                        
                        <!-- Star Rating for Hotel 1 -->
                        <div class="accommodation-field">
                            <div class="field-header">
                                <label>Star Rating:</label>
                                <button type="button" class="clear-rating-btn" data-target="hotel1_rating_${dayIndex}">Clear</button>
                            </div>
                            <div class="star-rating-container checkbox-group" id="hotel1_rating_${dayIndex}">
                                ${generateStarRatings(dayIndex, 'hotel1_rating')}
                            </div>
                        </div>

                        <!-- Hotel Selection for Hotel 1 -->
                        <div class="accommodation-field">
                            <div class="field-header">
                                <label>Select Hotel:</label>
                                <!--<button type="button" class="clear-hotel-btn" data-target="hotel1_select_${dayIndex}">Clear</button> -->
                            </div>
                            <select name="itinerary[${dayIndex}][hotel1]" class="hotel-select scrollable-select" id="hotel1_select_${dayIndex}">
                                <option value="">-- Select Hotel --</option>
                            </select>
                            <input type="hidden" 
                                name="itinerary[${dayIndex}][hotel1_title]" 
                                class="hotel-title-input"
                                value="">
                            
                            <div class="hotel-info" style="margin-top: 8px; font-size: 12px; color: #666; display: none;">
                                <span class="selected-hotel-rating"></span>
                                <span class="selected-hotel-location"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Hotel 2 -->
                    <div class="accommodation-column">
                        <div class="hotel-label">Hotel 2</div>
                        
                        <!-- Star Rating for Hotel 2 -->
                        <div class="accommodation-field">
                            <div class="field-header">
                                <label>Star Rating:</label>
                                <button type="button" class="clear-rating-btn" data-target="hotel2_rating_${dayIndex}">Clear</button>
                            </div>
                            <div class="star-rating-container checkbox-group" id="hotel2_rating_${dayIndex}">
                                ${generateStarRatings(dayIndex, 'hotel2_rating')}
                            </div>
                        </div>

                        <!-- Hotel Selection for Hotel 2 -->
                        <div class="accommodation-field">
                            <div class="field-header">
                                <label>Select Hotel:</label>
                                <!-- <button type="button" class="clear-hotel-btn" data-target="hotel2_select_${dayIndex}">Clear</button> -->
                            </div>
                            <select name="itinerary[${dayIndex}][hotel2]" class="hotel-select scrollable-select" id="hotel2_select_${dayIndex}">
                                <option value="">-- Select Hotel --</option>
                            </select>
                            <input type="hidden" 
                                name="itinerary[${dayIndex}][hotel2_title]" 
                                class="hotel-title-input"
                                value="">
                            
                            <div class="hotel-info" style="margin-top: 8px; font-size: 12px; color: #666; display: none;">
                                <span class="selected-hotel-rating"></span>
                                <span class="selected-hotel-location"></span>
                            </div>
                        </div>
                    </div>
                </div>          
            </div>

            <div class="form-section">
                <div class="section-title">Day Description</div>
                <label for="${dayId}_description">Description:</label>
                <textarea name="itinerary[${dayIndex}][description]" class="day-description" placeholder="Describe the activities, sights, and experiences for this day..." style="min-height: 120px;"></textarea>
            </div>
        `;

        container.appendChild(dayDiv);

        // Initialize the new day
        const countrySelect = dayDiv.querySelector('.country-select');
        const addCityBtn = dayDiv.querySelector('.add-city-btn');
        const hotelSelects = dayDiv.querySelectorAll('.hotel-select');

        populateCountrySelect(countrySelect);
        hotelSelects.forEach(populateHotelSelect);

        // Add event listeners for the new day
        countrySelect.addEventListener('change', function() {
            handleCountryChange(this);
        });

        // addCityBtn.addEventListener('click', function() {
        //     addCityToDay(dayIndex);
        // });

        hotelSelects.forEach(select => {
            select.addEventListener('change', function() {
                updateHotelInfo(this);
            });
        });

        dayCount++;
    }

    function generateStarRatings(dayIndex, fieldName) {
        let html = '';
        for (let i = 1; i <= 7; i++) {
            html += `
                <label class="star-radio">
                    <input type="radio" 
                           name="itinerary[${dayIndex}][${fieldName}]" 
                           value="${i}" 
                           class="star-rating-radio">
                    ${i} Star
                </label>
            `;
        }
        return html;
    }

    function removeDay(dayIndex) {
        if (confirm('Are you sure you want to remove this entire day?')) {
            const dayElement = document.getElementById('day_' + (parseInt(dayIndex) + 1));
            if (dayElement) {
                dayElement.remove();
                // Update day numbers for remaining days
                updateDayNumbers();
            }
        }
    }

    function removeCity(dayIndex, cityIndex) {
        if (confirm('Are you sure you want to remove this city?')) {
            const cityElement = document.getElementById('city_' + dayIndex + '_' + cityIndex);
            if (cityElement) {
                cityElement.remove();
                const container = document.getElementById('cities_container_' + dayIndex);
                updateCityNumbers(container);
                
                // Show no cities message if all cities are removed
                if (container.querySelectorAll('.city-item').length === 0) {
                    container.innerHTML = '<div class="no-cities-message">No cities added yet. Select a country first.</div>';
                }
            }
        }
    }

    function addCityToDay(dayIndex) {
        const dayElement = document.querySelector(`#day_${parseInt(dayIndex) + 1}`);
        const countrySelect = dayElement.querySelector('.country-select');
        const cityContainer = dayElement.querySelector('.city-container');
        const addCityBtn = dayElement.querySelector('.add-city-btn');
        console.log('Adding city to day:', dayIndex);
        
        if (!countrySelect.value) {
            alert('Please select a country first.');
            return;
        }
        
        // Remove no cities message if it exists
        const noCitiesMessage = cityContainer.querySelector('.no-cities-message');
        if (noCitiesMessage) {
            noCitiesMessage.remove();
        }
        
        const cityCount = cityContainer.querySelectorAll('.city-item').length;
        addCitySelect(cityContainer, countrySelect.value, cityCount, dayIndex);
    }

    function handleCountryChange(countrySelect) {
        const dayElement = countrySelect.closest('.itinerary-day');
        const dayIndex = Array.from(document.querySelectorAll('.itinerary-day')).indexOf(dayElement);
        const cityContainer = dayElement.querySelector('.city-container');
        const addCityBtn = dayElement.querySelector('.add-city-btn');
        const noCitiesMessage = cityContainer.querySelector('.no-cities-message');
        
        if (countrySelect.value) {
            addCityBtn.disabled = false;
            cityContainer.innerHTML = '';
            if (noCitiesMessage) noCitiesMessage.style.display = 'none';
            addCitySelect(cityContainer, countrySelect.value, 0, dayIndex);
        } else {
            addCityBtn.disabled = true;
            cityContainer.innerHTML = '<div class="no-cities-message">No cities added yet. Select a country first.</div>';
        }
    }

    function handleCityChange(citySelect) {
        const cityItem = citySelect.closest('.city-item');
        const dayElement = citySelect.closest('.itinerary-day');
        const dayIndex = Array.from(document.querySelectorAll('.itinerary-day')).indexOf(dayElement);
        const cityIndex = Array.from(cityItem.parentElement.querySelectorAll('.city-item')).indexOf(cityItem);
        const countrySelect = dayElement.querySelector('.country-select');
        const infoBox = cityItem.querySelector('.city-info-box');
        const hiddenTitleInput = cityItem.querySelector('input[type="hidden"]');
        
        // Update hidden title field
        hiddenTitleInput.value = citySelect.options[citySelect.selectedIndex]?.text || '';
        
        updateLocationInfo(citySelect.value, countrySelect.value, infoBox, dayIndex, cityIndex);
    }

    function addCitySelect(container, selectedCountry, cityNumber, dayIndex) {
        const cityId = `city_${dayIndex}_${cityCounter}`;
        const cityIndex = cityNumber;
        const wrapper = document.createElement('div');
        wrapper.className = 'city-item';
        wrapper.id = cityId;

        wrapper.innerHTML = `
            <div class="city-header">
                <div class="city-number">${cityNumber + 1}</div>
                <button type="button" class="remove-city" data-day-index="${dayIndex}" data-city-index="${cityCounter}">× Remove</button>
            </div>
            <div class="form-section">
                <label for="${cityId}_select">City:</label>
                <select name="itinerary[${dayIndex}][cities][${cityIndex}][name]" class="city-select" required>
                    <option value="">-- Select City --</option>
                </select>
                <input type="hidden" name="itinerary[${dayIndex}][cities][${cityIndex}][title]" id="${cityId}_title">
            </div>
            <div id="${cityId}_info" class="city-info-box">
                Please select a city to see available activities and attractions.
            </div>
        `;

        container.appendChild(wrapper);

        const select = wrapper.querySelector('select');
        const hiddenTitleInput = wrapper.querySelector('input[type="hidden"]');
        const infoBox = wrapper.querySelector('.city-info-box');

        populateCitySelect(select, selectedCountry);
        hiddenTitleInput.value = select.options[select.selectedIndex]?.text || '';

        cityCounter++;
        return wrapper;
    }

    function updateCityNumbers(container) {
        const cityItems = container.querySelectorAll('.city-item');
        cityItems.forEach((item, index) => {
            const numberElement = item.querySelector('.city-number');
            if (numberElement) {
                numberElement.textContent = index + 1;
            }
            // Update data attributes for remove buttons
            const removeBtn = item.querySelector('.remove-city');
            if (removeBtn) {
                // Get the actual city counter from the ID
                const cityId = item.id;
                const cityCounterMatch = cityId.match(/city_\d+_(\d+)/);
                if (cityCounterMatch) {
                    removeBtn.setAttribute('data-city-index', cityCounterMatch[1]);
                }
            }
        });
    }

    function updateDayNumbers() {
        const dayElements = document.querySelectorAll('.itinerary-day');
        dayElements.forEach((dayElement, index) => {
            const dayNumber = index + 1;
            dayElement.id = 'day_' + dayNumber;
            const titleElement = dayElement.querySelector('.day-title');
            if (titleElement) {
                titleElement.textContent = 'Day ' + dayNumber;
            }
            // Update remove button data attribute
            const removeBtn = dayElement.querySelector('.remove-day');
            if (removeBtn) {
                removeBtn.setAttribute('data-day-index', index);
            }
        });
        dayCount = dayElements.length;
    }

    function populateCountrySelect(selectEl) {
        const countries = [...new Set(locationsData.map(loc => loc.country).filter(Boolean))];
        selectEl.innerHTML = '<option value="">-- Select Country --</option>';
        countries.sort().forEach(country => {
            const option = document.createElement('option');
            option.value = country;
            option.textContent = country;
            selectEl.appendChild(option);
        });
    }

    function populateHotelSelect(selectEl) {
        selectEl.innerHTML = '<option value="">-- Select Hotel --</option>';
        hotelsData.forEach(hotel => {
            const option = document.createElement('option');
            option.value = hotel.id;
            option.textContent = hotel.title + (hotel.rating ? ` (${hotel.rating} Star)` : '');
            option.setAttribute('data-title', hotel.title);
            option.setAttribute('data-rating', hotel.rating || '');
            selectEl.appendChild(option);
        });
    }

    function populateCitySelect(selectEl, selectedCountry) {
        selectEl.innerHTML = '<option value="">-- Select City --</option>';
        const filteredCities = locationsData
            .filter(loc => loc.country === selectedCountry && loc.city)
            .map(loc => loc.city);

        [...new Set(filteredCities)].sort().forEach(cityName => {
            const option = document.createElement('option');
            option.value = cityName;
            option.textContent = cityName;
            selectEl.appendChild(option);
        });
    }

    function updateHotelInfo(selectElement) {
        const hotelId = selectElement.value;
        const accommodationField = selectElement.closest('.accommodation-field');
        const hotelTitleInput = accommodationField.querySelector('.hotel-title-input');
        const hotelInfo = accommodationField.querySelector('.hotel-info');
        
        if (hotelId) {
            const selectedHotel = hotelsData.find(hotel => hotel.id == hotelId);
            if (selectedHotel) {
                let infoHTML = '';
                if (selectedHotel.rating) {
                    infoHTML += `<strong>Rating:</strong> ${selectedHotel.rating} Star`;
                }
                if (selectedHotel.location) {
                    infoHTML += infoHTML ? ' | ' : '';
                    infoHTML += `<strong>Location:</strong> ${selectedHotel.location}`;
                }
                
                hotelInfo.innerHTML = infoHTML;
                hotelInfo.style.display = 'block';
                
                if (hotelTitleInput) {
                    hotelTitleInput.value = selectedHotel.title;
                }
            }
        } else {
            hotelInfo.style.display = 'none';
            if (hotelTitleInput) {
                hotelTitleInput.value = '';
            }
        }
    }

    function validateStarRating(radioElement) {
        // Add any validation logic here if needed
        console.log('Star rating selected:', radioElement.value);
    }

    function updateLocationInfo(selectedCity, selectedCountry, infoBox, dayIndex, cityIndex) {
        if (!infoBox) return;

        if (!selectedCity) {
            infoBox.innerHTML = 'Please select a city to see available activities and attractions.';
            return;
        }

        const cityLocations = locationsData.filter(loc =>
            loc.city === selectedCity && loc.country === selectedCountry
        );

        const activities = cityLocations.filter(loc => loc.type && loc.type.toLowerCase() === 'activity');
        const attractions = cityLocations.filter(loc => loc.type && loc.type.toLowerCase() === 'attraction');

        let html = '';

        if (activities.length > 0 || attractions.length > 0) {
            html += `
            <div class="activities-columns">
                <div class="activities-column">
                <strong>Activities:</strong>
                <ul>
                    ${activities.length > 0 ? activities.map(activity => `
                    <li>
                        <label>
                        <input type="checkbox" name="itinerary[${dayIndex}][cities][${cityIndex}][activities][]" value="${activity.id}">
                        ${activity.title}
                        </label>
                    </li>
                    `).join('') : '<li>No activities found.</li>'}
                </ul>
                </div>
                <div class="activities-column">
                <strong>Attractions:</strong>
                <ul>
                    ${attractions.length > 0 ? attractions.map(attraction => `
                    <li>
                        <label>
                        <input type="checkbox" name="itinerary[${dayIndex}][cities][${cityIndex}][attractions][]" value="${attraction.id}">
                        ${attraction.title}
                        </label>
                    </li>
                    `).join('') : '<li>No attractions found.</li>'}
                </ul>
                </div>
            </div>
            `;
        }

        if (activities.length === 0 && attractions.length === 0) {
            html = 'No activities or attractions found for this city.';
        }

        infoBox.innerHTML = html;
    }
</script>