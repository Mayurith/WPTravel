<?php
/** include/templates/archive-city.php */

get_header();

// Get current page
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

// Optional: if $meta_query is not defined elsewhere
$meta_query = isset($meta_query) ? $meta_query : [];

// Custom query
$args = [
    'post_type' => 'location',
    'posts_per_page' => 12,
    'paged' => $paged,
    'meta_query' => $meta_query,
];

$city_query = new WP_Query($args);
?>

<!-- hero section -->
<section class="relative z-10 -mt-28 h-[350px] sm:h-[750px]">
    <div class="relative !h-[350px] sm:!h-[750px] bg-no-repeat bg-center bg-cover flex items-center justify-center"
        style="background-image: url('<?= get_template_directory_uri() . '/assets/images/hero-bg-6.webp'; ?>');">
        <div class="absolute inset-0 bg-darkblue/40 z-5 opacity-0 animate-fadeIn"></div>
        <div class="relative text-center z-20 w-full">
            <h2 class="!text-white font-semibold">
                <?php
                if (is_post_type_archive()) {
                    post_type_archive_title();
                } elseif (is_tax()) {
                    single_term_title();
                } else {
                    the_title();
                }
                ?>
            </h2>
            <div class="!text-white mt-4 font-medium">Discover beautiful locations around the world</div>
        </div>
    </div>
</section>

<!-- Page Content -->
<section class="container mx-auto mt-20 sm:px-24 px-4">
    <?php if ($city_query->have_posts()): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php while ($city_query->have_posts()):
                $city_query->the_post(); ?>
                <div <?php post_class("!h-[400px] bg-white rounded-lg transition-all duration-300"); ?>>
                    <a href="<?php the_permalink(); ?>" class="block overflow-hidden">
                        <?php if (has_post_thumbnail()): ?>
                            <?php the_post_thumbnail('post_thumbnail', ['class' => 'w-full !h-[250px] object-cover rounded mb-4 transition-transform duration-300 hover:scale-105']); ?>
                        <?php else: ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-thumbnail.png"
                                alt="Default thumbnail"
                                class="w-full !h-[250px] object-cover rounded mb-4 transition-transform duration-300 hover:scale-105" />
                        <?php endif; ?>
                        <div class="hotel-card-title text-primary text-lg leading-[1.6rem] font-semibold mt-3">
                            <?php the_title(); ?>
                        </div>
                        <div class="text-dark text-sm mt-2">
                            <?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?>
                        </div>
                        <button
                            class="flex items-center text-secondary bg-secondary/10 hover:text-white hover:bg-secondary py-2 px-8 mt-4 rounded-sm cursor-pointer items-end">
                            <div class="text-sm font-medium"><span class="ml-2">Read More</span></div>
                            <div class="text-3xl flex items-center">
                                <i class="lni lni-arrow-angular-top-right text-secondary ml-2"></i>
                            </div>
                        </button>
                    </a>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination flex justify-center mt-12">
            <?php
            $pagination = paginate_links([
                'total' => $city_query->max_num_pages,
                'current' => $paged,
                'mid_size' => 2,
                'prev_text' => __('« Prev', 'textdomain'),
                'next_text' => __('Next »', 'textdomain'),
                'type' => 'array',
            ]);

            if ($pagination) {
                echo '<ul class="flex items-center justify-center gap-2 flex-wrap">';
                foreach ($pagination as $page) {
                    echo '<li class="inline-block">' . str_replace(
                        ['page-numbers current', 'page-numbers'],
                        ['px-4 py-2 border border-secondary bg-secondary text-white rounded-md font-medium', 'px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-secondary hover:text-white transition'],
                        $page
                    ) . '</li>';
                }
                echo '</ul>';
            }
            ?>
        </div>

    <?php else: ?>
        <p class="text-center text-gray-500"><?php _e('No posts found in this category.', 'textdomain'); ?></p>
    <?php endif; ?>
</section>

<?php
wp_reset_postdata();
get_footer();
?>
