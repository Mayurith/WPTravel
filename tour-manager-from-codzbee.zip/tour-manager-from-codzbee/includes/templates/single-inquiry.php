<?php
/** includes/templates/single-inquiry.php */

/**
 * Template Name: Single Inquiry View
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header(); ?>

<div class="inquiry-container">
    <?php while (have_posts()) : the_post(); ?>
        <h1><?php the_title(); ?></h1>
        
        <div class="inquiry-details">
            <div class="detail-row">
                <span class="detail-label">Name:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'name', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Email:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'email', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Phone:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'phone', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Tour Category:</span>
                <span class="detail-value">
                    <?php 
                    $term_id = get_post_meta(get_the_ID(), 'tour_category', true);
                    if ($term_id) {
                        $term = get_term($term_id, 'tour_category');
                        echo $term && !is_wp_error($term) ? esc_html($term->name) : '';
                    }
                    ?>
                </span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Arrival Date:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'date_field', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Guests:</span>
                <span class="detail-value">
                    <?php 
                    $adults = get_post_meta(get_the_ID(), 'adult_count', true);
                    $children = get_post_meta(get_the_ID(), 'child_count', true);
                    echo esc_html("$adults Adults, $children Children");
                    ?>
                </span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Message:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'message', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Status:</span>
                <span class="detail-value"><?php echo esc_html(get_post_meta(get_the_ID(), 'status', true)); ?></span>
            </div>
            
            <div class="detail-row">
                <span class="detail-label">Submitted:</span>
                <span class="detail-value"><?php echo get_the_date(); ?></span>
            </div>
        </div>
        
        <div class="inquiry-actions">
            <a href="<?php echo admin_url('post.php?post='.get_the_ID().'&action=edit'); ?>" class="button">
                Edit Inquiry
            </a>
            <a href="<?php echo admin_url('edit.php?post_type=inquiry'); ?>" class="button">
                Back to All Inquiries
            </a>
        </div>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>
