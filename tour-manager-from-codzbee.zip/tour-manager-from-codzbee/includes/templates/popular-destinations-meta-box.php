<?php
/** includes/templates/popular-destinations-meta-box.php */

if (!defined('ABSPATH')) {
    exit;
}

$is_popular = get_post_meta($post->ID, '_tm_popular_destinations', true);

?>


<div>
    <label for="tm_popular_destinations">Select as popular destinations</label>
    <div>
        <div>
            <input type="radio" id="tm_popular_destinations_yes" name="tm_popular_destinations" value="yes" <?php checked( $is_popular, 'yes' ); ?> />
            <label for="tm_popular_destinations_yes">Yes</label>
        </div>
        <div>
            <input type="radio" id="tm_popular_destinations_no" name="tm_popular_destinations" value="no" <?php checked( $is_popular, 'no' ); ?> />
            <label for="tm_popular_destinations_no">No</label>
        </div>
    </div>
</div>