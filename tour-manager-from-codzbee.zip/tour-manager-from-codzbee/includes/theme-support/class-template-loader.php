<?php
// includes/theme-support/class-template-loader.php

if (!defined('ABSPATH')) exit;

class Tour_Manager_Template_Loader {
    private $template_path;
    
    public function __construct() {
        $this->template_path = apply_filters('tour_manager_template_path', 'tour-manager/');
    }
    
    public function locate_template($template_name) {
        // 1. Check theme first
        $template = locate_template([
            $this->template_path . $template_name,
            $template_name
        ]);
        
        // 2. Fallback to plugin templates
        if (!$template && file_exists(TOUR_MANAGER_DIR . 'templates/' . $template_name)) {
            $template = TOUR_MANAGER_DIR . 'templates/' . $template_name;
        }
        
        return apply_filters('tour_manager_locate_template', $template, $template_name);
    }
    
    public function get_template($template_name, $args = []) {
        $template = $this->locate_template($template_name);
        
        if (!empty($args) && is_array($args)) {
            extract($args);
        }
        
        if ($template) {
            include $template;
        }
    }
}