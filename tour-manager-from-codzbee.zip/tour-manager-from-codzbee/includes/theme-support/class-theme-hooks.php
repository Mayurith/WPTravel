<?php
// includes/theme-support/class-theme-hooks.php

if (!defined('ABSPATH')) exit;

class Tour_Manager_Theme_Hooks {
    public function __construct() {
        // Allow themes to modify output
        add_filter('tour_manager_form_before', [$this, 'form_before_hook'], 10, 2);
        add_filter('tour_manager_form_after', [$this, 'form_after_hook'], 10, 2);
        
        // Add theme support check
        add_action('after_setup_theme', [$this, 'check_theme_support']);
    }
    
    public function form_before_hook($content, $form_type) {
        return $content;
    }
    
    public function form_after_hook($content, $form_type) {
        return $content;
    }
    
    public function check_theme_support() {
        if (current_theme_supports('tour-manager')) {
            // Theme declares explicit support
            $this->setup_theme_specific_features();
        }
    }
    
    protected function setup_theme_specific_features() {
        // Add theme-specific integrations here
    }
}