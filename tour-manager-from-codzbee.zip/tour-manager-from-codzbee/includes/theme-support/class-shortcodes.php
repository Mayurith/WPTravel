<?php
// includes/theme-support/class-shortcodes.php

if (!defined('ABSPATH')) exit;

class Tour_Manager_Shortcodes {
    private $template_loader;
    
    public function __construct() {
        $this->template_loader = new Tour_Manager_Template_Loader();
        
        add_shortcode('tour_inquiry_form', [$this, 'inquiry_form']);
        add_shortcode('tour_listing', [$this, 'tour_listing']);
    }
    
    public function inquiry_form($atts) {
        ob_start();
        
        // Allow themes to add content before form
        echo apply_filters('tour_manager_form_before', '', 'inquiry');
        
        // Load template
        $this->template_loader->get_template('inquiry-form.php', [
            'categories' => $this->get_tour_categories(),
            'atts' => shortcode_atts([
                'show_title' => true
            ], $atts)
        ]);
        
        // Allow themes to add content after form
        echo apply_filters('tour_manager_form_after', '', 'inquiry');
        
        return ob_get_clean();
    }
    
    protected function get_tour_categories() {
        return get_terms([
            'taxonomy' => 'tour_category',
            'hide_empty' => false,
        ]);
    }
}