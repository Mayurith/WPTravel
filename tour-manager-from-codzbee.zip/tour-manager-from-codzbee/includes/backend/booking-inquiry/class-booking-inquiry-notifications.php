<?php
/** includes/backend/inquiry/class-inquiry-notifications.php */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles all notification-related functionality for inquiries
 */
class Booking_Inquiry_Notifications {
    
    public function __construct() {
        add_action('admin_notices', [$this, 'show_admin_notice']);
        add_action('admin_init', [$this, 'check_for_new_inquiries']);
        add_action('wp_ajax_tm_dismiss_inquiry_notice', [$this, 'handle_dismiss_notice']);
        add_action('wp_dashboard_setup', [$this, 'add_dashboard_widget']);
    }

    /**
     * Check for new inquiries and set flag if found
     */
    public function check_for_new_inquiries() {
        if (isset($_GET['post_type']) && $_GET['post_type'] === 'inquiry') {
            // When admin views inquiries page, mark all as seen
            $this->mark_inquiries_seen();
            return;
        }

        // Skip if we already have new inquiries notification
        if (get_transient('tm_has_new_inquiries')) {
            return;
        }

        // Check for new inquiries in the last 24 hours
        $recent_inquiries = get_posts([
            'post_type' => 'inquiry',
            'post_status' => 'private',
            'date_query' => [['after' => '24 hours ago']],
            'posts_per_page' => 1,
            'fields' => 'ids'
        ]);

        if (!empty($recent_inquiries)) {
            set_transient('tm_has_new_inquiries', true, 0);
        }
    }

    /**
     * Show admin notice if there are new inquiries
     */
    public function show_admin_notice() {
        global $pagenow;
        
        // Only show on dashboard and edit pages
        if ($pagenow !== 'index.php' && $pagenow !== 'edit.php') {
            return;
        }

        $unread_count = $this->get_unread_count();
        
        if ($unread_count > 0) : ?>
            <div class="notice notice-info is-dismissible tm-inquiry-notice">
                <p>
                    <?php 
                    printf(
                        _n('You have %d new tour inquiry!', 'You have %d new tour inquiries!', $unread_count),
                        $unread_count
                    ); 
                    ?>
                    <a href="<?php echo admin_url('edit.php?post_type=inquiry'); ?>" class="button button-primary" style="margin-left: 10px;">
                        <?php _e('View Inquiries', 'text-domain'); ?>
                    </a>
                    <a href="#" class="tm-dismiss-notice" style="margin-left: 10px;">
                        <?php _e('Dismiss', 'text-domain'); ?>
                    </a>
                </p>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                $('.tm-dismiss-notice').on('click', function(e) {
                    e.preventDefault();
                    $.post(ajaxurl, {
                        action: 'tm_dismiss_inquiry_notice',
                        security: '<?php echo wp_create_nonce("tm_dismiss_notice"); ?>'
                    });
                    $(this).closest('.notice').fadeOut();
                });
            });
            </script>
        <?php endif;
    }

    /**
     * Get count of unread inquiries
     */
    public function get_unread_count() {
        $seen = get_user_meta(get_current_user_id(), 'tm_seen_inquiries', true) ?: [];
        $all_inquiries = get_posts([
            'post_type' => 'inquiry',
            'post_status' => 'private',
            'fields' => 'ids',
            'posts_per_page' => -1
        ]);
        
        return count(array_diff($all_inquiries, $seen));
    }

    /**
     * Mark all inquiries as seen by current user
     */
    public function mark_inquiries_seen() {
        if (current_user_can('manage_options')) {
            $all_inquiries = get_posts([
                'post_type' => 'inquiry',
                'post_status' => 'private',
                'fields' => 'ids',
                'posts_per_page' => -1
            ]);
            
            update_user_meta(get_current_user_id(), 'tm_seen_inquiries', $all_inquiries);
            delete_transient('tm_has_new_inquiries');
        }
    }

    /**
     * Handle AJAX request to dismiss notice
     */
    public function handle_dismiss_notice() {
        check_ajax_referer('tm_dismiss_notice', 'security');
        
        if (current_user_can('manage_options')) {
            $this->mark_inquiries_seen();
        }
        
        wp_send_json_success();
    }

    /**
     * Called when a new inquiry is received
     */
    public function new_inquiry_received($post_id) {
        set_transient('tm_has_new_inquiries', true, 0);
        
        // Optional: Send email notification
        $this->send_email_notification($post_id);
    }


    public function send_email_notification($post_id) {
        $inquiry = get_post($post_id);
        $admin_email = get_option('admin_email');
        
        $subject = sprintf(__('New Tour Inquiry: %s', 'text-domain'), $inquiry->post_title);
        
        $message = sprintf(__('You have received a new tour inquiry:<br><br>%s', 'text-domain'), 
            $this->format_inquiry_details($post_id)
        );
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        wp_mail($admin_email, $subject, $message, $headers);
    }
    
    private function format_inquiry_details($post_id) {
        $details = [
            __('Name', 'text-domain') => get_post_meta($post_id, 'name', true),
            __('Email', 'text-domain') => get_post_meta($post_id, 'email', true),
            __('Tour', 'text-domain') => get_post_meta($post_id, 'tour_category_name', true),
            __('Date', 'text-domain') => get_post_meta($post_id, 'date_field', true),
        ];
        
        $output = '<ul>';
        foreach ($details as $label => $value) {
            $output .= sprintf('<li><strong>%s:</strong> %s</li>', $label, $value);
        }
        $output .= '</ul>';
        
        return $output;
    }

    public function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'tm_recent_inquiries',
            __('Recent Tour Inquiries', 'text-domain'),
            [$this, 'render_dashboard_widget']
        );
    }
    
    public function render_dashboard_widget() {
        $inquiries = get_posts([
            'post_type' => 'inquiry',
            'posts_per_page' => 5,
            'orderby' => 'date',
            'order' => 'DESC'
        ]);
        
        if (empty($inquiries)) {
            echo '<p>' . __('No recent inquiries found.', 'text-domain') . '</p>';
            return;
        }
        
        echo '<ul>';
        foreach ($inquiries as $inquiry) {
            $view_url = admin_url(sprintf('post.php?post=%d&action=edit', $inquiry->ID));
            printf(
                '<li><a href="%s">%s</a> - %s</li>',
                $view_url,
                $inquiry->post_title,
                get_the_date('', $inquiry->ID)
            );
        }
        echo '</ul>';
        
        echo '<p><a href="' . admin_url('edit.php?post_type=inquiry') . '" class="button">' . 
             __('View All Inquiries', 'text-domain') . '</a></p>';
    }
}