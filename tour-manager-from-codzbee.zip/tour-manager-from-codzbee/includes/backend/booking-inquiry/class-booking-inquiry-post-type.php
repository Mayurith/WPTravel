<?php
/** includes/backend/inquiry/class-booking-inquiry-post-type.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}



class Booking_Inquiry_Post_Type
{

    public function __construct()
    {

        /** enqueue scripts */
        add_action('admin_enqueue_scripts', array($this, 'tm_enqueue_script_and_styles'));
        add_action('init', array($this, 'tm_register_inquiry_post_type'));
        
    }


    public function tm_enqueue_script_and_styles()
    {
        wp_enqueue_script('tour-inquiry-form-script', plugin_dir_url(__FILE__) . '../../../assets/js/inquiry-form.js', array('jquery'), filemtime(plugin_dir_path(__FILE__) . '../../../assets/js/inquiry-form.js'), true);
        wp_enqueue_style('tour-inquiry-form-style', plugin_dir_url(__FILE__) . '../../../assets/css/inquiry-booking-form.css', array(), filemtime(plugin_dir_path(__FILE__) . '../../../assets/css/inquiry-booking-form.css'));
    }


    public function tm_register_inquiry_post_type()
    {
        $args = array(
            'labels' => array(
                'name' => 'Inquiries',
                'singular_name' => 'Inquiry',
                'search_items' => 'Search'
            ),
            'public' => false,
            // 'has_archive' => true,
            'has_archive' => false,
            'publicaly_queryble' => false,
            'supports' => array(''),
            'capabilities' => array(
                'create_posts' => false, /** Disable creating new from admin */
            ),
            'map_meta_cap' => true,
            'show_ui' => true,
            'show_in_menu' => 'main_menu_of_tour_manager', /** Add to the "Tour Manager" main menu */
            'rewrite' => array('slug' => 'inquiry') // Custom slug if needed
        );

        register_post_type('inquiry', $args);

        // Add rewrite rule for pretty permalinks
        add_rewrite_rule('^inquiry/([^/]+)/?', 'index.php?post_type=inquiry&name=$matches[1]', 'top');
    }

}