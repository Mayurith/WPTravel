<?php
/** includes/backend/booking-inquiry/class-booking-inquiry-ajax-handler.php */

if (!defined('ABSPATH')) {
    exit;
}

class Booking_Inquiry_Ajax_Handler
{
    public function __construct()
    {
        add_action('wp_ajax_submit_tour_booking', [$this, 'handle_tour_booking']);
        add_action('wp_ajax_nopriv_submit_tour_booking', [$this, 'handle_tour_booking']);

        add_action('wp_ajax_submit_tour_inquiry', [$this, 'handle_tour_inquiry']);
        add_action('wp_ajax_nopriv_submit_tour_inquiry', [$this, 'handle_tour_inquiry']);
    }

    public function handle_tour_booking()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['tour_booking_security'], 'tour_booking_nonce')) {
            wp_send_json_error('Security check failed');
        }

        // Get tour title if not provided
        $tour_title = isset($_POST['tour_title']) ? sanitize_text_field($_POST['tour_title']) : '';
        if (empty($tour_title) && isset($_POST['tour_id'])) {
            $tour_title = get_the_title(intval($_POST['tour_id']));
        }

        $data = [
            'full_name' => sanitize_text_field($_POST['full_name']),
            'phone' => sanitize_text_field($_POST['phone']),
            'email' => sanitize_email($_POST['email']),
            'country' => sanitize_text_field($_POST['country']),
            'message' => sanitize_textarea_field($_POST['message']),
            'tour_id' => intval($_POST['tour_id']),
            'tour_title' => $tour_title,
            'arrival_date' => sanitize_text_field($_POST['arrival_date']),
            'adults' => intval($_POST['adults']),
            'children' => intval($_POST['children']),
            // 'total_price' => floatval($_POST['total_price']),
            'form_type' => 'booking'
        ];

        $post_id = $this->create_inquiry_post($data);

        if ($post_id && !is_wp_error($post_id)) {
            // Send emails
            $admin_email_sent = $this->send_admin_booking_email($data, $post_id);
            $user_email_sent = $this->send_user_booking_confirmation($data, $post_id);
            $success_message = 'Your inquiry booking has been submitted successfully! We will get back to you soon.';

            // Debug logging (remove in production)
            if (!$admin_email_sent) {
                error_log('Admin booking email failed to send for post ID: ' . $post_id);
            }
            if (!$user_email_sent) {
                error_log('User booking confirmation email failed to send for post ID: ' . $post_id);
            }

            // wp_send_json_success('Booking submitted successfully');
            wp_send_json_success($success_message);
        } else {
            // wp_send_json_error('Failed to save booking');
            $error_message = 'Failed to save booking inquiry. Please try again.';
            if (is_wp_error($post_id)) {
                $error_message = $post_id->get_error_message();
            }
            wp_send_json_error($error_message);
        }
    }

    public function handle_tour_inquiry()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'tour_inquiry_nonce')) {
            wp_send_json_error('Security check failed');
        }

        $data = [
            'full_name' => sanitize_text_field($_POST['full_name']),
            'phone' => sanitize_text_field($_POST['phone']),
            'email' => sanitize_email($_POST['email']),
            'country' => sanitize_text_field($_POST['country']),
            'message' => sanitize_textarea_field($_POST['message']),
            'tour_category' => sanitize_text_field($_POST['tour_category']),
            'arrival_date' => sanitize_text_field($_POST['arrival_date']),
            'adults' => intval($_POST['adults']),
            'children' => intval($_POST['children']),
            'form_type' => 'inquiry'
        ];

        $post_id = $this->create_inquiry_post($data);

        if ($post_id && !is_wp_error($post_id)) {
            // Send emails
            $admin_email_sent = $this->send_admin_inquiry_email($data, $post_id);
            $user_email_sent = $this->send_user_inquiry_confirmation($data, $post_id);

            // Debug logging (remove in production)
            // if (!$admin_email_sent) {
            //     error_log('Admin inquiry email failed to send for post ID: ' . $post_id);
            // }
            // if (!$user_email_sent) {
            //     error_log('User inquiry confirmation email failed to send for post ID: ' . $post_id);
            // }

            // wp_send_json_success('Inquiry submitted successfully');
            $success_message = 'Your inquiry has been submitted successfully! <br> We will get back to you soon.';

            // Message pass
            wp_send_json_success($success_message);
        } else {
            // wp_send_json_error('Failed to save inquiry');
            $error_message = 'Failed to save inquiry. Please try again.';
            if (is_wp_error($post_id)) {
                $error_message = $post_id->get_error_message();
            }
            wp_send_json_error($error_message);
        }
    }

    private function create_inquiry_post($data)
    {
        $post_data = [
            'post_title' => $data['form_type'] . ' - ' . $data['full_name'] . ' - ' . date('Y-m-d H:i:s'),
            'post_type' => 'inquiry',
            'post_status' => 'publish',
            'meta_input' => $data
        ];

        return wp_insert_post($post_data);
    }

    private function send_admin_booking_email($data, $post_id)
    {
        $to = get_option('tm_admin_email', get_bloginfo('gl_admin_email'));
        $subject = 'New Tour Booking Received - ' . get_bloginfo('name');

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('gl_admin_email') . '>'
        ];

        $message = $this->get_admin_booking_email_template($data, $post_id);

        // error_log('Admin email is: ' . get_option('gl_admin_email'));

        return wp_mail($to, $subject, $message, $headers);
    }

    private function send_user_booking_confirmation($data, $post_id)
    {
        $to = $data['email'];
        $subject = 'Your booking request has been submitted successfully - ' . get_bloginfo('name');

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            // 'From: ' . get_bloginfo('name') . ' <' . get_option('gl_admin_email') . '>'
        ];

        $message = $this->get_user_booking_confirmation_template($data, $post_id);

        return wp_mail($to, $subject, $message, $headers);
    }

    private function send_admin_inquiry_email($data, $post_id)
    {
        $to = get_option('tm_admin_email', get_bloginfo('gl_admin_email'));
        $subject = 'New Tour Inquiry Received - ' . get_bloginfo('name');
        

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('gl_admin_email') . '>'
        ];

        $message = $this->get_admin_inquiry_email_template($data, $post_id);

        return wp_mail($to, $subject, $message, $headers);
    }

    private function send_user_inquiry_confirmation($data, $post_id)
    {
        $to = $data['email'];
        $subject = 'Inquiry Received - ' . get_bloginfo('name');

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            // 'From: ' . get_bloginfo('name') . ' <' . get_option('gl_admin_email') . '>'
        ];

        $message = $this->get_user_inquiry_confirmation_template($data, $post_id);

        return wp_mail($to, $subject, $message, $headers);
    }

    private function get_admin_inquiry_email_template($data, $post_id)
    {
        // Define template path
        $template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/inquiry-emails/admin-submition-confirmation.php';

        // Alternative: If in theme, use locate_template
        // $template_path = locate_template('templates/emails/admin-inquiry-email.php');

        if (!file_exists($template_path)) {
            return '<p>Email template not found.</p>';
        }

        // Extract variables for the template
        extract([
            'data' => $data,
            'post_id' => $post_id
        ]);

        ob_start();
        include $template_path;
        return ob_get_clean();
    }

    private function get_user_inquiry_confirmation_template($data, $post_id)
    {
        // Define template path
        $template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/inquiry-emails/user-submition-confirmation.php';

        // Alternative: If in theme, use locate_template
        // $template_path = locate_template('templates/emails/user-inquiry-confirmation.php');

        if (!file_exists($template_path)) {
            return '<p>Email template not found.</p>';
        }

        // Extract variables for the template
        extract([
            'data' => $data,
            'post_id' => $post_id
        ]);

        ob_start();
        include $template_path;
        return ob_get_clean();
    }


    private function get_admin_booking_email_template($data, $post_id)
    {

        // Define template path
        $template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/booking-emails/admin-submition-confirmation.php';

        // Alternative: If in theme, use locate_template
        // $template_path = locate_template('templates/emails/admin-inquiry-email.php');

        if (!file_exists($template_path)) {
            return '<p>Email template not found.</p>';
        }

        // Extract variables for the template
        extract([
            'data' => $data,
            'post_id' => $post_id
        ]);

        ob_start();
        include $template_path;
        return ob_get_clean();
    }

    private function get_user_booking_confirmation_template($data, $post_id)
    {
        // Define template path
        $template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/booking-emails/user-submition-confirmation.php';

        // Alternative: If in theme, use locate_template
        // $template_path = locate_template('templates/emails/admin-inquiry-email.php');

        if (!file_exists($template_path)) {
            return '<p>Email template not found.</p>';
        }

        // Extract variables for the template
        extract([
            'data' => $data,
            'post_id' => $post_id
        ]);

        ob_start();
        include $template_path;
        return ob_get_clean();

    }
}