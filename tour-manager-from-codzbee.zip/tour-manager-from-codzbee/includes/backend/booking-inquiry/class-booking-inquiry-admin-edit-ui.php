<?php
/** includes/backend/inquiry/class-inquiry-admin-ui-new.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class Inquiry_Admin_UI
 */
class Booking_Inquiry_Admin_Edit_UI
{
    /**
     * @method __construct
     */
    public function __construct()
    {
        /** Hook for enqueing scripts and styles */
        add_action('admin_enqueue_scripts', [$this, 'tm_enqueue_assets']);
        /** Hook for add view action to posts */
        add_filter('post_row_actions', [$this, 'tm_add_view_action_to_posts'], 10, 2);
        /** Hook for add view option to posts */
        add_filter('page_row_actions', [$this, 'tm_add_view_action_to_posts'], 10, 2);
        /** Hook for create mete box */
        add_action('add_meta_boxes', [$this, 'tm_add_inquiry_meta_box']);
        /** Hook for save post meta */
        add_action('save_post_inquiry', [$this, 'tm_save_inquiry_meta'], 10, 3);


    }


    /**
     * Summary of enqueue_assets
     * @param mixed $hook
     * @return void
     */
    public function tm_enqueue_assets($hook)
    {
        global $pagenow, $post_type;
        if (is_admin() && ($pagenow === 'edit.php' || $pagenow === 'post.php') && $post_type === 'inquiry') {

            /** Enqueue jQuery (should already be in admin) */
            wp_enqueue_script('jquery');

            /** Enqueue jQuery UI for dialog (modal) */
            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_style('wp-jquery-ui-dialog');

            /** Add custom script */
            wp_enqueue_script(
                'custom-view-modal',
                plugins_url('../../../assets/js/inquiry-custom-edit-page.js', __FILE__),
                array('jquery', 'jquery-ui-dialog'),
                '1.0',
                true
            );

            wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');


            /** Add custom style */
            wp_enqueue_style(
                'custom-view-modal',
                plugins_url('../../../assets/css/inquiry-custom-edit-page.css', __FILE__),
                array(),
                '1.0'
            );
        }
    }


    /**
     * Summary of add_view_action_to_posts
     * @param mixed $actions
     * @param mixed $post
     */


    public function tm_add_view_action_to_posts($actions, $post)
    {
        if ($post->post_type === 'inquiry') {
            $type = get_post_meta($post->ID, 'type', true) ?: 'inquiry';
            $nonce = wp_create_nonce('get_inquiry_details' . $post->ID);

            // Keep default Edit link
            $edit_url = get_edit_post_link($post->ID);
            $actions['edit'] = sprintf(
                '<a href="%s" class="Edit-details" data-id="%d" data-type="%s" data-nonce="%s" title="%s">%s</a>',
                esc_url($edit_url),
                $post->ID,
                esc_attr($type),
                esc_attr($nonce),
                esc_attr__('Edit this inquiry in WordPress', 'text-domain'),
                esc_html__('Edit', 'text-domain')
            );
        }

        return $actions;
    }


    public function tm_add_inquiry_meta_box($post)
    {

        add_meta_box(
            'tm_inquiry_meta',
            __('Inquiry/Booking Details', 'text-domain'),
            [$this, 'tm_render_inquiry_meta_box'],
            'inquiry',
            'normal',
            'default'
        );

        // Ensure unique IDs for each meta box
        // add_meta_box(
        //     'tm_inquiry_rejected_note',
        //     __('Rejected Note', 'text-domain'),
        //     [$this, 'tm_booking_inquiry_rejected_meta_box'],
        //     'inquiry',
        //     'normal',
        //     'default'
        // );
    }
    public function tm_render_inquiry_meta_box($post)
    {
        // Get existing meta
        $type = get_post_meta($post->ID, 'type', true);

        // Nonce for security
        wp_nonce_field('tm_save_inquiry_meta', 'tm_inquiry_meta_nonce');

        $name = get_post_meta($post->ID, 'name', true);
        $email = get_post_meta($post->ID, 'email', true);
        $phone = get_post_meta($post->ID, 'phone', true);
        $type = get_post_meta($post->ID, 'type', true) ?: 'inquiry';
        $tour_booking_date = get_post_meta($post->ID, 'tour-booking-date', true);
        $inquiry_date_field = get_post_meta($post->ID, 'inquiry-date_field', true);
        $adults = get_post_meta($post->ID, 'adult_count', true);
        $children = get_post_meta($post->ID, 'child_count', true);
        $total = get_post_meta($post->ID, 'total_amount', true);
        $tour_id = get_post_meta($post->ID, 'tour_id', true);
        $inquiry_id = get_post_meta($post->ID, 'inquiry_id', true);
        $booking_id = get_post_meta($post->ID, 'booking_id', true);
        $message = get_post_meta($post->ID, 'message', true);

        // $numeric_total = preg_replace('/[^0-9.]/', '', $total);

        // Get tour category name from post meta
        $tour_category = get_post_meta($post->ID, 'tour_category', true);
        $tour_category_name = $tour_category;
        if (is_numeric($tour_category)) {
            $term = get_term_by('id', $tour_category, 'tour_category');
            if ($term && !is_wp_error($term)) {
                $tour_category_name = $term->name;
            }
        }
        $tour_slug = get_post_meta($post->ID, 'tour_slug', true);

        $country = get_post_meta($post->ID, 'inquiry-country', true);


        $tour_booking_date = get_post_meta($post->ID, 'tour-booking-date', true);
        $inquiry_date_field = get_post_meta($post->ID, 'inquiry-date_field', true);


        $current_status = get_post_meta($post->ID, 'status', true) ?: 'pending';

        ?>


        <section class="tm-booking-inquiry-section" data-post-id="<?php echo $post->ID; ?>">

            <div class="tm-id-class">
                <?php if ($type === 'inquiry'): ?>
                    <h2><strong><?php _e('Inquiry ID: ', 'text-domain'); ?><?= esc_attr($inquiry_id) ?></strong> </h2>
                <?php else: ?>
                    <h2><strong><?php _e('Booking ID: ', 'text-domain'); ?><?= esc_attr($booking_id) ?></strong></h2>
                <?php endif; ?>
            </div>

            <div class="tm-booking-inquiry-details">
                <div class="tm-column customer-details">
                    <h3>Customer Details</h3>
                    <p><strong><?php _e('Name:', 'text-domain'); ?></strong> <?= esc_attr($name) ?> </p>
                    <p><strong><?php _e('Email:', 'text-domain'); ?> </strong> <?= esc_attr($email) ?> </p>
                    <p><strong><?php _e('Phone: ', 'text-domain'); ?></strong> <?= esc_attr($phone) ?> </p>
                    <p><strong><?php _e('Country: ', 'text-domain'); ?></strong> <?= esc_attr($country) ?> </p>

                </div>
                <div class="tm-column tm-booking-details">
                    <?php if ($type === 'inquiry'): ?>
                        <h3><?php _e('Inquiry Details'); ?></h3>
                    <?php else: ?>
                        <h3><?php _e('Booking Details') ?></h3>
                    <?php endif; ?>

                    <p><strong><?php _e('Type:', 'text-domain'); ?></strong> <?= esc_attr($type) ?> </p>
                    <p><strong><?php _e('Guest:', 'text-domain'); ?></strong> A- <?= esc_attr($adults) ?> / C-
                        <?= esc_attr($children) ?>
                    </p>

                    <!-- Conditional display -->

                    <?php if ($type === 'inquiry'): ?>
                        <p><strong><?php _e('Tour Category:', 'text-domain'); ?></strong> <?= esc_html($tour_category_name); ?></p>
                        <p><strong><?php _e('Inquiry Date:', 'text-domain'); ?></strong> <?= esc_html($inquiry_date_field); ?></p>
                    <?php else: ?>
                        <p><strong><?php _e('Tour Name:', 'text-domain'); ?></strong> <?= esc_html($tour_slug); ?></p>
                        <p><strong><?php _e('Booking Date:', 'text-domain'); ?></strong> <?= esc_html($tour_booking_date); ?></p>

                    <?php endif; ?>
                </div>
            </div>
            <div class="tm-column tm-custom-message">
                <h3><strong><?php _e('Message', 'text-domain'); ?></strong></h3>
                <p><?= esc_html($message); ?></p>
            </div>

        </section>

        <?php

    }



    public function tm_save_inquiry_meta($post_id, $post, $update)
    {
        // Skip autosaves, revisions, and non-inquiry posts
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;
        if (wp_is_post_revision($post_id))
            return;
        if ($post->post_type !== 'inquiry')
            return;

        // Verify nonce
        if (
            !isset($_POST['tm_inquiry_meta_nonce']) ||
            !wp_verify_nonce($_POST['tm_inquiry_meta_nonce'], 'tm_save_inquiry_meta')
        ) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $post_id))
            return;

        // Save status and other fields
        $old_status = get_post_meta($post_id, 'status', true);
        $new_status = isset($_POST['tm_inquiry_status']) ? sanitize_text_field($_POST['tm_inquiry_status']) : 'pending';
        update_post_meta($post_id, 'status', $new_status);

        // Save admin notes and amounts
        if (isset($_POST['tm_additional_note'])) {
            update_post_meta($post_id, 'tm_additional_note', sanitize_textarea_field($_POST['tm_additional_note']));
        }
        if (isset($_POST['total_amount'])) {
            update_post_meta($post_id, 'total_amount', sanitize_text_field($_POST['total_amount']));
        } elseif (isset($_POST['tm_inquiry_total'])) {
            update_post_meta($post_id, 'tm_inquiry_total', sanitize_text_field($_POST['tm_inquiry_total']));
        }


        // Save Rejected Note
        // if (isset($_POST['custom_rejected_note'])) {
        //     update_post_meta($post_id, 'custom_rejected_note', sanitize_textarea_field($_POST['custom_rejected_note']));
        // }

        //Svae rejected & cancelled note
        if (isset($_POST['tm_cancelled_rejected_note'])) {
            update_post_meta($post_id, 'tm_cancelled_rejected_note', sanitize_textarea_field($_POST['tm_cancelled_rejected_note']));
        }

        // Send email if status changed to "accepted" or "rejected"
        if ($new_status === 'accepted' && $old_status !== 'accepted') {
            $this->send_status_accepted_email($post_id);
        } elseif
        (
            ($new_status === 'rejected' && $old_status !== 'rejected') ||
            ($new_status === 'cancelled' && $old_status !== 'cancelled')
        ) {
            $this->send_status_rejected_email($post_id);
        }


        // Save Payment Method
        if (isset($_POST['tm_cash_payment_method']) || isset($_POST['tm_online_payment_method'])) {
            $payment_method = isset($_POST['tm_cash_payment_method']) ? 'cash' : 'online';
            update_post_meta($post_id, 'tm_payment_method', $payment_method);
        } else {
            // Default to empty if no payment method is selected
            update_post_meta($post_id, 'tm_payment_method', '');
        }


    }

    private function send_status_accepted_email($post_id)
    {
        // Path to user Accepted email template
        $user_template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/send-to-user-emails/accepted-email-template.php';

        /** Send email to user (if template exists) */
        if (!file_exists($user_template_path))
            return;

        ob_start();
        include $user_template_path;

        // $email_content = ob_get_clean();

        // // Get recipient email
        // $email = get_post_meta($post_id, 'email', true);
        // $to = sanitize_email($email);
        // $subject = (get_post_meta($post_id, 'type', true) === 'inquiry')
        //     ? __('Your inquiry has been accepted', 'text-domain')
        //     : __('Your booking has been accepted', 'text-domain');

        // // Send email
        // $headers = ['Content-Type: text/html; charset=UTF-8'];
        // wp_mail($to, $subject, $email_content, $headers);



        // Path to admin Accepted email template
        $admin_template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/send-to-admin-emails/admin-accepted-email-template.php';

        /** Send email to admin (admin email setup setting page) */
        if (!file_exists($admin_template_path))
            return;

        ob_start();
        include $admin_template_path;




    }

    private function send_status_rejected_email($post_id)
    {
        // Path to user Rejected email template
        $user_template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/send-to-user-emails/rejected-email-template.php';

        /** Send email to user (if template exists) */
        if (!file_exists($user_template_path))
            return;

        ob_start();
        include $user_template_path;



        // Path to admin Rejected email template
        $admin_template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/send-to-admin-emails/admin-rejected-email-template.php';

        /** Send email to admin (admin email setup setting page) */
        if (!file_exists($admin_template_path))
            return;

        ob_start();
        include $admin_template_path;
    }


}
// Helper method to generate email content



// public function tm_handle_status_update()
// {
//     check_ajax_referer('update_inquiry_status', 'security');

//     if (!current_user_can('edit_posts')) {
//         wp_send_json_error(['message' => __('Permission denied.', 'text-domain')]);
//     }

//     $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
//     $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

//     if (!$post_id || !get_post($post_id)) {
//         wp_send_json_error(['message' => __('Invalid post ID.', 'text-domain')]);
//     }

//     if (!in_array($status, ['Pending', 'Accepted', 'Rejected'])) {
//         wp_send_json_error(['message' => __('Invalid status value.', 'text-domain')]);
//     }

//     // Get current status before updating
//     $current_status = get_post_meta($post_id, 'status', true);

//     // Update the status
//     $updated = update_post_meta($post_id, 'status', $status);

//     if (!$updated) {
//         wp_send_json_error(['message' => __('Failed to update status.', 'text-domain')]);
//     }

//     // Send email only if status changed to Accepted
//     if ($status === 'Accepted' && $current_status !== 'Accepted') {

//         // $this->send_status_email($post_id, $status);

//         // Load and send email using a template file
//         $template_path = plugin_dir_path(__FILE__) . '../../templates/email-templates/email-template.php';
//         if (file_exists($template_path)) {
//             ob_start();
//             include $template_path;
//             $email_content = ob_get_clean();

//             // Get email address from post meta
//             $email = get_post_meta($post_id, 'email', true);
//             $to = sanitize_email($email);

//             // Send the email
//             $subject = __('Your inquiry has been accepted', 'text-domain');
//             $headers = array('Content-Type: text/html; charset=UTF-8');

//             wp_mail($to, $subject, $email_content, $headers);
//             error_log("Email sent successfully to {$email}");
//         } else {
//             error_log("Email template file not found: {$template_path}");
//             wp_send_json_error(['message' => __('Email template not found.', 'text-domain')]);
//         }

//     }

//     // Clear any caching
//     clean_post_cache($post_id);
//     wp_cache_delete($post_id, 'post_meta');

//     wp_send_json_success([
//         'message' => __('Status updated successfully.', 'text-domain'),
//         'new_status' => $status,
//         'post_id' => $post_id
//     ]);
// }



