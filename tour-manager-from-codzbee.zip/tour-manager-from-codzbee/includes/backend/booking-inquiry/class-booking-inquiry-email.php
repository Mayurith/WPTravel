<?php

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}



/**
 * @class Inquiry_Email
 * @description Handles the email notifications for inquiries
 */
 class Booking_Inquiry_Email{



public function __construct(){
    
    add_action('wp_ajax_send_inquiry_email', array($this, 'send_inquiry_email'));

}


/**
 * @function send_inquiry_email
 * @description Sends an email with the inquiry details
 */
public function send_inquiry_email() {
    // Check if the request is an AJAX request
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        wp_send_json_error('Invalid request');
        return;
    }

    // Check if the required fields are set
    if (!isset($_POST['message_name']) || !isset($_POST['message_email']) || !isset($_POST['message_text'])) {
        wp_send_json_error('Missing required fields');
        return;
    }

    // Sanitize the input data
    $name = sanitize_text_field($_POST['message_name']);
    $email = sanitize_email($_POST['message_email']);
    $message = sanitize_textarea_field($_POST['message_text']);


    // Validate the email address
    if (!is_email($email)) {
        wp_send_json_error('Invalid email address');
        return;
    }


    // Prepare the email variables
    $to = get_option('admin_email');
    $subject = "New Inquiry from $name";
    $headers = 'From: ' . $email . "\r\n" .
        'Reply-To: ' . $email . "\r\n";

    // Prepare the email body
    $body = "You have received a new inquiry from $name.\n\n" .
        "Email: $email\n\n" .
        "Message:\n$message\n\n" .
        "This email was sent from the Inquiry form on your website.";

    // Send the email
    $sent = wp_mail($to, $subject, $body, $headers);
    
    // Check if the email was sent successfully
    if ($sent) {
        // Send a success response
        wp_send_json_success('Email sent successfully');
    } else {
        // Send an error response
        wp_send_json_error('Failed to send email');
    }
    // Exit to prevent further output
    wp_die();
}
}