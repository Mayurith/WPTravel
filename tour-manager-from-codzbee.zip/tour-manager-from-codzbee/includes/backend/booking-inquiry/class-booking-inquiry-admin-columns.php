<?php
/** includes/backend/booking-inquiry/class-booking-inquiry-admin-columns.php */

if (!defined('ABSPATH')) {
    exit;
}

class Booking_Inquiry_Admin_Columns
{
    public function __construct()
    {
        add_filter('manage_inquiry_posts_columns', [$this, 'tm_custom_inquiry_columns']);
        add_action('manage_inquiry_posts_custom_column', [$this, 'tm_custom_inquiry_columns_content'], 10, 2);
        add_filter('manage_edit-inquiry_sortable_columns', [$this, 'tm_sortable_columns']);
        add_action('pre_get_posts', [$this, 'tm_orderby_columns']);
        add_action('restrict_manage_posts', [$this, 'tm_add_filters']);
        add_filter('parse_query', [$this, 'tm_filter_query']);
    }

    public function tm_custom_inquiry_columns($columns)
    {
        $new_columns = [
            'cb' => $columns['cb'],
            'form_type' => 'Form Type',
            'full_name' => 'Full Name',
            'email' => 'Email',
            // 'phone' => 'Phone',
            'tour_info' => 'Tour Info',
            'arrival_date' => 'Arrival Date',
            'guests' => 'Guests',
            // 'total_price' => 'Total Price',
            'status' => 'Status',
            'date' => 'Date Submitted'
        ];
        return $new_columns;
    }

    public function tm_custom_inquiry_columns_content($column, $post_id)
    {
        ?>
        <style>
            .tm-status-pending{
                background-color: #eee8b2ff;
                color: #000;
                padding: 2px 6px;
                border-radius: 2px;
            }
            .tm-status-accepted{
                background-color: #afebb7ff;
                color: #000;
                padding: 2px 6px;
                border-radius: 2px;
            }
            .tm-status-rejected{
                background-color: #f1babaff;
                color: #000;
                padding: 2px 6px;
                border-radius: 2px;
            }
        </style>
        <?php
        switch ($column) {
            case 'form_type':
                $form_type = get_post_meta($post_id, 'form_type', true);
                echo '<span class="tm-badge tm-badge-' . esc_attr($form_type) . '">' . esc_html(ucfirst($form_type)) . '</span>';
                break;

            case 'full_name':
                echo esc_html(get_post_meta($post_id, 'full_name', true));
                break;

            case 'email':
                $email = get_post_meta($post_id, 'email', true);
                echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
                break;

            // case 'phone':
            //     echo esc_html(get_post_meta($post_id, 'phone', true));
            //     break;

            case 'tour_info':
                $form_type = get_post_meta($post_id, 'form_type', true);
                if ($form_type === 'booking') {
                    $tour_title = get_post_meta($post_id, 'tour_title', true);
                    $tour_id = get_post_meta($post_id, 'tour_id', true);
                    echo esc_html($tour_title) . ' (ID: ' . esc_html($tour_id) . ')';
                } else {
                    $tour_category = get_post_meta($post_id, 'tour_category', true);
                    echo 'Category: ' . esc_html($tour_category);
                }
                break;

            case 'arrival_date':
                $arrival_date = get_post_meta($post_id, 'arrival_date', true);
                echo $arrival_date ? esc_html($arrival_date) : '—';
                break;

            case 'guests':
                $adults = get_post_meta($post_id, 'adults', true);
                $children = get_post_meta($post_id, 'children', true);
                echo esc_html($adults) . ' Adults';
                if ($children) {
                    echo '<br>' . esc_html($children) . ' Children';
                }
                break;

            case 'status':
                $status = get_post_meta($post_id, 'status', true) ?: 'pending';
                $status_display = ucfirst($status);

                // Add CSS classes based on status
                $status_classes = [
                    'pending' => 'tm-status-pending',
                    'accepted' => 'tm-status-accepted',
                    'rejected' => 'tm-status-rejected',
                ];

                $class = isset($status_classes[$status]) ? $status_classes[$status] : '';

                echo '<span class="tm-status ' . esc_attr($class) . '">' . esc_html($status_display) . '</span>';
                break;

            // case 'total_price':
            //     $total_price = get_post_meta($post_id, 'total_price', true);
            //     if ($total_price) {
            //         echo 'USD ' . number_format($total_price, 2);
            //     } else {
            //         echo '—';
            //     }
            //     break;
        }
    }

    public function tm_sortable_columns($columns)
    {
        $columns['form_type'] = 'form_type';
        $columns['full_name'] = 'full_name';
        $columns['arrival_date'] = 'arrival_date';
        $columns['total_price'] = 'total_price';
        return $columns;
    }

    public function tm_orderby_columns($query)
    {
        if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== 'inquiry') {
            return;
        }

        $orderby = $query->get('orderby');

        switch ($orderby) {
            case 'form_type':
                $query->set('meta_key', 'form_type');
                $query->set('orderby', 'meta_value');
                break;

            case 'full_name':
                $query->set('meta_key', 'full_name');
                $query->set('orderby', 'meta_value');
                break;

            case 'arrival_date':
                $query->set('meta_key', 'arrival_date');
                $query->set('orderby', 'meta_value');
                break;

            case 'total_price':
                $query->set('meta_key', 'total_price');
                $query->set('orderby', 'meta_value_num');
                break;
        }
    }

    public function tm_add_filters($post_type)
    {
        if ($post_type !== 'inquiry')
            return;

        // Form Type Filter
        $current_form_type = isset($_GET['form_type_filter']) ? $_GET['form_type_filter'] : '';
        ?>
        <select name="form_type_filter">
            <option value="">All Form Types</option>
            <option value="booking" <?php selected($current_form_type, 'booking'); ?>>Booking</option>
            <option value="inquiry" <?php selected($current_form_type, 'inquiry'); ?>>Inquiry</option>
        </select>

        <?php
        // Tour Category Filter (for inquiry form)
        $current_category = isset($_GET['tour_category_filter']) ? $_GET['tour_category_filter'] : '';
        $tour_categories = get_terms(['taxonomy' => 'tour_category', 'hide_empty' => false]);
        ?>
        <select name="tour_category_filter">
            <option value="">All Categories</option>
            <?php foreach ($tour_categories as $category): ?>
                <option value="<?php echo esc_attr($category->slug); ?>" <?php selected($current_category, $category->slug); ?>>
                    <?php echo esc_html($category->name); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php
    }

    public function tm_filter_query($query)
    {
        if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== 'inquiry') {
            return;
        }

        $meta_query = [];

        // Form Type Filter
        if (!empty($_GET['form_type_filter'])) {
            $meta_query[] = [
                'key' => 'form_type',
                'value' => sanitize_text_field($_GET['form_type_filter']),
                'compare' => '='
            ];
        }

        // Tour Category Filter
        if (!empty($_GET['tour_category_filter'])) {
            $meta_query[] = [
                'key' => 'tour_category',
                'value' => sanitize_text_field($_GET['tour_category_filter']),
                'compare' => '='
            ];
        }

        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }
    }
}