<?php
/** includes/backend/inquiry/class-inquiry-admin-ui.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class Inquiry_Admin_UI
 */
class Booking_Inquiry_Admin_View_UI
{
    /**
     * @method __construct
     */
    public function __construct()
    {
        /** Hook for enqueing scripts and styles */
        add_action('admin_enqueue_scripts', [$this, 'tm_enqueue_assets']);
        /** Hook for show inquiry admin notices */
        add_action('admin_notices', [$this, 'tm_show_inquiry_notice']);
        /** Hook for add inquiry count bubble */
        add_action('admin_menu', [$this, 'tm_add_inquiry_count_bubble']);
        /** Hook for add dashboard widget */
        add_action('wp_dashboard_setup', [$this, 'tm_add_dashboard_widget']);
        /** Hook for add admin bar notifications */
        add_action('admin_bar_menu', [$this, 'tm_add_admin_bar_notification'], 999);
        /** Hook for add view action to posts */
        add_filter('post_row_actions', [$this, 'tm_add_view_action_to_posts'], 10, 2);
        /** Hook for add view option to posts */
        add_filter('page_row_actions', [$this, 'tm_add_view_action_to_posts'], 10, 2);

        add_action('admin_footer', [$this, 'tm_modal']);
        add_action('wp_ajax_get_inquiry_details', [$this, 'tm_handle_get_inquiry_details']);
        add_action('wp_ajax_update_inquiry_status', [$this, 'tm_handle_status_update']);
    }

    /**
     * Summary of enqueue_assets
     * @param mixed $hook
     * @return void
     */
    public function tm_enqueue_assets($hook)
    {
        /** Admin assets (only load on inquiry admin pages) */
        global $pagenow, $post_type;

        if (is_admin() && $pagenow === 'edit.php' && $post_type === 'inquiry') {
            /** Admin CSS */
            wp_enqueue_style(
                'tour-inquiry-admin-style',
                plugin_dir_url(__FILE__) . '../../../assets/css/inquiry-admin.css',
                array(),
                filemtime(plugin_dir_path(__FILE__) . '../../../assets/css/inquiry-admin.css')
            );
            wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');

            /** Enqueue jQuery UI for dialog (modal) */
            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_style('wp-jquery-ui-dialog');

            /** Admin JS */
            wp_enqueue_script(
                'tour-inquiry-admin-script',
                plugin_dir_url(__FILE__) . '../../../assets/js/inquiry-admin.js',
                array('jquery', 'jquery-ui-dialog'),
                filemtime(plugin_dir_path(__FILE__) . '../../../assets/js/inquiry-admin.js'),
                true
            );

            /** Localize admin script */
            wp_localize_script(
                'tour-inquiry-admin-script',
                'tourInquiryAdminData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('save_inquiry_security'),
                    'get_nonce' => wp_create_nonce('get_inquiry_nonce'),
                    'updating_text' => __('Updating...', 'text-domain'),
                    'success_text' => __('Status updated successfully!', 'text-domain'),
                    'error_text' => __('Error updating status', 'text-domain'),
                )
            );
        }
    }

    /**
     * Summary of tm_show_inquiry_notice
     * @return void
     */
    public function tm_show_inquiry_notice()
    {
        /**
         * @global mixed $pagenow
         */
        global $pagenow;

        // Only show on dashboard and edit.php pages
        if ($pagenow !== 'index.php' && $pagenow !== 'edit.php') {
            return;
        }

        $pending_count = wp_count_posts('inquiry')->pending;

        if ($pending_count > 0) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . sprintf(
                _n('You have %d new tour inquiry!', 'You have %d new tour inquiries!', $pending_count),
                $pending_count
            ) . ' <a href="' . admin_url('edit.php?post_type=inquiry') . '">View inquiries</a></p>';
            echo '</div>';
        }
    }

    /**
     * Summary of tm_add_inquiry_count_bubble
     * @return void
     */
    public function tm_add_inquiry_count_bubble()
    {
        /**
         * @global mixed $menu
         */
        global $menu;

        $pending_count = $this->tm_get_pending_inquiry_count();

        if ($pending_count > 0) {
            foreach ($menu as $key => $value) {
                if ($menu[$key][2] == 'main_menu_of_tour_manager') {
                    $menu[$key][0] .= ' <span class="update-plugins count-' . $pending_count . '">
                    <span class="plugin-count">' . $pending_count . '</span>
                </span>';
                }
            }
        }
    }

    /**
     * Summary of tm_add_dashboard_widget
     * @return void
     */
    public function tm_add_dashboard_widget()
    {
        wp_add_dashboard_widget(
            'tour_inquiries_widget',
            'Tour Inquiries',
            [$this, 'tm_render_dashboard_widget']
        );
    }

    /**
     * Summary of tm_render_dashboard_widget
     * @return void
     */
    public function tm_render_dashboard_widget()
    {
        $pending_count = $this->tm_get_pending_inquiry_count();
        $total_count = wp_count_posts('inquiry')->publish;

        echo '<div class="tour-inquiry-dashboard-widget">';
        echo '<p><strong>Pending Inquiries:</strong> ' . $pending_count . '</p>';
        echo '<p><strong>Total Inquiries:</strong> ' . $total_count . '</p>';
        echo '<p><a href="' . admin_url('edit.php?post_type=inquiry') . '">View All Inquiries</a></p>';
        echo '</div>';
    }

    /**
     * Summary of add_admin_bar_notification
     * @param mixed $admin_bar
     * @return void
     */
    public function tm_add_admin_bar_notification($admin_bar)
    {
        $pending_count = $this->tm_get_pending_inquiry_count();

        if ($pending_count > 0 && current_user_can('manage_options')) {
            $admin_bar->add_menu(array(
                'id' => 'tour-inquiries-notification',
                'title' => sprintf(
                    '<span class="ab-icon dashicons dashicons-email-alt"></span>
                    <span class="ab-label">%d</span>',
                    $pending_count
                ),
                'href' => admin_url('edit.php?post_type=inquiry'),
                'meta' => array(
                    'title' => sprintf(
                        _n('%d pending tour inquiry', '%d pending tour inquiries', $pending_count),
                        $pending_count
                    ),
                ),
            ));
        }
    }

    /**
     * Summary of tm_admin_bar_css
     * @return void
     */
    public function tm_admin_bar_css()
    {
        echo '<style>
            #wpadminbar #wp-admin-bar-tour-inquiries-notification .ab-icon:before {
                content: "\f466";
                top: 2px;
            }
        </style>';
    }

    /**
     * Summary of add_view_action_to_posts
     * @param mixed $actions
     * @param mixed $post
     */
    public function tm_add_view_action_to_posts($actions, $post)
    {
        if ($post->post_type === 'inquiry') {
            $form_type = get_post_meta($post->ID, 'form_type', true) ?: 'inquiry';
            $actions['view_details'] = sprintf(
                '<a href="#" class="view-inquiry-details" data-id="%d" data-type="%s" title="%s">%s</a>',
                $post->ID,
                esc_attr($form_type),
                esc_attr__('View Inquiry Details', 'text-domain'),
                esc_html__('View Details', 'text-domain')
            );
        }
        return $actions;
    }

    /**
     * Summary of tm_get_pending_inquiry_count
     */
    private function tm_get_pending_inquiry_count()
    {
        return wp_count_posts('inquiry')->pending;
    }

    /**
     * Handle AJAX request to get inquiry details
     */
    public function tm_handle_get_inquiry_details()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['security'], 'get_inquiry_nonce')) {
            wp_send_json_error('Security check failed');
        }

        $post_id = intval($_POST['post_id']);
        $tour_id = get_post_meta($post_id, 'tour_id', true);


        if (!$post_id) {
            wp_send_json_error('Invalid post ID');
        }

        // Get all post meta
        $post_meta = get_post_meta($post_id);

        // Prepare response data
        $data = array(
            'inquiry_id' => $tour_id ? $tour_id : $post_id,
            'form_type' => isset($post_meta['form_type'][0]) ? $post_meta['form_type'][0] : 'inquiry',
            'status' => isset($post_meta['status'][0]) ? $post_meta['status'][0] : 'pending',
            'name' => isset($post_meta['full_name'][0]) ? $post_meta['full_name'][0] : '',
            'email' => isset($post_meta['email'][0]) ? $post_meta['email'][0] : '',
            'phone' => isset($post_meta['phone'][0]) ? $post_meta['phone'][0] : '',
            'country' => isset($post_meta['country'][0]) ? $post_meta['country'][0] : '',
            'message' => isset($post_meta['message'][0]) ? $post_meta['message'][0] : '',
            'adult_count' => isset($post_meta['adults'][0]) ? $post_meta['adults'][0] : '0',
            'child_count' => isset($post_meta['children'][0]) ? $post_meta['children'][0] : '0',
            'arrival_date' => isset($post_meta['arrival_date'][0]) ? $post_meta['arrival_date'][0] : '',
            'tour_category' => isset($post_meta['tour_category'][0]) ? $post_meta['tour_category'][0] : '',
            'tour_title' => isset($post_meta['tour_title'][0]) ? $post_meta['tour_title'][0] : '',
            // 'total_amount' => isset($post_meta['total_price'][0]) ? $post_meta['total_price'][0] : '',
            'post_date' => get_the_date('Y-m-d H:i:s', $post_id)
        );

        wp_send_json_success($data);
    }

    public function tm_modal()
    {
        ?>
        <div id="inquiry-details-modal" style="display:none;" title="Inquiry Details">
            <div class="inquiry-modal-content">
                <div class="modal-header">
                    <div class="modal-title-section">
                        <h3 id="modal-title">Inquiry Details</h3>
                        <span id="modal-status" class="status-badge"></span>
                    </div>
                    <div class="modal-meta">
                        <span id="modal-date" class="modal-date"></span>
                        <span id="modal-id" class="modal-id"></span>
                    </div>
                </div>

                <div class="modal-columns">
                    <div class="column customer-column">
                        <h4><i class="fas fa-user"></i> Customer Details</h4>
                        <div class="detail-group">
                            <div class="detail-item">
                                <label>Name:</label>
                                <span id="modal-customer-name"></span>
                            </div>
                            <div class="detail-item">
                                <label>Email:</label>
                                <span id="modal-customer-email"></span>
                            </div>
                            <div class="detail-item">
                                <label>Phone:</label>
                                <span id="modal-customer-phone"></span>
                            </div>
                            <div class="detail-item">
                                <label>Country:</label>
                                <span id="modal-customer-country"></span>
                            </div>
                        </div>
                    </div>

                    <div class="column booking-column">
                        <h4><i class="fas fa-calendar-alt"></i> Booking Details</h4>
                        <div class="detail-group">
                            <div class="detail-item">
                                <label>Type:</label>
                                <span id="modal-booking-type"></span>
                            </div>
                            <div class="detail-item" id="modal-tour-item">
                                <label id="modal-tour-label">Tour:</label>
                                <span id="modal-tour-value"></span>
                            </div>
                            <div class="detail-item">
                                <label>Arrival Date:</label>
                                <span id="modal-arrival-date"></span>
                            </div>
                            <div class="detail-item">
                                <label>Guests:</label>
                                <span id="modal-guests"></span>
                            </div>
                            <!-- <div class="detail-item" id="modal-amount-item" style="display:none;">
                                <label>Total Amount:</label>
                                <span id="modal-total-amount"></span>
                            </div> -->
                        </div>
                    </div>
                </div>

                <div class="message-section">
                    <h4><i class="fas fa-comment"></i> Message</h4>
                    <div class="message-content" id="modal-message-content">
                        <p id="modal-message-text"></p>
                    </div>
                </div>

                <div class="modal-actions">
                    <div class="status-actions">
                        <button type="button" id="accept-inquiry" class="button button-primary status-btn accept-btn"
                            data-status="accepted">
                            <i class="fas fa-check"></i> Accept
                        </button>
                        <button type="button" id="reject-inquiry" class="button button-secondary status-btn reject-btn"
                            data-status="rejected">
                            <i class="fas fa-times"></i> Reject
                        </button>
                    </div>
                    <div class="action-buttons">
                        <button type="button" id="close-modal" class="button">Close</button>
                        <!-- <a href="#" id="edit-inquiry" class="button button-primary">
                            <i class="fas fa-edit"></i> Edit
                        </a> -->
                    </div>
                </div>
            </div>
        </div>

        <style>
            .inquiry-modal-content {
                padding: 20px;
            }

            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 20px;
                padding-bottom: 15px;
                border-bottom: 1px solid #ddd;
            }

            .modal-title-section h3 {
                margin: 0 0 5px 0;
                color: #1d2327;
            }

            .status-badge {
                padding: 4px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }

            .status-badge.pending {
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffeaa7;
            }

            .status-badge.accepted {
                background: #d1ecf1;
                color: #0c5460;
                border: 1px solid #bee5eb;
            }

            .status-badge.rejected {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }

            .modal-meta {
                text-align: right;
                font-size: 12px;
                color: #666;
            }

            .modal-columns {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 20px;
            }

            .column h4 {
                margin: 0 0 15px 0;
                color: #1d2327;
                font-size: 16px;
            }

            .column h4 i {
                margin-right: 8px;
                color: #0073aa;
            }

            .detail-group {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 5px;
            }

            .detail-item {
                display: flex;
                justify-content: space-between;
                margin-bottom: 10px;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
            }

            .detail-item:last-child {
                margin-bottom: 0;
                padding-bottom: 0;
                border-bottom: none;
            }

            .detail-item label {
                font-weight: 600;
                color: #555;
            }

            .detail-item span {
                color: #333;
                text-align: right;
            }

            .message-section {
                margin-bottom: 20px;
            }

            .message-section h4 {
                margin: 0 0 10px 0;
                color: #1d2327;
            }

            .message-section h4 i {
                margin-right: 8px;
                color: #0073aa;
            }

            .message-content {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 5px;
                max-height: 150px;
                overflow-y: auto;
            }

            .modal-actions {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding-top: 15px;
                border-top: 1px solid #ddd;
            }

            .status-actions {
                display: flex;
                gap: 10px;
            }

            .status-btn {
                display: flex;
                align-items: center;
                gap: 5px;
            }

            .accept-btn {
                background: #28a745;
                border-color: #28a745;
            }

            .accept-btn:hover {
                background: #218838;
                border-color: #1e7e34;
            }

            .reject-btn {
                background: #dc3545;
                border-color: #dc3545;
            }

            .reject-btn:hover {
                background: #c82333;
                border-color: #bd2130;
            }

            .action-buttons {
                display: flex;
                gap: 10px;
            }

            .ui-dialog {
                z-index: 100000 !important;
            }

            .ui-dialog-titlebar {
                background: #f1f1f1 !important;
                border-bottom: 1px solid #ddd !important;
            }
        </style>

        <script>
            jQuery(document).ready(function ($) {
                let currentInquiryId = null;
                let currentStatus = 'pending';

                // Open modal when view details is clicked
                $(document).on('click', '.view-inquiry-details', function (e) {
                    e.preventDefault();
                    currentInquiryId = $(this).data('id');
                    const formType = $(this).data('type');

                    // Show loading state
                    $('#inquiry-details-modal').dialog({
                        modal: true,
                        width: 800,
                        height: 'auto',
                        resizable: false,
                        title: 'Loading Inquiry Details...',
                        open: function () {
                            $(this).dialog('option', 'title', 'Loading...');
                        }
                    });

                    // Fetch inquiry details via AJAX
                    $.ajax({
                        url: tourInquiryAdminData.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'get_inquiry_details',
                            post_id: currentInquiryId,
                            security: tourInquiryAdminData.get_nonce
                        },
                        success: function (response) {
                            if (response.success) {
                                const data = response.data;
                                currentStatus = data.status;

                                // Update modal title
                                const title = data.form_type === 'booking' ? 'Booking Details' : 'Inquiry Details';
                                $('#inquiry-details-modal').dialog('option', 'title', title);

                                // Update status badge
                                $('#modal-status')
                                    .text(data.status.charAt(0).toUpperCase() + data.status.slice(1))
                                    .removeClass('pending accepted rejected')
                                    .addClass(data.status);

                                // Update dates and IDs
                                $('#modal-date').text('Submitted: ' + data.post_date);
                                $('#modal-id').text('ID: #' + data.inquiry_id);

                                // Update customer details
                                $('#modal-customer-name').text(data.name || 'Not provided');
                                $('#modal-customer-email').text(data.email || 'Not provided');
                                $('#modal-customer-phone').text(data.phone || 'Not provided');
                                $('#modal-customer-country').text(data.country || 'Not provided');

                                // Update booking details
                                $('#modal-booking-type').text(data.form_type.charAt(0).toUpperCase() + data.form_type.slice(1));

                                if (data.form_type === 'booking') {
                                    $('#modal-tour-label').text('Tour:');
                                    $('#modal-tour-value').text(data.tour_title || 'Not specified');
                                    $('#modal-amount-item').show();
                                    // $('#modal-total-amount').text(data.total_amount ? '$' + data.total_amount : 'Not specified');
                                } else {
                                    $('#modal-tour-label').text('Category:');
                                    $('#modal-tour-value').text(data.tour_category || 'Not specified');
                                    $('#modal-amount-item').hide();
                                }

                                $('#modal-arrival-date').text(data.arrival_date || 'Not specified');
                                $('#modal-guests').text('Adults: ' + data.adult_count + ', Children: ' + data.child_count);

                                // Update message
                                const messageText = data.message || 'No message provided';
                                $('#modal-message-text').text(messageText);

                                // Update edit link
                                $('#edit-inquiry').attr('href', '<?php echo admin_url('post.php?post='); ?>' + currentInquiryId + '&action=edit');

                                // Update button visibility based on status
                                updateButtonVisibility(data.status);
                            } else {
                                alert('Error loading inquiry details');
                                $('#inquiry-details-modal').dialog('close');
                            }
                        },
                        error: function () {
                            alert('Error loading inquiry details');
                            $('#inquiry-details-modal').dialog('close');
                        }
                    });
                });

                // Update button visibility based on status
                function updateButtonVisibility(status) {
                    if (status === 'pending') {
                        $('.status-btn').show();
                    } else {
                        $('.status-btn').hide();
                    }
                }

                // Handle status changes
                $('.status-btn').on('click', function () {
                    const newStatus = $(this).data('status');
                    const action = newStatus === 'accepted' ? 'accept' : 'reject';

                    if (!confirm('Are you sure you want to ' + action + ' this inquiry?')) {
                        return;
                    }

                    const $button = $(this);
                    $button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');

                    $.ajax({
                        url: tourInquiryAdminData.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'update_inquiry_status',
                            post_id: currentInquiryId,
                            status: newStatus,
                            security: tourInquiryAdminData.nonce
                        },
                        success: function (response) {
                            if (response.success) {
                                // Update UI
                                currentStatus = newStatus;
                                $('#modal-status')
                                    .text(newStatus.charAt(0).toUpperCase() + newStatus.slice(1))
                                    .removeClass('pending accepted rejected')
                                    .addClass(newStatus);

                                updateButtonVisibility(newStatus);
                                alert('Status updated successfully!');
                            } else {
                                alert('Error updating status: ' + (response.data.message || 'Unknown error'));
                            }
                            $button.prop('disabled', false).html('<i class="fas fa-' + (newStatus === 'accepted' ? 'check' : 'times') + '"></i> ' + (newStatus === 'accepted' ? 'Accept' : 'Reject'));
                        },
                        error: function () {
                            alert('Error updating status');
                            $button.prop('disabled', false).html('<i class="fas fa-' + (newStatus === 'accepted' ? 'check' : 'times') + '"></i> ' + (newStatus === 'accepted' ? 'Accept' : 'Reject'));
                        }
                    });
                });

                // Close modal
                $('#close-modal').on('click', function () {
                    $('#inquiry-details-modal').dialog('close');
                });

                // Close modal when clicking outside
                $(document).on('click', '.ui-widget-overlay', function () {
                    $('#inquiry-details-modal').dialog('close');
                });
            });
        </script>
        <?php
    }

    public function tm_handle_status_update()
    {
        check_ajax_referer('save_inquiry_security', 'security');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Permission denied.', 'text-domain')]);
        }

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if (!$post_id || !get_post($post_id)) {
            wp_send_json_error(['message' => __('Invalid post ID.', 'text-domain')]);
        }

        if (!in_array($status, ['pending', 'accepted', 'rejected'])) {
            wp_send_json_error(['message' => __('Invalid status value.', 'text-domain')]);
        }

        // Update the status
        $updated = update_post_meta($post_id, 'status', $status);

        if (!$updated) {
            wp_send_json_error(['message' => __('Failed to update status.', 'text-domain')]);
        }

        // Clear any caching
        clean_post_cache($post_id);
        wp_cache_delete($post_id, 'post_meta');

        wp_send_json_success([
            'message' => __('Status updated successfully.', 'text-domain'),
            'new_status' => $status
        ]);
    }
}
