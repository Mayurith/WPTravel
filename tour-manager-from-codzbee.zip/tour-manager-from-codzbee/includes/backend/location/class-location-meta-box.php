<?php
/** includes/backend/location/class-location-meta-box.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

class Location_Meta_Box
{
    /**
     * @method __construct
     */
    public function __construct()
    {
        /** Hook for add meta box */
        add_action('add_meta_boxes', array($this, 'tm_add_location_meta_box'));
        /** Hook for save meta box data */
        add_action('save_post_location', array($this, 'tm_save_location_meta'));

        /** Hook for manage meta data column */
        add_filter('manage_location_posts_columns', array($this, 'tm_set_custom_edit_location_columns'));
        add_action('manage_location_posts_custom_column', [$this, 'tm_custom_location_column'], 10, 2);

        /** Hook for enqueue scripts and styles */
        add_action('admin_enqueue_scripts', array($this, 'tm_enqueue_location_scripts_and_styles'));

        /** AJAX hooks for getting cities by country */
        add_action('wp_ajax_get_cities_by_country_for_location', array($this, 'tm_get_cities_by_country_ajax'));
        add_action('wp_ajax_nopriv_get_cities_by_country_for_location', array($this, 'tm_get_cities_by_country_ajax'));

        /** Hook for add featured image size */
        add_image_size('add_featured_images', 120, 140, true);

        /** Hook for add location filter : Location type, Country & City */
        add_action('restrict_manage_posts', array($this, 'tm_add_location_filter_dropdowns'));
        add_filter('parse_query', array($this, 'tm_add_location_filter'));
    }

    /**
     * @function tm_add_location_meta_box
     * @description Add meta box for location post type
     * @return void
     */
    public function tm_add_location_meta_box()
    {
        /** Check if location post type exists */
        if (!post_type_exists('location')) {
            return;
        }

        add_meta_box(
            'location_details',
            __('Location Details', 'tour-manager'),
            array($this, 'tm_render_location_details_meta_box'),
            'location',
            'normal',
            'default'
        );

        add_meta_box(
            '_location_image_gallery',
            'Location Image Gallery',
            [$this, 'tm_add_custom_meta_box_for_location_gallery'],
            'location',
            'normal',
            'high'
        );

        /** add meta box to mark as a top sight */
        add_meta_box(
            'top_sight_details',
            __('Top Sight Details', 'tour-manager'),
            array($this, 'tm_render_top_sight_meta_box'),
            'location',
            'side',
            'default'
        );

        /** add meta box to fetch latitude and longitude */
        add_meta_box(
            'location_coordinates',
            __('Location Coordinates', 'tour-manager'),
            array($this, 'tm_render_location_coordinates_meta_box'),
            'location',
            'normal',
            'default'
        );
    }

    public function tm_render_location_details_meta_box($post)
    {
        /** Security nonce field */
        wp_nonce_field('save_location_data', 'location_meta_nonce');
        wp_nonce_field('tm_location_meta_box_city_nonce_action', 'tm_location_meta_box_city_nonce');

        /** Get saved values */
        $location_type = get_post_meta($post->ID, '_location_type', true);
        $location_country = get_post_meta($post->ID, '_location_country', true);
        $location_city = get_post_meta($post->ID, '_location_city', true);

        /** Get all countries from city posts */
        $countries = $this->tm_get_all_countries();

        // Get cities based on selected country
        $cities = array();
        if (!empty($location_country)) {
            $cities = $this->tm_get_cities_by_country($location_country);
        }

        include plugin_dir_path(__FILE__) . '../../templates/location-metabox/location-meta-box.php';
    }

    /**
     * @function    : tm_get_all_countries()
     * @description : Returns all unique countries from city meta
     */
    private function tm_get_all_countries()
    {
        global $wpdb;

        $results = $wpdb->get_col("
            SELECT DISTINCT meta_value 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_city_country' 
            AND meta_value != ''
            ORDER BY meta_value ASC
        ");

        return $results;
    }

    /**
     * @function    : tm_get_cities_by_country()
     * @description : Returns all cities for a specific country
     * @param       : string $country - The country name
     * @return      : array of city posts
     */
    private function tm_get_cities_by_country($country)
    {
        $args = array(
            'post_type' => 'city',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_city_country',
                    'value' => $country,
                    'compare' => '='
                )
            ),
            'orderby' => 'title',
            'order' => 'ASC'
        );

        return get_posts($args);
    }

    /**
     * @function    : tm_get_all_cities()
     * @description : Returns all cities with their IDs and titles
     */
    private function tm_get_all_cities()
    {
        $cities = get_posts(array(
            'post_type' => 'city',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ));

        $city_list = array();
        foreach ($cities as $city) {
            $city_list[] = array(
                'id' => $city->ID,
                'title' => $city->post_title
            );
        }

        return $city_list;
    }

    /**
     * @function    : tm_add_custom_meta_box_for_location_gallery()
     * @description : location gallery meta box
     */
    public function tm_add_custom_meta_box_for_location_gallery($post)
    {
        // Get saved gallery images
        $location_gallery = get_post_meta($post->ID, '_location_gallery', true);
        $gallery_ids = !empty($location_gallery) ? explode(',', $location_gallery) : array();

        // Security nonce
        wp_nonce_field('save_gallery_data', 'gallery_meta_nonce');

        include plugin_dir_path(__FILE__) . '../../templates/location-metabox/location-gallery-meta-box.php';
    }


    /**
     * @function    : tm_render_top_sight_meta_box
     * @description : top sight meta box
     */
    public function tm_render_top_sight_meta_box($post)
    {
        $is_top_sight = get_post_meta($post->ID, '_is_top_sight', true);
        include plugin_dir_path(__FILE__) . '../../templates/location-metabox/top-sight-meta-box.php';
    }

    /**
     * @function    : tm_render_location_coordinates_meta_box
     * @description : location coordinates meta box
     */
    public function tm_render_location_coordinates_meta_box($post)
    {

        $location = get_post_meta($post->ID, '_location_name', true);
        $lat = get_post_meta($post->ID, '_location_lat', true);
        $lng = get_post_meta($post->ID, '_location_lng', true);

        // wp_nonce_field('save_location_meta', 'location_meta_nonce');
        include plugin_dir_path(__FILE__) . '../../templates/location-metabox/location-coordinates-meta-box.php';
    }



    /**
     * @function tm_save_location_meta
     * @description Save meta box data
     * @param $post_id
     * @return void 
     */
    public function tm_save_location_meta($post_id)
    {
        /** Verify Nonce */
        if (
            !isset($_POST['tm_location_meta_box_city_nonce']) ||
            !wp_verify_nonce($_POST['tm_location_meta_box_city_nonce'], 'tm_location_meta_box_city_nonce_action') ||
            !isset($_POST['location_meta_nonce']) ||
            !wp_verify_nonce($_POST['location_meta_nonce'], 'save_location_data') ||
            !isset($_POST['gallery_meta_nonce']) ||
            !wp_verify_nonce($_POST['gallery_meta_nonce'], 'save_gallery_data')
        ) {
            return;
        }

        /** Don't save on autosave */
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        /** Check permissions */
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        /** Save country */
        if (isset($_POST['tm_location_country'])) {
            update_post_meta($post_id, '_location_country', sanitize_text_field($_POST['tm_location_country']));
        }

        /** Save city */
        if (isset($_POST['tm_location_city'])) {
            update_post_meta($post_id, '_location_city', sanitize_text_field($_POST['tm_location_city']));
        }

        /** Save location type */
        if (isset($_POST['location_type'])) {
            update_post_meta($post_id, '_location_type', sanitize_text_field($_POST['location_type']));
        }

        /** Save is top sight */
        if (isset($_POST['tm_top_site'])) {
            update_post_meta($post_id, '_is_top_sight', sanitize_text_field($_POST['tm_top_site']));
        }

        /** Save location name */
        if (isset($_POST['location_name'])) {
            update_post_meta($post_id, '_location_name', sanitize_text_field($_POST['location_name']));
        }
        /** Save latitude */
        if (isset($_POST['location_lat'])) {
            update_post_meta($post_id, '_location_lat', sanitize_text_field($_POST['location_lat']));
        }
        /** Save longitude */
        if (isset($_POST['location_lng'])) {
            update_post_meta($post_id, '_location_lng', sanitize_text_field($_POST['location_lng']));
        }

        /** Save Image Gallery */
        if (isset($_POST['tm_location_gallery'])) {
            // Sanitize the comma-separated string of image IDs
            $gallery_ids = sanitize_text_field($_POST['tm_location_gallery']);
            update_post_meta($post_id, '_location_gallery', $gallery_ids);
        } else {
            // If no gallery images, save empty string
            update_post_meta($post_id, '_location_gallery', '');
        }
    }

    /**
     * @function tm_set_custom_edit_location_columns()
     * @description Add custom columns to the location post type list
     */
    public function tm_set_custom_edit_location_columns($columns)
    {
        $new_columns = array(
            'country' => 'Country',
            'city' => 'City',
            'location_type' => 'Location Type',
            'featured_image' => 'Featured Image',
        );

        /** Insert after title column */
        $offset = array_search('title', array_keys($columns)) + 1;
        $columns = array_merge(
            array_slice($columns, 0, $offset),
            $new_columns,
            array_slice($columns, $offset)
        );

        return $columns;
    }

    /**
     * @function tm_custom_location_column()
     * @description Populate the custom columns with data
     */
    public function tm_custom_location_column($column, $post_id)
    {
        switch ($column) {
            case 'featured_image':
                if (has_post_thumbnail($post_id)) {
                    echo get_the_post_thumbnail($post_id, 'add_featured_images');
                }
                break;
            case 'country':
                echo get_post_meta($post_id, '_location_country', true);
                break;
            case 'city':
                $city_id = get_post_meta($post_id, '_location_city', true);
                if (!empty($city_id)) {
                    $city_post = get_post($city_id);
                    if ($city_post) {
                        echo esc_html($city_post->post_title);
                    }
                }
                break;
            case 'location_type':
                $location_type = get_post_meta($post_id, '_location_type', true);
                echo $location_type ? esc_html($location_type) : '—';
                break;
        }
    }

    /**
     * @function    : tm_get_cities_by_country_ajax()
     * @description : AJAX handler to get cities by country
     */
    public function tm_get_cities_by_country_ajax()
    {
        // Verify nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'location_city_nonce')) {
            wp_send_json_error('Security check failed');
        }

        if (!isset($_POST['country']) || empty($_POST['country'])) {
            wp_send_json_error('No country specified');
        }

        $country = sanitize_text_field($_POST['country']);
        $cities = $this->tm_get_cities_by_country($country);

        $options = '<option value="">' . __('Select a City', 'text-domain') . '</option>';
        foreach ($cities as $city) {
            $options .= '<option value="' . esc_attr($city->ID) . '">' . esc_html($city->post_title) . '</option>';
        }

        wp_send_json_success($options);
    }

    /**
     * @function tm_add_location_filter_dropdowns
     * @description Add dropdowns for location type, country and city in admin filter
     */
    public function tm_add_location_filter_dropdowns($post_type)
    {
        if ($post_type !== 'location') {
            return;
        }

        $location_types = array('Activity', 'Attraction');
        $selected_type = isset($_GET['location_type']) ? sanitize_text_field($_GET['location_type']) : '';
        $selected_country = isset($_GET['location_country']) ? sanitize_text_field($_GET['location_country']) : '';
        $selected_city = isset($_GET['location_city']) ? sanitize_text_field($_GET['location_city']) : '';

        // Get all countries and cities for filters
        $countries = $this->tm_get_all_countries();
        $cities = $this->tm_get_all_cities();

        /** Location Type Dropdown */
        echo '<select name="location_type" id="location_type" class="postform">';
        echo '<option value="">All Types</option>';
        foreach ($location_types as $type) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($type),
                selected($selected_type, $type, false),
                esc_html($type)
            );
        }
        echo '</select>';

        /** Country Dropdown */
        echo '<select name="location_country" id="location_country" class="postform">';
        echo '<option value="">All Countries</option>';
        foreach ($countries as $country) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($country),
                selected($selected_country, $country, false),
                esc_html($country)
            );
        }
        echo '</select>';

        /** City Dropdown */
        echo '<select name="location_city" id="location_city" class="postform">';
        echo '<option value="">All Cities</option>';
        foreach ($cities as $city) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($city['id']),
                selected($selected_city, $city['id'], false),
                esc_html($city['title'])
            );
        }
        echo '</select>';
    }

    /**
     * @function tm_add_location_filter
     * @description Add custom filters for location type, country and city
     */
    public function tm_add_location_filter($query)
    {
        global $pagenow, $post_type;

        if ($pagenow === 'edit.php' && $post_type === 'location') {
            $meta_query = array();

            // Filter by location type
            if (!empty($_GET['location_type'])) {
                $meta_query[] = array(
                    'key' => '_location_type',
                    'value' => sanitize_text_field($_GET['location_type']),
                    'compare' => '='
                );
            }

            // Filter by country
            if (!empty($_GET['location_country'])) {
                $meta_query[] = array(
                    'key' => '_location_country',
                    'value' => sanitize_text_field($_GET['location_country']),
                    'compare' => '='
                );
            }

            // Filter by city
            if (!empty($_GET['location_city'])) {
                $meta_query[] = array(
                    'key' => '_location_city',
                    'value' => sanitize_text_field($_GET['location_city']),
                    'compare' => '='
                );
            }

            // Apply meta query if any filters are set
            if (!empty($meta_query)) {
                // If multiple filters, set relation to AND
                if (count($meta_query) > 1) {
                    $meta_query['relation'] = 'AND';
                }
                $query->set('meta_query', $meta_query);
            }
        }
    }

    /**
     * @function tm_enqueue_location_scripts_and_styles
     * @description Enqueue scripts and styles for location meta box
     */
    public function tm_enqueue_location_scripts_and_styles()
    {
        if (!is_admin()) {
            return;
        }

        $screen = get_current_screen();

        /** Enqueue for location post type */
        if ($screen && $screen->post_type === 'location') {
            /** Enqueue WordPress media uploader scripts */
            wp_enqueue_media();

            wp_enqueue_script(
                'location-manager-script',
                plugin_dir_url(__FILE__) . '../../../assets/js/location.js',
                array('jquery', 'media-upload'),
                null,
                true
            );

            wp_localize_script('location-manager-script', 'location_manager', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('location_city_nonce'),
                'title' => __('Select Gallery Images', 'tour-manager'),
                'button_text' => __('Add to Gallery', 'tour-manager'),
                'no_images' => __('No gallery images selected.', 'tour-manager')
            ));

            wp_enqueue_style(
                'location-manager-style',
                plugin_dir_url(__FILE__) . '../../../assets/css/location-admin.css',
                array(),
                1,
                'all'
            );

            wp_enqueue_script(
                'google-maps-api',
                'https://maps.googleapis.com/maps/api/js?key=AIzaSyBrlErC7_iaeM_C3dM8-GKTVysbqNSXNNE&libraries=places',
                array(),
                null,
                true
            );

        }
    }
}