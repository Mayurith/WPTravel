<?php
/** includes/backend/location/class-location-post-type.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}


/**
 * @class Location_Post_Type
 * @description Create class for register custom post type : location
 */
class Location_Post_Type
{

  /**
   * @method __construct
   */
  public function __construct()
  {
    /** Hook for register custom post type : location */
    add_action('init', array($this, 'tm_register_location_post_type'));
    add_theme_support('post-thumbnails');

  }


  /**
   * @function register_post_type
   * @return void
   */
  public function tm_register_location_post_type()
  {
    $args = array(
      'labels' => array(
        'name' => 'Locations',
        'add_new' => 'Add New Location',
        'add_new_item' => 'Add New Location',
        'edit_item' => 'Edit Location',
        'search_items' => 'Search Location'
      ),
      'public' => true,
      'has_archive' => true,
      'rewrite' => ['slug' => 'location'],
      'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
      'show_ui' => true,
      'show_in_menu' => 'main_menu_of_tour_manager' /** Add to the "Tour Manager" main menu */
    );
    register_post_type('location', $args);
  }

}