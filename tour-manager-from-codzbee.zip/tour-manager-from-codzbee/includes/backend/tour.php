<?php
/** includes/backend/tour.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}


/** Load dependencies */
require_once plugin_dir_path(__FILE__) . 'tour/class-tour-post-type.php';
require_once plugin_dir_path(__FILE__) . 'tour/class-tour-meta-box.php';



/**
 * @class Tour
 * @description All tour details include this class.
 */

class Tour
{

   private $tm_tour_post_type;
  private $tm_tour_meta_box;

  public function __construct()
  {
    $this->tm_tour_post_type = new Tour_Post_Type();
    $this->tm_tour_meta_box = new Tour_Meta_Box();

  }
}
