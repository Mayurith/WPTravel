<?php
/** includes/backend/tour/class-tour-post-type.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}


/**
 * @class Location_Post_Type
 * @description Create class for register custom post type : tour
 */
class Tour_Post_Type
{

    /**
     * @method __construct
     */
    public function __construct()
    {
        /** Hook for register custom post type : tour */
        add_action('init', array($this, 'tm_register_tour_post_type'));
        add_theme_support('post-thumbnails');
    }



    /**
     * @function tm_register_tour_post_type()
     * @description tour post type callback 
     */
    public function tm_register_tour_post_type()
    {

        $args = array(
            'labels' => array(
                'name' => 'Tours',
                'add_new' => 'Add New Tour',
                'add_new_item' => 'Add New Tour',
                'edit_item' => 'Edit Tour',
                'search_items' => 'Search Tour',
                'new_item' => 'New Tour',
                'view_item' => 'View Tour',
                'not_found' => 'No Tours found',
                'not_found_in_trash' => 'No Tours found in Trash',
            ),
            'public' => true,
            'rewrite' => ['slug' => 'tour'],
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'show_ui' => true,
            'show_in_menu' => 'main_menu_of_tour_manager' /** Add to the "Tour Manager" main menu */
        );
        register_post_type('tour', $args);

    }

}