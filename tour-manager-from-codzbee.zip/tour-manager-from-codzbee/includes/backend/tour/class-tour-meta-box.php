<?php
/** includes/backend/tour/class-tour-meta-box.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

class Tour_Meta_Box
{

    /**
     * @method __construct
     */
    public function __construct()
    {

        /** Hook for add meta box */
        add_action('add_meta_boxes', array($this, 'tm_add_meta_box'));
        /** Hook for save meta data */
        add_action('save_post_tour', array($this, 'tm_save_tour_meta'));

        /** Hook for manage meta data column */
        add_filter('manage_tour_posts_columns', array($this, 'tm_add_tour_columns'));
        /** Hook for manage meta data */
        add_action('manage_tour_posts_custom_column', array($this, 'tm_populate_tour_columns'), 10, 2);

        /** Hook for enqueue Script and Styles (backend) */
        add_action('admin_enqueue_scripts', array($this, 'tm_enqueue_script_and_styles'));
        add_action('wp_enqueue_scripts', array($this, 'tm_enqueue_frontend_scripts'));

        /** Hook for add Category filter field in admin column page */
        add_action('restrict_manage_posts', array($this, 'filter_tours_by_category'));
        add_filter('parse_query', array($this, 'filter_tours_query_by_category'));


        add_action('wp_ajax_fetch_city_activities', [$this, 'fetch_city_activities']);
        add_action('wp_ajax_fetch_day_hotels', [$this, 'fetch_day_hotels']);
    }


    /**
     * @function tm_add_meta_box()
     * @description Add Tour meta box callback
     */
    public function tm_add_meta_box()
    {

        if (!post_type_exists('tour')) {
            return;
        }

        /** meta box for add tour details */
        add_meta_box(
            'trip_itinerary',
            __('Trip Itinerary', 'tour-manager'),
            [$this, 'tm_add_custom_meta_box_for_tour'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add guest details */
        add_meta_box(
            'tm_guest_meta_box',
            'Guest',
            [$this, 'tm_add_custom_meta_box_for_guest'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add journey highlights */
        add_meta_box(
            'tm_journey_highlights_meta_box',
            'Journey Highlights',
            [$this, 'tm_add_custom_meta_box_for_journey_highlights'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add FAQ */
        add_meta_box(
            'tm_faq_meta_box',
            'FAQs',
            [$this, 'tm_add_custom_meta_box_for_faq'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add tour guide option */
        add_meta_box(
            'tm_tour_guide_meta_box',
            'Tour Guide',
            [$this, 'tm_add_custom_meta_box_for_tour_guide'],
            'tour',
            'side',
            'default'
        );

        /** meta box for add details shown in single city page */
        add_meta_box(
            'tm_tour_details_meta_box',
            'Select as Popular Tour',
            [$this, 'tm_add_custom_meta_box_for_tour_details'],
            'tour',
            'side',
            'default'
        );

        /** meta box for add what's included */
        add_meta_box(
            'tm_whats_included_meta_box',
            'What\'s Included',
            [$this, 'tm_add_custom_meta_box_for_whats_included'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add what's not included */
        add_meta_box(
            'tm_whats_not_included_meta_box',
            'What\'s Not Included',
            [$this, 'tm_add_custom_meta_box_for_whats_not_included'],
            'tour',
            'normal',
            'default'
        );

        /** meta box for add cancellation policy */
        add_meta_box(
            'tm_cancellation_policy_meta_box',
            'Cancellation Policy',
            [$this, 'tm_add_custom_meta_box_for_cancellation_policy'],
            'tour',
            'normal',
            'default'
        );

    }


    /**
     * meta box for add trip details
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_tour($post)
    {

        $itinerary = get_post_meta($post->ID, '_trip_itinerary', true);

        // include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/trip-itinerary-meta-box.php';
        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/custom-trip-itinerary-meta-box.php';

    }


    /**
     * meta box for add guest details
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_guest($post)
    {

        // /** Retrieve existing values */
        // $fields = ['adult_max_count', 'adult_min_count', 'adult_rate', 'child_max_count', 'child_min_count', 'child_rate'];

        // foreach ($fields as $field) {
        //     $$field = get_post_meta($post->ID, "_$field", true);
        // }

        // global $post;
        // $custom = get_post_custom($post->ID);
        // $sl_meta_box_sidebar = isset($custom["tm-meta-box-sidebar"][0]) ? $custom["tm-meta-box-sidebar"][0] : '';

        $meta_keys = [
            'adult_max_count',
            'adult_min_count',
            'adult_rate',
            'child_max_count',
            'child_min_count',
            'child_rate',
            'tm-meta-box-sidebar'
        ];

        foreach ($meta_keys as $key) {
            ${$key} = get_post_meta($post->ID, "_$key", true);
        }


        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/tour-guest-meta-box.php';

    }


    /**
     * meta box for add journey highlights
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_journey_highlights($post)
    {

        /** Retrieve existing values */
        $fields = ['custom_highlights'];

        foreach ($fields as $field) {
            $$field = get_post_meta($post->ID, "_$field", true);
        }

        /** Editor for add Journey Highlights */
        wp_editor(
            $custom_highlights,
            'custom_editor_for_highlights',
            array(
                'textarea_name' => 'custom_highlights',
                'textarea_rows' => 10,
                'media_buttons' => false
            )
        );

    }


    /**
     * meta box for add tour FAQs
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_faq($post)
    {

        $faqs = get_post_meta($post->ID, '_tour_faqs', true);
        $faqs = is_array($faqs) ? $faqs : array();

        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/tour-faq-meta-box.php';

    }


    /**
     * meta box for add tour guide option
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_tour_guide($post)
    {

        $has_guide = get_post_meta($post->ID, '_has_tour_guide', true);

        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/tour-guide-meta-box.php';
    }


    /**
     * meta box for add details shown in single city page
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_tour_details($post)
    {

        $is_popular = get_post_meta($post->ID, '_tour_population', true);
        $top_badge = get_post_meta($post->ID, '_tour_top_badge', true);

        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/city-page-meta-box.php';
    }


    /**
     * meta box for add what's included
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_whats_included($post)
    {
        // Get existing included items and notes
        $whats_included = get_post_meta($post->ID, '_whats_included', true);
        $whats_included = is_array($whats_included) ? $whats_included : array();

        $included_notes = get_post_meta($post->ID, '_whats_included_notes', true);
        $included_notes = is_array($included_notes) ? $included_notes : array();

        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/whats-included-meta-box.php';
    }


    /**
     * meta box for add what's not included
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_whats_not_included($post)
    {

        include plugin_dir_path(__FILE__) . '../../templates/tour-metabox/whats-not-included-meta-box.php';
    }


    /**
     * meta box for add cancellation policy
     * @param mixed $post
     * @return void
     */
    public function tm_add_custom_meta_box_for_cancellation_policy($post)
    {
        /** Retrieve existing values */
        $fields = ['cancellation_policy'];

        foreach ($fields as $field) {
            $$field = get_post_meta($post->ID, "_$field", true);
        }

        /** Editor for add Cancellation Policy */
        wp_editor(
            $cancellation_policy,
            'custom_editor_for_cancellation_policy',
            array(
                'textarea_name' => 'cancellation_policy',
                'textarea_rows' => 100,
                'editor_height' => 300,
                'media_buttons' => false
            )
        );
    }


    /**
     * save meta data 
     * @param mixed $post_id
     * @return void
     */
    public function tm_save_tour_meta($post_id)
    {
        if (!isset($_POST['tour_meta_nonce']) || !wp_verify_nonce($_POST['tour_meta_nonce'], 'save_tour_data')) {
            return $post_id;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }

        /**
         * Single City Page meta data save
         */
        if (isset($_POST['tm_tour_population'])) {
            update_post_meta($post_id, '_tour_population', sanitize_text_field($_POST['tm_tour_population']));
        }

        if (isset($_POST['tm_tour_top_badge'])) {
            update_post_meta($post_id, '_tour_top_badge', sanitize_text_field($_POST['tm_tour_top_badge']));
        }

        /**
         * Tour Guide meta data save
         */
        if (isset($_POST['has_tour_guide'])) {
            update_post_meta($post_id, '_has_tour_guide', sanitize_text_field($_POST['has_tour_guide']));
        }

        /**
         * Tour Faq meta data save
         */
        $faq_data = array();
        if (isset($_POST['faq_questions']) && isset($_POST['faq_answers'])) {
            $questions = $_POST['faq_questions'];
            $answers = $_POST['faq_answers'];

            $count = min(count($questions), count($answers));
            for ($i = 0; $i < $count; $i++) {
                $question = trim($questions[$i]);
                $answer = trim($answers[$i]);

                if (!empty($question) && !empty($answer)) {
                    $faq_data[] = array(
                        'question' => sanitize_text_field($question),
                        'answer' => wp_kses_post($answer)
                    );
                }
            }
        }

        if (!empty($faq_data)) {
            update_post_meta($post_id, '_tour_faqs', $faq_data);
        } else {
            delete_post_meta($post_id, '_tour_faqs');
        }

        /**
         * Custom Highlights meta data save
         */
        if (isset($_POST['custom_highlights'])) {
            update_post_meta($post_id, '_custom_highlights', wp_kses_post($_POST['custom_highlights']));
        }

        /**
         * Cancellation Policy meta data save
         */
        if (isset($_POST['cancellation_policy'])) {
            update_post_meta($post_id, '_cancellation_policy', wp_kses_post($_POST['cancellation_policy']));
        }

        /**
         * Guest meta data save
         */
        if (isset($_POST['adult_max_count'])) {
            update_post_meta($post_id, '_adult_max_count', sanitize_text_field($_POST['adult_max_count']));
        }

        if (isset($_POST['adult_min_count'])) {
            update_post_meta($post_id, '_adult_min_count', sanitize_text_field($_POST['adult_min_count']));
        }

        if (isset($_POST['child_max_count'])) {
            update_post_meta($post_id, '_child_max_count', sanitize_text_field($_POST['child_max_count']));
        }

        if (isset($_POST['child_min_count'])) {
            update_post_meta($post_id, '_child_min_count', sanitize_text_field($_POST['child_min_count']));
        }

        if (isset($_POST['adult_rate'])) {
            update_post_meta($post_id, '_adult_rate', sanitize_text_field($_POST['adult_rate']));
        }

        if (isset($_POST['child_rate'])) {
            update_post_meta($post_id, '_child_rate', sanitize_text_field($_POST['child_rate']));
        }

        if (isset($_POST['tm-meta-box-sidebar'])) {
            update_post_meta($post_id, '_tm-meta-box-sidebar', sanitize_text_field($_POST['tm-meta-box-sidebar']));
        }

        // Save available months
        if (isset($_POST['available_months']) && is_array($_POST['available_months'])) {
            $available_months = array_map('sanitize_text_field', $_POST['available_months']);
            update_post_meta($post_id, '_available_months', $available_months);
        } else {
            // If no months selected, save empty array
            update_post_meta($post_id, '_available_months', array());
        }


        /**
         * Trip Itinerary meta data save - ARRAY STRUCTURE
         */
        if (isset($_POST['itinerary']) && is_array($_POST['itinerary'])) {
            $itinerary_data = array();

            foreach ($_POST['itinerary'] as $day_index => $day_data) {
                // Skip empty days
                if (empty($day_data['country'])) {
                    continue;
                }

                $day = array(
                    'day_number' => intval($day_index) + 1,
                    'country' => sanitize_text_field($day_data['country']),
                    'accommodation_rating' => isset($day_data['accommodation_rating']) ? sanitize_text_field($day_data['accommodation_rating']) : '',
                    'hotel' => isset($day_data['hotel']) ? sanitize_text_field($day_data['hotel']) : '',
                    'hotel_title' => isset($day_data['hotel_title']) ? sanitize_text_field($day_data['hotel_title']) : '', // This is correct
                    'description' => isset($day_data['description']) ? wp_kses_post($day_data['description']) : '',

                    'cities' => array(),

                    // Hotel 1 data
                    'hotel1_rating' => isset($day_data['hotel1_rating']) ? sanitize_text_field($day_data['hotel1_rating']) : '',
                    'hotel1' => isset($day_data['hotel1']) ? sanitize_text_field($day_data['hotel1']) : '',
                    'hotel1_title' => isset($day_data['hotel1_title']) ? sanitize_text_field($day_data['hotel1_title']) : '',

                    // Hotel 2 data
                    'hotel2_rating' => isset($day_data['hotel2_rating']) ? sanitize_text_field($day_data['hotel2_rating']) : '',
                    'hotel2' => isset($day_data['hotel2']) ? sanitize_text_field($day_data['hotel2']) : '',
                    'hotel2_title' => isset($day_data['hotel2_title']) ? sanitize_text_field($day_data['hotel2_title']) : ''
                );

                // Process cities
                if (isset($day_data['cities']) && is_array($day_data['cities'])) {
                    foreach ($day_data['cities'] as $city_index => $city_data) {
                        if (!empty($city_data['name'])) {
                            $city = array(
                                'name' => sanitize_text_field($city_data['name']),
                                'title' => sanitize_text_field($city_data['title']),
                                'order' => intval($city_index) + 1,
                                'activities' => array(),
                                'attractions' => array()
                            );

                            // Process activities
                            if (isset($city_data['activities']) && is_array($city_data['activities'])) {
                                foreach ($city_data['activities'] as $activity_id) {
                                    $activity_id = intval($activity_id);
                                    if ($activity_id > 0) {
                                        $city['activities'][] = $activity_id;
                                    }
                                }
                            }

                            // Process attractions
                            if (isset($city_data['attractions']) && is_array($city_data['attractions'])) {
                                foreach ($city_data['attractions'] as $attraction_id) {
                                    $attraction_id = intval($attraction_id);
                                    if ($attraction_id > 0) {
                                        $city['attractions'][] = $attraction_id;
                                    }
                                }
                            }

                            $day['cities'][] = $city;
                        }
                    }
                }

                $itinerary_data[] = $day;
            }

            // Save the itinerary data
            if (!empty($itinerary_data)) {
                update_post_meta($post_id, '_trip_itinerary', $itinerary_data);
            } else {
                delete_post_meta($post_id, '_trip_itinerary');
            }
        } else {
            delete_post_meta($post_id, '_trip_itinerary');
        }


        /**
         * Save What's Included meta data
         */
        if (isset($_POST['whats_included']) && is_array($_POST['whats_included'])) {
            $whats_included = array_map('sanitize_text_field', $_POST['whats_included']);
            update_post_meta($post_id, '_whats_included', $whats_included);
        } else {
            // If none selected, delete meta
            delete_post_meta($post_id, '_whats_included');
        }

        // Save included textarea notes
        if (isset($_POST['whats_included_notes']) && is_array($_POST['whats_included_notes'])) {
            $included_notes = [];
            foreach ($_POST['whats_included_notes'] as $key => $value) {
                $included_notes[sanitize_text_field($key)] = sanitize_textarea_field($value);
            }
            update_post_meta($post_id, '_whats_included_notes', $included_notes);
        } else {
            delete_post_meta($post_id, '_whats_included_notes');
        }

        /**
         * Save What's NOT Included meta data
         */
        if (isset($_POST['whats_not_included']) && is_array($_POST['whats_not_included'])) {
            $not_included = array_map('sanitize_text_field', $_POST['whats_not_included']);
            update_post_meta($post_id, '_whats_not_included', $not_included);
        } else {
            // If none selected, delete meta
            delete_post_meta($post_id, '_whats_not_included');
        }

        // Save not included textarea notes
        if (isset($_POST['whats_not_included_notes']) && is_array($_POST['whats_not_included_notes'])) {
            $notes = [];
            foreach ($_POST['whats_not_included_notes'] as $key => $value) {
                $notes[sanitize_text_field($key)] = sanitize_textarea_field($value);
            }
            update_post_meta($post_id, '_whats_not_included_notes', $notes);
        } else {
            delete_post_meta($post_id, '_whats_not_included_notes');
        }

    }


    /**
     * @function tm_add_tour_columns()
     * @description Add custom columns headers
     */
    public function tm_add_tour_columns($columns)
    {

        $new_columns = array(
            'featured_image' => __('Image', 'text-domain'),
            'guest_count' => 'Guest Count',
            'guest_rates' => 'Rates',
            // 'country' => 'Country',
        );

        // Insert after title column
        $offset = array_search('title', array_keys($columns)) + 1;
        $columns = array_merge(
            array_slice($columns, 0, $offset),
            $new_columns,
            array_slice($columns, $offset)
        );

        return $columns;

    }



    /**
     * @function tm_populate_tour_columns()
     * @description Add custom columns data
     */
    public function tm_populate_tour_columns($column, $post_id)
    {

        switch ($column) {
            case 'featured_image':
                if (function_exists('the_post_thumbnail'))
                    ;
                echo the_post_thumbnail('add_featured_images');
                break;

            case 'guest_count':
                $adult_max_count = get_post_meta($post_id, '_adult_max_count', true);
                $adult_min_count = get_post_meta($post_id, '_adult_min_count', true);
                $child_max_count = get_post_meta($post_id, '_child_max_count', true);
                $child_min_count = get_post_meta($post_id, '_child_min_count', true);

                $output = '';
                if ($adult_max_count) {
                    $output .= '<strong>A </strong> ' . esc_html($adult_max_count) . '-' . esc_html($adult_min_count) . '<br>';
                }
                if ($child_max_count) {
                    $output .= '<strong>C </strong> ' . esc_html($child_max_count) . '-' . esc_html($child_min_count);
                }

                echo $output ? $output : '—';
                break;

            case 'guest_rates':
                $adult_rate = get_post_meta($post_id, '_adult_rate', true);
                $child_rate = get_post_meta($post_id, '_child_rate', true);

                $output = '';
                if ($adult_rate) {
                    $output .= '<strong>A </strong> $' . number_format($adult_rate, 2) . '<br>';
                }
                if ($child_rate) {
                    $output .= '<strong>C </strong> $' . number_format($child_rate, 2);
                }

                echo $output ? $output : '—';
                break;

            // case 'country':
            //     $country = get_post_meta($post_id, '_location_country', true);
            //     echo $country ? esc_html($country) : '—';
            //     break;
        }

    }



    /**
     * @function tm_enqueue_script_and_styles()
     * @description Enqueue Scripts and Styles
     */
    public function tm_enqueue_script_and_styles()
    {

        if (!is_admin() || !(get_current_screen()->post_type === 'tour'))
            return;

        wp_enqueue_style(
            'tour-manager-from-codzbee.php',
            plugin_dir_url(__FILE__) . '../../../assets/css/tour.css',
            array(),
            1,
            'all'
        );

        // wp_enqueue_script(
        //     'tour-manager-from-codzbee-script',
        //     plugin_dir_url(__FILE__) . '../../../assets/js/tour.js',
        //     array('jquery'),
        //     null,
        //     true
        // );

    }




    private function get_location_coordinates($location_id)
    {
        if (!$location_id)
            return false;

        return array(
            'title' => get_the_title($location_id),
            'lat' => get_post_meta($location_id, '_latitude', true),
            'lng' => get_post_meta($location_id, '_longitude', true),
            'description' => get_post_meta($location_id, '_location_description', true)
        );
    }

    public function display_tour_map($post_id)
    {
        // Get tour itinerary data
        $from_locations = get_post_meta($post_id, '_from_location', true);
        $to_locations = get_post_meta($post_id, '_to_location', true);
        $from_stay_times = get_post_meta($post_id, '_from_stay_time', true);
        $to_stay_times = get_post_meta($post_id, '_to_stay_time', true);
        $descriptions = get_post_meta($post_id, '_location_descriptions', true);

        // Get map settings
        $zoom = get_post_meta($post_id, '_map_zoom', true) ?: 10;
        $map_type = get_post_meta($post_id, '_map_type', true) ?: 'roadmap';

        // Prepare itinerary points
        $itinerary = array();
        $day_count = 1;

        if (is_array($from_locations)) {
            foreach ($from_locations as $index => $from_location_id) {
                $from_location = $this->get_location_coordinates($from_location_id);
                $to_location = isset($to_locations[$index]) ? $this->get_location_coordinates($to_locations[$index]) : false;

                if ($from_location && $from_location['lat'] && $from_location['lng']) {
                    $from_location['day'] = $day_count;
                    $from_location['stay_time'] = isset($from_stay_times[$index]) ? $from_stay_times[$index] : '';
                    $from_location['description'] = isset($descriptions[$index]) ? $descriptions[$index] : '';
                    $itinerary[] = $from_location;
                }

                if ($to_location && $to_location['lat'] && $to_location['lng']) {
                    $to_location['day'] = $day_count;
                    $to_location['stay_time'] = isset($to_stay_times[$index]) ? $to_stay_times[$index] : '';
                    $to_location['description'] = isset($descriptions[$index]) ? $descriptions[$index] : '';
                    $itinerary[] = $to_location;
                }

                $day_count++;
            }
        }

        // Only proceed if we have locations with coordinates
        if (empty($itinerary)) {
            return;
        }

        // Enqueue Google Maps API
        wp_enqueue_script('google-maps', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBrlErC7_iaeM_C3dM8-GKTVysbqNSXNNE&callback=Function.prototype', array(), null, true);

        // Localize script with itinerary data
        wp_localize_script('tour-manager-frontend', 'tourMapData', array(
            'itinerary' => $itinerary,
            'zoom' => $zoom,
            'mapType' => $map_type,
            'mapStyles' => '' // You can add custom map styles here if needed
        ));

        // Output the map HTML
        ?>
        <div class="tour-map-container">
            <h3>Tour Itinerary Map</h3>
            <div id="tour-itinerary-map" style="height: 500px; width: 100%;"></div>
        </div>
        <?php
    }

    public function tm_enqueue_frontend_scripts()
    {
        if (is_singular('tour')) {
            wp_enqueue_script(
                'tour-manager-frontend',
                plugin_dir_url(__FILE__) . '../../../assets/js/tour-waypoint-map.js',
                array('jquery'),
                null,
                true
            );

            // wp_enqueue_style(
            //     'tour-manager-frontend',
            //     plugin_dir_url(__FILE__) . '../../../assets/css/tour-frontend.css',
            //     array(),
            //     1,
            //     'all'
            // );
        }
    }


    public function filter_tours_by_category()
    {
        global $typenow;

        if ($typenow !== 'tour') {
            return;
        }

        $taxonomy = 'tour_category';
        $selected = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';

        wp_dropdown_categories([
            'show_option_all' => 'All Categories',
            'taxonomy' => $taxonomy,
            'name' => $taxonomy,
            'orderby' => 'name',
            'selected' => $selected,
            'hierarchical' => true,
            'depth' => 3,
            'show_count' => true,
            'hide_empty' => false,
            'value_field' => 'slug', // Important for filtering
        ]);
    }

    public function filter_tours_query_by_category($query)
    {
        global $pagenow;

        if (
            $pagenow === 'edit.php' &&
            isset($_GET['post_type']) &&
            $_GET['post_type'] === 'tour' &&
            isset($_GET['tour_category']) &&
            $_GET['tour_category'] != ''
        ) {

            $tax_query = array(
                [
                    'taxonomy' => 'tour_category',
                    'field' => 'slug',
                    'terms' => $_GET['tour_category']
                ]
            );

            $query->set('tax_query', $tax_query);
        }
    }

}