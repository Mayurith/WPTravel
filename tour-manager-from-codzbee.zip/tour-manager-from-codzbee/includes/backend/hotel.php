<?php
/** includes/backend/hotel.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}


/**
 * @class       : Hotel
 * @description : load dependencies
 */
require_once plugin_dir_path(__FILE__) . 'hotel/class-hotel-post-type.php';
require_once plugin_dir_path(__FILE__) . 'hotel/class-hotel-meta-box.php';


/**
 * @class       : Hotel
 * @description : All hotel details include this class.
 */
class Hotel
{
    private $tm_hotel_post_type;
    private $tm_hotel_meta_box;

    public function __construct()
    {
        $this->tm_hotel_post_type = new Hotel_Post_Type();
        $this->tm_hotel_meta_box = new Hotel_Meta_Box();
    }
}



















