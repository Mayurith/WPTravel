<?php
/** includes/backend/inquiry.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/** Load dependencies */
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-post-type.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-admin-columns.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-ajax-handler.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-notifications.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-admin-view-ui.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-email.php';

// require_once plugin_dir_path(__FILE__) . 'inquiry/class-inquiry-status-change-modal.php';
require_once plugin_dir_path(__FILE__) . '../frontend/inquiry-form.php';
require_once plugin_dir_path(__FILE__) . 'booking-inquiry/class-booking-inquiry-admin-edit-ui.php';



/**
 * Main Inquiry class that composes all sub-components
 */
class Booking_Inquiry
{
    private $tm_post_type;
    private $tm_admin_columns;
    private $tm_ajax_handler;
    private $tm_notifications;
    private $tm_admin_view_ui;
    private $tm_email;
    private $tm_admin_edit_ui;
    // private $tm_custom_inquiry_post_type;

    public function __construct()
    {
        $this->tm_post_type = new Booking_Inquiry_Post_Type();
        $this->tm_admin_columns = new Booking_Inquiry_Admin_Columns();
        $this->tm_ajax_handler = new Booking_Inquiry_Ajax_Handler();
        $this->tm_notifications = new Booking_Inquiry_Notifications();
        $this->tm_admin_view_ui = new Booking_Inquiry_Admin_View_UI();
        $this->tm_email = new Booking_Inquiry_Email();
        $this->tm_admin_edit_ui = new Booking_Inquiry_Admin_Edit_UI();

        // Register custom post type for custom inquiries
        // $this->tm_custom_inquiry_post_type = new Custom_Inquiry_Post_Type();




        // add_filter('single_template', function ($template) {
        //     global $post;

        //     if ($post->post_type === 'inquiry') {
        //         // Look for template in theme first
        //         $theme_template = locate_template(['single-inquiry.php']);

        //         if ($theme_template) {
        //             return $theme_template;
        //         }

        //         // Fallback to plugin template
        //         $plugin_template = plugin_dir_path(__FILE__) . '../templates/single-inquiry.php';
        //         if (file_exists($plugin_template)) {
        //             return $plugin_template;
        //         }
        //     }

        //     return $template;
        // });
    }
}