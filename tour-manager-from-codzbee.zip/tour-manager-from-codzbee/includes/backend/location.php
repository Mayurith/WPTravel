<?php
/** includes/backend/location.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}

/** Load dependencies */
require_once plugin_dir_path(__FILE__) . 'location/class-location-post-type.php';
require_once plugin_dir_path(__FILE__) . 'location/class-location-meta-box.php';

/**
 * @class Location
 * @description location details include class.
 */
class Location
{
  private $tm_post_type;
  private $tm_meta_box;

  public function __construct()
  {
    $this->tm_post_type = new Location_Post_Type();
    $this->tm_meta_box = new Location_Meta_Box();

    add_filter('single_template', function ($template) {
      global $post;

      if ($post->post_type === 'location') {
        // Look for template in theme first
        $theme_template = locate_template(['location-coordinates-meta-box.php']);

        if ($theme_template) {
          return $theme_template;
        }

        // Fallback to plugin template
        $plugin_template = plugin_dir_path(__FILE__) . '../templates/location-coordinates-meta-box.php';
        if (file_exists($plugin_template)) {
          return $plugin_template;
        }
      }

      return $template;
    });

  }
  
}