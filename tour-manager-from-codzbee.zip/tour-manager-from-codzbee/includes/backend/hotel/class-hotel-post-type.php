<?php
/** includes/backend/hotel/class-hotel-post-type.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class       : Hotel_Post_Type
 * @description : Register Hotel Post Type
 */
class Hotel_Post_Type
{
    public function __construct()
    {
        add_action('init', array($this, 'register_hotel_post_type'));
    }

    public function register_hotel_post_type()
    {
         $args = array(
      'labels' => array(
        'name' => 'Hotels',
        'add_new' => 'Add New Hotel',
        'add_new_item' => 'Add New Hotel',
        'edit_item' => 'Edit Hotel',
        'search_items' => 'Search Hotel'
      ),
      'public' => true,
      'has_archive' => true,
      'rewrite' => ['slug' => 'hotel'],
      'supports' => array('title', 'thumbnail'),
      'show_ui' => true,
      'show_in_menu' => 'main_menu_of_tour_manager' /** Add to the "Tour Manager" main menu */
    );
    register_post_type('hotel', $args);


    }

}