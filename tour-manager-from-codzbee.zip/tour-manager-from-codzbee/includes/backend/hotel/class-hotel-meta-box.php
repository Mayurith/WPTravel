<?php
/** includes/backend/hotel/class-hotel-meta-box.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class Hotel_Meta_Box
 * @description Create class for hotel meta box with country and city selection
 */
class Hotel_Meta_Box
{
    /**
     * @method      : __construct
     * @description : hotel meta box callback
     */
    public function __construct()
    {
        /** Hook for add meta box */
        add_action('add_meta_boxes', array($this, 'tm_add_hotel_meta_box'));
        /** Hook for save meta data */
        add_action('save_post_hotel', array($this, 'tm_save_hotel_meta'));

        /** Hook for manage meta data column */
        add_filter('manage_hotel_posts_columns', array($this, 'tm_set_custom_edit_hotel_columns'));
        add_action('manage_hotel_posts_custom_column', array($this, 'tm_custom_hotel_column'), 10, 2);

        /** Hook for enqueue Script and Styles (backend) */
        add_action('admin_enqueue_scripts', array($this, 'tm_enqueue_hotel_scripts_and_styles'));

        /** AJAX hooks for getting cities by country */
        add_action('wp_ajax_get_cities_by_country', array($this, 'tm_get_cities_by_country_ajax'));
        add_action('wp_ajax_nopriv_get_cities_by_country', array($this, 'tm_get_cities_by_country_ajax'));

        /** Filter for country in hotel list */
        add_action('restrict_manage_posts', array($this, 'tm_filter_hotel_by_country'));
        add_action('pre_get_posts', array($this, 'tm_filter_hotel_list_by_country'));
    }

    /**
     * @function    : tm_add_hotel_meta_box()
     * @description : hotel meta box callback
     */
    public function tm_add_hotel_meta_box()
    {
        /** Add meta box for hotel details */
        add_meta_box(
            'tm_hotel_details_meta_box',
            'Hotel Details',
            array($this, 'tm_add_custom_meta_box_for_hotel_details'),
            'hotel',
            'normal',
            'high'
        );

        /** Add meta box for hotel gallery */
        add_meta_box(
            'tm_hotel_gallery_meta_box',
            'Hotel Gallery',
            array($this, 'tm_add_custom_meta_box_for_hotel_gallery'),
            'hotel',
            'normal',
            'high'
        );

        /** add meta box for select recommended hotels */
        add_meta_box(
            'tm_recommended_hotels_meta_box',
            'Recommended Hotels',
            array($this, 'tm_add_custom_meta_box_for_recommended_hotels'),
            'hotel',
            'side',
            'high'
        );
    }

    /**
     * @function    : tm_add_custom_meta_box_for_hotel_details()
     * @description : hotel meta box fields
     */
    public function tm_add_custom_meta_box_for_hotel_details($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_hotel_data', 'hotel_meta_nonce');

        // Get saved values
        $hotel_country = get_post_meta($post->ID, '_hotel_country', true);
        $hotel_city = get_post_meta($post->ID, '_hotel_city', true);
        $hotel_locations = get_post_meta($post->ID, '_hotel_location', true);
        $hotel_top_badge = get_post_meta($post->ID, '_hotel_top_badge', true);
        $hotel_reviews = get_post_meta($post->ID, '_hotel_reviews', true);
        $hotel_start_rate = get_post_meta($post->ID, '_hotel_start_rate', true);
        $hotel_url = get_post_meta($post->ID, '_hotel_url', true);

        // Get all countries from city posts
        $countries = $this->tm_get_all_countries();

        // Get cities based on selected country
        $cities = array();
        if (!empty($hotel_country)) {
            $cities = $this->tm_get_cities_by_country($hotel_country);
        }

        include plugin_dir_path(__FILE__) . '../../templates/hotel-metabox/hotel-details-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_hotel_details()
     * @description : hotel gallery meta box fields
     */
    public function tm_add_custom_meta_box_for_recommended_hotels($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_hotel_data', 'hotel_meta_nonce');

        // Get saved values
        $recommended_hotels = get_post_meta($post->ID, '_recommended_hotels', true);

        include plugin_dir_path(__FILE__) . '../../templates/hotel-metabox/recommended-hotels-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_hotel_gallery()
     * @description : hotel gallery meta box
     */
    public function tm_add_custom_meta_box_for_hotel_gallery($post)
    {
        // Get saved gallery images
        $hotel_gallery = get_post_meta($post->ID, '_hotel_gallery', true);
        $gallery_ids = !empty($hotel_gallery) ? explode(',', $hotel_gallery) : array();

        include plugin_dir_path(__FILE__) . '../../templates/hotel-metabox/hotel-gallery-meta-box.php';
    }

    /**
     * @function    : tm_save_hotel_meta()
     * @description : save hotel meta box data
     */
    public function tm_save_hotel_meta($post_id)
    {
        /** Verify nonce */
        if (!isset($_POST['hotel_meta_nonce']) || !wp_verify_nonce($_POST['hotel_meta_nonce'], 'save_hotel_data')) {
            return $post_id;
        }

        /** Check autosave */
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        /** Check permissions */
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }

        /** Save country */
        if (isset($_POST['tm_hotel_country'])) {
            update_post_meta($post_id, '_hotel_country', sanitize_text_field($_POST['tm_hotel_country']));
        }

        /** Save city */
        if (isset($_POST['tm_hotel_city'])) {
            update_post_meta($post_id, '_hotel_city', sanitize_text_field($_POST['tm_hotel_city']));
        }

        /** Save location */
        if (isset($_POST['tm_hotel_location'])) {
            update_post_meta($post_id, '_hotel_location', sanitize_text_field($_POST['tm_hotel_location']));
        }

        /** Save top_badge */
        if (isset($_POST['tm_hotel_top_badge'])) {
            update_post_meta($post_id, '_hotel_top_badge', sanitize_text_field($_POST['tm_hotel_top_badge']));
        }

        /** Save reviews */
        if (isset($_POST['tm_hotel_reviews'])) {
            update_post_meta($post_id, '_hotel_reviews', intval($_POST['tm_hotel_reviews']));
        }

        /** Save start rate */
        if (isset($_POST['tm_hotel_start_rate'])) {
            update_post_meta($post_id, '_hotel_start_rate', sanitize_text_field($_POST['tm_hotel_start_rate']));
        }

        /** Save hotel url */
        if (isset($_POST['tm_hotel_url'])) {
            update_post_meta($post_id, '_hotel_url', esc_url($_POST['tm_hotel_url']));
        }

        /** Save recommended hotels */
        if (isset($_POST['tm_recommended_hotels'])) {
            update_post_meta($post_id, '_recommended_hotels', sanitize_text_field($_POST['tm_recommended_hotels']));
        }

        /** Save gallery images */
        if (isset($_POST['tm_hotel_gallery'])) {
            $gallery_ids = sanitize_text_field($_POST['tm_hotel_gallery']);
            update_post_meta($post_id, '_hotel_gallery', $gallery_ids);
        } else {
            delete_post_meta($post_id, '_hotel_gallery');
        }
    }

    /**
     * @function    : tm_set_custom_edit_hotel_columns()
     * @description : set custom columns for hotel post type
     */
    public function tm_set_custom_edit_hotel_columns($columns)
    {
        $new_columns = array(
            'country' => 'Country',
            'city' => 'City',
            'rating' => 'Rating',
            'gallery' => 'Gallery Images'
        );

        // Insert after title column
        $offset = array_search('title', array_keys($columns)) + 1;
        $columns = array_merge(
            array_slice($columns, 0, $offset),
            $new_columns,
            array_slice($columns, $offset)
        );

        return $columns;
    }

    /**
     * @function    : tm_custom_hotel_column()
     * @description : custom columns for hotel post type
     */
    public function tm_custom_hotel_column($column, $post_id)
    {
        switch ($column) {
            case 'country':
                echo get_post_meta($post_id, '_hotel_country', true);
                break;
            case 'city':
                $city_id = get_post_meta($post_id, '_hotel_city', true);
                if (!empty($city_id)) {
                    echo get_the_title($city_id);
                }
                break;
            case 'rating':
                $rating = get_post_meta($post_id, '_hotel_rating', true);
                echo !empty($rating) ? $rating . ' Stars' : 'N/A';
                break;
            case 'gallery':
                $gallery = get_post_meta($post_id, '_hotel_gallery', true);
                $gallery_ids = !empty($gallery) ? explode(',', $gallery) : array();
                echo count($gallery_ids) . ' images';
                break;
        }
    }

    /**
     * @function    : tm_get_all_countries()
     * @description : Returns all unique countries from city meta
     */
    private function tm_get_all_countries()
    {
        global $wpdb;

        $results = $wpdb->get_col("
            SELECT DISTINCT meta_value 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_city_country' 
            AND meta_value != ''
            ORDER BY meta_value ASC
        ");

        return $results;
    }

    /**
     * @function    : tm_get_cities_by_country()
     * @description : Returns all cities for a specific country
     * @param       : string $country - The country name
     * @return      : array of city posts
     */
    private function tm_get_cities_by_country($country)
    {
        $args = array(
            'post_type' => 'city',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_city_country',
                    'value' => $country,
                    'compare' => '='
                )
            ),
            'orderby' => 'title',
            'order' => 'ASC'
        );

        return get_posts($args);
    }

    /**
     * @function    : tm_get_cities_by_country_ajax()
     * @description : AJAX handler to get cities by country
     */
    public function tm_get_cities_by_country_ajax()
    {
        // Verify nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hotel_city_nonce')) {
            wp_die('Security check failed');
        }

        if (!isset($_POST['country']) || empty($_POST['country'])) {
            wp_die();
        }

        $country = sanitize_text_field($_POST['country']);
        $cities = $this->tm_get_cities_by_country($country);

        $options = '<option value="">' . __('Select a City', 'text-domain') . '</option>';
        foreach ($cities as $city) {
            $options .= '<option value="' . esc_attr($city->ID) . '">' . esc_html($city->post_title) . '</option>';
        }

        echo $options;
        wp_die();
    }

    /**
     * @function    : tm_filter_hotel_by_country()
     * @description : Adds a country filter dropdown in admin list for Hotel post type
     */
    public function tm_filter_hotel_by_country()
    {
        global $typenow;

        if ($typenow !== 'hotel') {
            return;
        }

        // Get all unique countries from hotels
        $countries = $this->tm_get_hotel_countries();

        if (empty($countries)) {
            return;
        }

        $selected = isset($_GET['hotel_country_filter']) ? $_GET['hotel_country_filter'] : '';

        echo '<select name="hotel_country_filter">';
        echo '<option value="">' . __('All Countries', 'text-domain') . '</option>';

        foreach ($countries as $country) {
            printf(
                '<option value="%s"%s>%s</option>',
                esc_attr($country),
                selected($selected, $country, false),
                esc_html($country)
            );
        }

        echo '</select>';
    }

    /**
     * @function    : tm_get_hotel_countries()
     * @description : Returns all unique countries from hotel meta
     */
    private function tm_get_hotel_countries()
    {
        global $wpdb;

        $results = $wpdb->get_col("
            SELECT DISTINCT meta_value 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_hotel_country' 
            AND meta_value != ''
            ORDER BY meta_value ASC
        ");

        return $results;
    }

    /**
     * @function    : tm_filter_hotel_list_by_country()
     * @description : Alters query to filter hotels by selected country
     */
    public function tm_filter_hotel_list_by_country($query)
    {
        global $pagenow;

        if (!is_admin() || $pagenow !== 'edit.php' || $query->get('post_type') !== 'hotel') {
            return;
        }

        if (!empty($_GET['hotel_country_filter'])) {
            $query->set('meta_query', array(
                array(
                    'key' => '_hotel_country',
                    'value' => sanitize_text_field($_GET['hotel_country_filter']),
                    'compare' => '='
                )
            ));
        }
    }

    /**
     * @function    : tm_enqueue_hotel_scripts_and_styles()
     * @description : Enqueue admin scripts and styles for hotel post type
     */
    public function tm_enqueue_hotel_scripts_and_styles()
    {
        if (!is_admin()) {
            return;
        }

        $screen = get_current_screen();

        /** Enqueue for hotel post type */
        if ($screen->post_type === 'hotel') {
            /** Enqueue WordPress media uploader scripts */
            wp_enqueue_media();

            wp_enqueue_script(
                'hotel-manager-script',
                plugin_dir_url(__FILE__) . '../../../assets/js/hotel.js',
                array('jquery', 'media-upload'),
                null,
                true
            );

            wp_localize_script('hotel-manager-script', 'hotel_manager', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('hotel_city_nonce'),
                'title' => __('Select Gallery Images', 'text-domain'),
                'button_text' => __('Add to Gallery', 'text-domain')
            ));

            wp_enqueue_style(
                'hotel-manager-style',
                plugin_dir_url(__FILE__) . '../../../assets/css/hotel.css',
                array(),
                1,
                'all'
            );
        }
    }
}