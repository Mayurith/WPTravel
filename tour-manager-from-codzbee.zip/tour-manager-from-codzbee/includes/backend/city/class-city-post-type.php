<?php
/** includes/backend/city/class-city-post-type.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class       : City_Post_Type
 * @description : Create class for register custom post type --> city
 */
class City_Post_Type
{

    /**
     * @method      : __construct
     * @description : city post type callback
     */
    public function __construct()
    {
        /** Hook for register custom post type : city */
        add_action('init', array($this, 'tm_register_city_post_type'));
        add_theme_support('post-thumbnails');
    }

    public function tm_register_city_post_type()
    {

        $args = array(
            'labels' => array(
                'name' => 'Cities',
                'add_new' => 'Add New City',
                'add_new_item' => 'Add New City',
                'edit_item' => 'Edit City',
                'search_items' => 'Search City',
                'new_item' => 'New City',
                'view_item' => 'View City',
                'not_found' => 'No Cities found',
                'not_found_in_trash' => 'No Cities found in Trash',
            ),
            'public' => true,
            'rewrite' => ['slug' => 'city'],
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'show_ui' => true,
            'show_in_menu' => 'main_menu_of_tour_manager' /** Add to the "Tour Manager" main menu */
        );
        register_post_type('city', $args);

    }

}