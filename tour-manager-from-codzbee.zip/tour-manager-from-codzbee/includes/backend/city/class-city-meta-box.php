<?php
/** includes/backend/city/class-city-meta-box.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @class City_Meta_Box
 * @description Create class for city meta box
 */
class City_Meta_Box
{
    /**
     * @method      : __construct
     * @description : city meta box callback
     */
    public function __construct()
    {
        /** Hook for add meta box */
        add_action('add_meta_boxes', array($this, 'tm_add_meta_box'));
        /** Hook for save meta data */
        add_action('save_post_city', array($this, 'tm_save_city_meta'));

        /** Hook for manage meta data column */
        add_filter('manage_city_posts_columns', array($this, 'tm_set_custom_edit_city_columns'));
        add_action('manage_city_posts_custom_column', array($this, 'tm_custom_city_column'), 10, 2);

        /** Hook for enqueue Script and Styles (backend) */
        add_action('admin_enqueue_scripts', array($this, 'tm_enqueue_script_and_styles'));
        // add_action('wp_enqueue_scripts', array($this, 'tm_enqueue_frontend_scripts'));

        add_action('restrict_manage_posts', array($this, 'tm_filter_by_country'));
        add_action('pre_get_posts', array($this, 'tm_filter_city_by_country'));

        /** AJAX hooks for hotel meta box */
        add_action('wp_ajax_get_cities_by_country', array($this, 'tm_get_cities_by_country_ajax'));
        add_action('wp_ajax_nopriv_get_cities_by_country', array($this, 'tm_get_cities_by_country_ajax'));


    }

    /**
     * @function    : tm_add_meta_box()
     * @description : city meta box callback
     */
    public function tm_add_meta_box()
    {
        /** add meta box for popular destination */
        add_meta_box(
            'tm_city_meta_box',
            'Popular Destination',
            array($this, 'tm_add_custom_meta_box_for_popular_destination'),
            'city',
            'side',
            'default'
        );

        /** add meta box for country */
        add_meta_box(
            'tm_city_country_meta_box',
            'Country',
            array($this, 'tm_add_custom_meta_box_for_country'),
            'city',
            'side',
            'default'
        );

        /** add meta box for image gallery */
        add_meta_box(
            'tm_city_image_gallery_meta_box',
            'Image Gallery',
            array($this, 'tm_add_custom_meta_box_for_image_gallery'),
            'city',
            'normal',
            'default'
        );

        /** add meta box for link available hotel or tour */
        // add_meta_box(
        //     'tm_city_linked_hotel_tour_meta_box',
        //     'Linked Hotels & Tours',
        //     array($this, 'tm_add_custom_meta_box_for_linked_hotel_tour'),
        //     'city',
        //     'normal',
        //     'default'
        // );

        /** add meta box for add city properties */
        add_meta_box(
            'tm_city_properties_meta_box',
            'City Properties',
            array($this, 'tm_add_custom_meta_box_for_city_properties'),
            'city',
            'normal',
            'default'
        );

        /** add meta box for manage single city page data */
        add_meta_box(
            'tm_city_single_page_meta_box',
            'Single City Page',
            array($this, 'tm_add_custom_meta_box_for_single_page'),
            'city',
            'normal',
            'default'
        );

        /** add meta box for FAQs */
        add_meta_box(
            'tm_city_faqs_meta_box',
            'FAQs',
            array($this, 'tm_add_custom_meta_box_for_faqs'),
            'city',
            'normal',
            'default'
        );

        /** add meta box for marking as nearest destination */
        add_meta_box(
            'tm_city_nearest_destination_meta_box',
            'Nearest Destination',
            array($this, 'tm_add_custom_meta_box_for_nearest_destination'),
            'city',
            'normal',
            'default'
        );
    }

    /**
     * @function    : tm_add_custom_meta_box_for_popular_destination()
     * @description : city meta box fields
     */
    public function tm_add_custom_meta_box_for_popular_destination($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        $city_population = get_post_meta($post->ID, '_city_population', true);
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-popular-destination-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_country()
     * @description : city country meta box fields
     */
    public function tm_add_custom_meta_box_for_country($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        $city_country = get_post_meta($post->ID, '_city_country', true);
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-country-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_image_gallery()
     * @description : city image gallery meta box fields
     */
    public function tm_add_custom_meta_box_for_image_gallery($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        $image_gallery = get_post_meta($post->ID, '_city_image_gallery', true);
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-image-gallery-meta-box.php';
    }

    // /**
    //  * @function    : tm_add_custom_meta_box_for_linked_hotel_tour()
    //  * @description : city linked hotel & tour meta box fields
    //  */
    // public function tm_add_custom_meta_box_for_linked_hotel_tour($post)
    // {
    //     /** Add nonce for security */
    //     wp_nonce_field('save_city_nonce', 'security');
    //     wp_nonce_field('save_city_data', 'city_meta_nonce');
    //     include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-linked-hotel-tour-meta-box.php';
    // }

    /**
     * @function    : tm_add_custom_meta_box_for_city_properties()
     * @description : city properties meta box fields
     */
    public function tm_add_custom_meta_box_for_city_properties($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-properties-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_single_page()
     * @description : city single page meta box fields
     */
    public function tm_add_custom_meta_box_for_single_page($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-single-page-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_faqs()
     * @description : city faqs meta box fields
     */
    public function tm_add_custom_meta_box_for_faqs($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-faqs-meta-box.php';
    }

    /**
     * @function    : tm_add_custom_meta_box_for_nearest_destination()
     * @description : city nearest destination meta box fields
     */
    public function tm_add_custom_meta_box_for_nearest_destination($post)
    {
        /** Add nonce for security */
        wp_nonce_field('save_city_nonce', 'security');
        wp_nonce_field('save_city_data', 'city_meta_nonce');
        $is_nearest = get_post_meta($post->ID, '_is_nearest_destination', true);
        $city_latitude = get_post_meta($post->ID, '_city_latitude', true);
        $city_longitude = get_post_meta($post->ID, '_city_longitude', true);
        $city_address = get_post_meta($post->ID, '_city_address', true);
        include plugin_dir_path(__FILE__) . '../../templates/city-metabox/city-nearest-destination-meta-box.php';
    }

    /**
     * @function    : tm_save_city_meta()
     * @description : save city meta box data
     */
    public function tm_save_city_meta($post_id)
    {
        if (!isset($_POST['city_meta_nonce']) || !wp_verify_nonce($_POST['city_meta_nonce'], 'save_city_data')) {
            return $post_id;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
        if (isset($_POST['tm_popular_destinations'])) {
            update_post_meta($post_id, '_city_population', sanitize_text_field($_POST['tm_popular_destinations']));
        }
        if (isset($_POST['tm_city_country'])) {
            update_post_meta($post_id, '_city_country', sanitize_text_field($_POST['tm_city_country']));
        }
        if (isset($_POST['tm_city_property'])) {
            update_post_meta($post_id, '_city_property', sanitize_text_field($_POST['tm_city_property']));
        }
        if (isset($_POST['city_image_gallery'])) {
            update_post_meta($post_id, '_city_image_gallery', sanitize_text_field($_POST['city_image_gallery']));
        }
        if (isset($_POST['tm_subtitle'])) {
            update_post_meta($post_id, '_city_subtitle', sanitize_text_field($_POST['tm_subtitle']));
        }
        // General Info Section
        if (isset($_POST['general_info_title'])) {
            update_post_meta($post_id, '_general_info_title', sanitize_text_field($_POST['general_info_title']));
        }
        if (isset($_POST['general_info_zone'])) {
            update_post_meta($post_id, '_general_info_time_zone', sanitize_text_field($_POST['general_info_zone']));
        }
        if (isset($_POST['general_info_sub_title'])) {
            update_post_meta($post_id, '_general_info_sub_title', sanitize_text_field($_POST['general_info_sub_title']));
        }
        if (isset($_POST['general_info_title_2'])) {
            update_post_meta($post_id, '_general_info_title_2', sanitize_text_field($_POST['general_info_title_2']));
        }
        if (isset($_POST['general_info_zone_2'])) {
            update_post_meta($post_id, '_general_info_time_zone_2', sanitize_text_field($_POST['general_info_zone_2']));
        }
        if (isset($_POST['general_info_sub_title_2'])) {
            update_post_meta($post_id, '_general_info_sub_title_2', sanitize_text_field($_POST['general_info_sub_title_2']));
        }
        if (isset($_POST['general_info_title_3'])) {
            update_post_meta($post_id, '_general_info_title_3', sanitize_text_field($_POST['general_info_title_3']));
        }
        if (isset($_POST['general_info_zone_3'])) {
            update_post_meta($post_id, '_general_info_time_zone_3', sanitize_text_field($_POST['general_info_zone_3']));
        }
        if (isset($_POST['general_info_sub_title_3'])) {
            update_post_meta($post_id, '_general_info_sub_title_3', sanitize_text_field($_POST['general_info_sub_title_3']));
        }
        if (isset($_POST['general_info_title_4'])) {
            update_post_meta($post_id, '_general_info_title_4', sanitize_text_field($_POST['general_info_title_4']));
        }
        if (isset($_POST['general_info_zone_4'])) {
            update_post_meta($post_id, '_general_info_time_zone_4', sanitize_text_field($_POST['general_info_zone_4']));
        }
        if (isset($_POST['general_info_sub_title_4'])) {
            update_post_meta($post_id, '_general_info_sub_title_4', sanitize_text_field($_POST['general_info_sub_title_4']));
        }

        /** nearest destination */
        if (isset($_POST['tm_nearest_destination'])) {
            update_post_meta($post_id, '_is_nearest_destination', sanitize_text_field($_POST['tm_nearest_destination']));
        }

        /** Save coordinates and address */
        if (isset($_POST['city_latitude']) && isset($_POST['city_longitude'])) {
            $latitude = sanitize_text_field($_POST['city_latitude']);
            $longitude = sanitize_text_field($_POST['city_longitude']);
            $address = sanitize_text_field($_POST['city_address']);

            update_post_meta($post_id, '_city_latitude', $latitude);
            update_post_meta($post_id, '_city_longitude', $longitude);
            update_post_meta($post_id, '_city_address', $address);
        }

        /** Save FAQs */
        $faq_data = array();
        if (isset($_POST['faq_questions']) && isset($_POST['faq_answers'])) {
            $questions = $_POST['faq_questions'];
            $answers = $_POST['faq_answers'];

            $count = min(count($questions), count($answers));
            for ($i = 0; $i < $count; $i++) {
                $question = trim($questions[$i]);
                $answer = trim($answers[$i]);

                if (!empty($question) && !empty($answer)) {
                    $faq_data[] = array(
                        'question' => sanitize_text_field($question),
                        'answer' => wp_kses_post($answer)
                    );
                }
            }
        }

        if (!empty($faq_data)) {
            update_post_meta($post_id, '_city_faqs', $faq_data);
        } else {
            delete_post_meta($post_id, '_city_faqs');
        }

        // $fields = ['title', 'zone', 'sub_title'];

        // for ($i = 0; $i <= 4; $i++) {
        //     foreach ($fields as $field) {
        //         $post_key = 'general_info_' . $field . ($i === 0 ? '' : '_' . $i);
        //         $meta_key = '_general_info_' . $field . ($i === 0 ? '' : '_' . $i);

        //         if (isset($_POST[$post_key])) {
        //             update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$post_key]));
        //         }
        //     }
        // }



        // Save hotel URL
        // if (isset($_POST['tm_city_hotel_url'])) {
        //     $hotel_url = esc_url_raw($_POST['tm_city_hotel_url']);
        //     update_post_meta($post_id, '_tm_city_hotel_url', $hotel_url);
        // }

        // Save tour URL
        // if (isset($_POST['tm_city_tour_url'])) {
        //     $tour_url = esc_url_raw($_POST['tm_city_tour_url']);
        //     update_post_meta($post_id, '_tm_city_tour_url', $tour_url);
        // }
    }


    /**
     * @function    : tm_set_custom_edit_city_columns()
     * @description : set custom columns for city post type
     */
    public function tm_set_custom_edit_city_columns($columns)
    {
        $new_columns = array(
            'featured_image' => __('Image', 'text-domain'),
            'population' => 'Popular Destination',
            'country' => 'Country'
        );

        // Insert after title column
        $offset = array_search('title', array_keys($columns)) + 1;
        $columns = array_merge(
            array_slice($columns, 0, $offset),
            $new_columns,
            array_slice($columns, $offset)
        );

        return $columns;
    }

    /**
     * @function    : tm_custom_city_column()
     * @description : custom columns for city post type
     */
    public function tm_custom_city_column($column, $post_id)
    {
        switch ($column) {
            case 'featured_image':
                if (has_post_thumbnail($post_id)) {
                    echo get_the_post_thumbnail($post_id, array(80, 80));
                } else {
                    echo '<img src="' . plugin_dir_url(__FILE__) . '../../../assets/images/no-img.png" alt="" width="80" height="80" />';
                }
                break;
            case 'population':
                echo get_post_meta($post_id, '_city_population', true);
                break;
            case 'country':
                echo get_post_meta($post_id, '_city_country', true);
                break;
        }
    }

    /**
     * @function    : tm_filter_by_country()
     * @description : Adds a country filter dropdown in admin list for City post type
     */
    public function tm_filter_by_country()
    {
        global $typenow;

        if ($typenow !== 'city') {
            return;
        }

        // Get all unique countries used in the meta
        $countries = $this->tm_get_all_countries();

        if (empty($countries)) {
            return;
        }

        $selected = isset($_GET['city_country_filter']) ? $_GET['city_country_filter'] : '';

        echo '<select name="city_country_filter">';
        echo '<option value="">' . __('All Countries', 'text-domain') . '</option>';

        foreach ($countries as $country) {
            printf(
                '<option value="%s"%s>%s</option>',
                esc_attr($country),
                selected($selected, $country, false),
                esc_html($country)
            );
        }

        echo '</select>';
    }

    /**
     * @function    : tm_filter_city_by_country()
     * @description : Alters query to filter cities by selected country
     */
    public function tm_filter_city_by_country($query)
    {
        global $pagenow;

        if (!is_admin() || $pagenow !== 'edit.php' || $query->get('post_type') !== 'city') {
            return;
        }

        if (!empty($_GET['city_country_filter'])) {
            $query->set('meta_query', array(
                array(
                    'key' => '_city_country',
                    'value' => sanitize_text_field($_GET['city_country_filter']),
                    'compare' => '='
                )
            ));
        }
    }

    /**
     * @function    : tm_get_all_countries()
     * @description : Returns all unique countries from city meta
     */
    private function tm_get_all_countries()
    {
        global $wpdb;

        $results = $wpdb->get_col("
        SELECT DISTINCT meta_value 
        FROM {$wpdb->postmeta} 
        WHERE meta_key = '_city_country' 
        AND meta_value != ''
        ORDER BY meta_value ASC
    ");

        return $results;
    }

    /**
     * @function    : tm_get_cities_by_country()
     * @description : Returns all cities for a specific country
     * @param       : string $country - The country name
     * @return      : array of city posts
     */
    public function tm_get_cities_by_country($country)
    {
        $args = array(
            'post_type' => 'city',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_city_country',
                    'value' => $country,
                    'compare' => '='
                )
            ),
            'orderby' => 'title',
            'order' => 'ASC'
        );

        return get_posts($args);
    }

    /**
     * @function    : tm_get_cities_by_country_ajax()
     * @description : AJAX handler to get cities by country
     */
    public function tm_get_cities_by_country_ajax()
    {
        if (!isset($_POST['country']) || empty($_POST['country'])) {
            wp_die();
        }

        $country = sanitize_text_field($_POST['country']);
        $cities = $this->tm_get_cities_by_country($country);

        $options = '<option value="">' . __('Select a City', 'text-domain') . '</option>';
        foreach ($cities as $city) {
            $options .= '<option value="' . esc_attr($city->ID) . '">' . esc_html($city->post_title) . '</option>';
        }

        echo $options;
        wp_die();
    }


    /**
     * @function    : tm_enqueue_script_and_styles()
     * @description : Enqueue admin scripts and styles
     */
    public function tm_enqueue_script_and_styles()
    {
        if (!is_admin()) {
            return;
        }

        $screen = get_current_screen();

        // Enqueue for city post type
        if ($screen->post_type === 'city') {
            wp_enqueue_style(
                'city-manager-from-codzbee',
                plugin_dir_url(__FILE__) . '../../../assets/css/city.css',
                array(),
                1,
                'all'
            );

            wp_enqueue_script(
                'city-manager-from-codzbee-script',
                plugin_dir_url(__FILE__) . '../../../assets/js/city.js',
                array('jquery'),
                null,
                true
            );
        }

        // Enqueue for hotel post type (for the country-city dropdowns)
        if ($screen->post_type === 'hotel') {
            wp_enqueue_script(
                'hotel-city-manager-script',
                plugin_dir_url(__FILE__) . '../../../assets/js/hotel.js',
                array('jquery'),
                null,
                true
            );

            wp_localize_script('hotel-city-manager-script', 'hotel_city_manager', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('hotel_city_nonce')
            ));
        }
    }

}
