<?php
/** includes/backend/city.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}


/**
 * @class       : City
 * @description : load dependencies
 */
require_once plugin_dir_path(__FILE__) . 'city/class-city-post-type.php';
require_once plugin_dir_path(__FILE__) . 'city/class-city-meta-box.php';


/**
 * @class       : City
 * @description : All city details include this class.
 */
class City
{
    private $tm_city_post_type;
    private $tm_city_meta_box;

    public function __construct()
    {
        $this->tm_city_post_type = new City_Post_Type();
        $this->tm_city_meta_box = new City_Meta_Box();
    }
}