<?php

/**
 * @package Tour Manager
 * @version 1.0
 * @since 1.0
 * @description This class is the settings page for the Tour Manager plugin.
 * includes/backend/setting.php
 */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

class Setting
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'tm_add_settings_menu'));
        add_action('admin_init', array($this, 'tm_register_settings'));
    }

    public function tm_add_settings_menu()
    {
        add_submenu_page(
            'main_menu_of_tour_manager',
            'Global Settings',
            'Settings',
            'manage_options',
            'tm_global_settings',
            array($this, 'tm_render_settings_page')
        );
    }

    /**
     * Render the settings page.
     * @description This function generates the HTML for the settings page, including a sidebar for navigation and a form for saving settings.
     * It uses JavaScript to toggle the visibility of different setting sections based on user interaction.
     * @return void
     */
    public function tm_render_settings_page()
    {
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Global Settings</h1>
            <div style="display: flex;">

                <!-- Settings Content -->
                <div style="width: 75%; padding-left: 20px;">
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('tm_settings_group');
                        do_settings_sections('tm_global_settings');
                        submit_button('Save Changes');
                        ?>
                    </form>
                </div>
            </div>
        </div>

        <script>
            function showSetting(id) {
                const groups = document.querySelectorAll('.tm-setting-group');
                groups.forEach(group => group.style.display = 'none');

                const selected = document.getElementById('setting_' + id);
                if (selected) selected.style.display = 'block';
            }
        </script>
        <?php
    }

    /**
     * Summary of tm_register_settings
     * @description This function registers the settings for the plugin.
     * @return void
     */
    public function tm_register_settings()
    {
        register_setting('tm_settings_group', 'tm_admin_email');
        register_setting('tm_settings_group', 'tm_google_map_api');
        register_setting('tm_settings_group', 'tm_core_api_key');
        register_setting('tm_settings_group', 'tm_core_api_endpoint');
        register_setting('tm_settings_group', 'tm_booking_engine_url');

        add_settings_section('tm_main_section', '', function () {}, 'tm_global_settings');

        /**
         * Admin Email Configuration
         */
        add_settings_field(
            'tm_admin_email',
            'Admin Configuration',
            function () {
                $value = get_option('tm_admin_email', get_bloginfo('gl_admin_email'));
                echo '<div id="setting_admin_email" class="tm-setting-group">';
                echo '<p>Admin Email</p>';
                echo '<input type="email" name="tm_admin_email" value="' . esc_attr($value) . '" class="regular-text">';
                echo '</div>';
            },
            'tm_global_settings',
            'tm_main_section'
        );

        /**
         * Google Map Configuration
         */
        add_settings_field(
            'tm_google_map_api',
            'Google Configuration',
            function () {
                $value = get_option('tm_google_map_api', get_bloginfo('map_api'));
                echo '<div id="setting_google_map" class="tm-setting-group" >';
                echo '<p>Google Map API key</p>';
                echo '<input type="text" name="tm_google_map_api" value="' . esc_attr($value) . '" class="regular-text">';
                echo '</div>';
            },
            'tm_global_settings',
            'tm_main_section'
        );

        /**
         * Booking Engine Configuration
         */
        add_settings_field(
            'tm_booking_section',
            'Booking Engine Configuration',
            function () {
                echo '<div id="setting_booking" class="tm-setting-group" >';
                echo '<p>Core API key</p>';
                echo '<input type="text" name="tm_core_api_key" value="' . esc_attr(get_option('tm_core_api_key')) . '" class="regular-text">';
                echo '<p>Core API endpoint</p>'; // Booking engine url
                echo '<input type="text" name="tm_core_api_endpoint" value="' . esc_attr(get_option('tm_core_api_endpoint')) . '" class="regular-text">';
                echo '<p>Booking Engine URL</p>';
                echo '<input type="text" name="tm_booking_engine_url" value="' . esc_attr(get_option('tm_booking_engine_url')) . '" class="regular-text">';
                echo '</div>';
            },
            'tm_global_settings',
            'tm_main_section'
        );

    }

}