<?php
/** 
 * @package Tour Manager
 * @version 1.0
 * @since 1.0
 * @description This class handles AJAX requests for the Booking Engine.
 * includes/backend/booking-engine/class-booking-engine-ajax-handler.php 
 */

if (!defined('ABSPATH')) {
    exit;
}

class BookingEngineAjaxHandler
{

    private $core_api_key;
    private $core_api_endpoint;
    private $booking_engine_url;

    public function __construct()
    {
        $this->core_api_key = get_option('tm_core_api_key');
        $this->core_api_endpoint = get_option('tm_core_api_endpoint');
        $this->booking_engine_url = get_option('tm_booking_engine_url');
        
        add_action('wp_ajax_nopriv_tm_booking_engine_request', array($this, 'booking_engine_request'));
        add_action('wp_ajax_tm_booking_engine_request', array($this, 'booking_engine_request'));

        wp_enqueue_script(
            'booking-engine-script',
            plugin_dir_url(__FILE__) . '../../../assets/js/booking-engine.js',
            array('jquery'),
            null,
            true
        );

        // Localize script for AJAX
        wp_localize_script('booking-engine-script', 'server_data', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'booking_engine_url' => $this->booking_engine_url
            // 'nonce' => wp_create_nonce('tm_booking_engine_request')
        ]);
        

        /** AJAX actions for getting settings */
        // add_action('wp_ajax_tm_get_booking_settings', array($this, 'get_booking_settings'));
    }

    public function booking_engine_request()
    {

        $method = $_SERVER['REQUEST_METHOD'];
        $headers = array_change_key_case(getallheaders(), CASE_LOWER);
        // Extract the API path from custom header
        if (empty($headers['core-api-url'])) {
            wp_send_json_error(['message' => 'Missing core-api-url header'], 400);
        }

        $api_path = ltrim($headers['core-api-url'], '/'); // e.g., "v1/products"

        // Build the query string, excluding 'action' param
        $query_params = $_GET;
        unset($query_params['action']); // WordPress-specific, not needed by API

        $query_string = http_build_query($query_params);
        $target_url = $this->core_api_endpoint . '/' . $api_path;
        if (!empty($query_string)) {
            $target_url .= '?' . $query_string;
        }

        // Grab the raw body (JSON, form data, etc.)
        $body = file_get_contents('php://input');

        // Prepare headers for remote API
        $api_headers = [
            'Content-Type' => $headers['Content-Type'] ?? 'application/json',
            'Accept' => 'application/json',
            'api-key' => $this->core_api_key, // Secret only on server
        ];

        // Forward the request
        $response = wp_remote_request($target_url, [
            'method' => $method,
            'headers' => $api_headers,
            'body' => $body,
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'Request failed',
                'error' => $response->get_error_message(),
            ], 500);
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        // Send back the API's response directly
        status_header($status_code);
        echo $response_body;
        wp_die();
    }

}