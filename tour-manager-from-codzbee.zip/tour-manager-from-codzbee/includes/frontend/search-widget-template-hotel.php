<?php
/** 
 * @package Tour Manager
 * @version 1.0
 * @since 1.0
 * @description This class is the search widget template for the Tour Manager plugin.
 * includes/frontend/search-widget-template-hotel.php
 */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

class Search_widget_template_hotel
{
    public function __construct()
    {
        add_shortcode('tm_search_widget_hotel_globelodger', array($this, 'tm_search_widget_template_hotel'));
        add_action('wp_enqueue_scripts', array($this, 'tm_enqueue_search_widget_hotel_assets'));
    }

    public function tm_search_widget_template_hotel()
    {
        ?>

        <form action="<?= esc_url(home_url('/search-results/')); ?>" method="get" id="hotel-search-form"
            style="width: 100%; padding: 5px;">

            <div class="grid grid-cols-1 sm:grid-cols-4 gap-2 px-4">

                <!-- Destination -->
                <div class="relative mb-2 mt-2">
                    <div class="text-secondary font-medium text-md">Destination</div>
                    <select class="destination-select text-dark text-sm" name="destination-value"></select>
                </div>

                <!-- Check-in + Check-out in one column -->
                <div class="grid grid-cols-2 gap-2 mb-2 mt-2" style="grid-template-columns: 1fr 1fr;">

                    <!-- Check-in -->
                    <div>
                        <div class="text-secondary font-medium text-md">Check-in</div>
                        <input type="text" id="checkin" name="checkin" class="border text-dark text-sm w-full" placeholder="Select date"
                            required>
                    </div>

                    <!-- Check-out -->
                    <div>
                        <div class="text-secondary font-medium text-md">Check-out</div>
                        <input type="text" id="checkout" name="checkout" class="border text-dark text-sm w-full"
                            placeholder="Select date" required>
                    </div>

                </div>

                <!-- Guests -->
                <div class="relative mb-2 mt-2">
                    <div class="text-secondary font-medium text-md">Guests</div>
                    <input type="text" id="guest-display" name="guest_display" class="border text-dark text-sm w-full cursor-pointer"
                        placeholder="2 adults, 0 children, 1 room" readonly>
                    <input type="hidden" id="guests-data" name="guests_data">

                    <!-- Guests modal -->
                    <div id="guest-modal" class="absolute hidden bg-white p-10 mt-4 overflow-y-auto rounded-sm shadow-lg"
                        style="width: 120%; z-index: 3000;">

                        <div class="px-3 py-3">
                            <button type="button" id="close-modal" class="absolute top-2 right-0 px-4">
                                <span class="text-xl">×</span>
                            </button>

                            <div id="rooms-container"></div>

                            <div class="mt-4">
                                <button type="button" id="add-room"
                                    class="border border-secondary border-2 text-secondary px-4 py-2 w-full rounded-sm cursor-pointer hover:bg-secondary/10">
                                    + Add Room
                                </button>
                            </div>

                            <div class="mt-2">
                                <div class="flex justify-end">
                                    <button type="button" id="apply-guests"
                                        class="bg-secondary text-white px-4 py-2 w-full rounded-sm cursor-pointer hover:bg-primary">
                                        x Done
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Search -->
                <div class="flex md:justify-end mb-2 mt-2">
                    <button type="submit" class="bg-secondary text-white px-10 py-2 rounded-sm w-full">
                        <i class="fas fa-search mr-2"></i>Search
                    </button>
                </div>

            </div>

        </form>

        <?php
    }

    public function tm_enqueue_search_widget_hotel_assets()
    {
        wp_enqueue_style(
            'search-widget-style',
            plugin_dir_url(__FILE__) . '../../assets/css/search-widget.css',
            array(),
            1,
            'all'
        );

        wp_enqueue_script(
            'search-widget-script',
            plugin_dir_url(__FILE__) . '../../assets/js/search-widget.js',
            array('jquery'),
            null,
            true
        );

        // Localize script for AJAX
        wp_localize_script('search-widget-script', 'hotel_search_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            // 'nonce' => wp_create_nonce('tm_booking_engine_request')
        ]);

        wp_enqueue_style('datepicker-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css');
        wp_enqueue_script('datepicker-js', 'https://code.jquery.com/jquery-3.7.0.min.js');
        wp_enqueue_script('datepicker-ui-js', 'https://code.jquery.com/ui/1.13.2/jquery-ui.min.js');

        wp_enqueue_style('select-2-css', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
        wp_enqueue_script('select-2-js', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js');
    }
}