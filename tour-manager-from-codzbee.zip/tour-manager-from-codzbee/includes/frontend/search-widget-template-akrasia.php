<?php
/** includes/frontend/search-widget-template-akrasia.php */

class Search_widget_template_akrasia
{
    private $cities_data = [];

    public function __construct()
    {
        $this->load_cities_data();
        add_shortcode('tm_search_widget_akrasia', array($this, 'tm_search_widget_template_akrasia'));
        // add_action('wp_enqueue_scripts', array($this, 'enqueue_search_widget_assets'));
    }

    private function load_cities_data()
    {
        $file_path = plugin_dir_path(__FILE__) . '../../assets/data/cities.json';
        if (file_exists($file_path)) {
            $cities_json = file_get_contents($file_path);
            $this->cities_data = json_decode($cities_json, true) ?: [];
        }
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Cities JSON error: ' . json_last_error_msg());
        }
    }

    public function tm_search_widget_template_akrasia()
    {
        /** Fetch categories */
        $categories = get_terms(array(
            'taxonomy' => 'tour_category',
            'hide_empty' => false,
        ));

        /** Fetch duration days and nights from tours */
        $durations = get_posts(array(
            'post_type' => 'tour',
            'posts_per_page' => -1,
        ));

        $duration_days = [];
        foreach ($durations as $duration) {
            $post_id = $duration->ID;
            $itinerary = get_post_meta($post_id, '_trip_itinerary', true);
            $total_days = !empty($itinerary['days']) ? count($itinerary['days']) : 0;
            $total_night = max(0, $total_days - 1);
            $duration_days[] = "$total_night Nights - $total_days Days";
        }

        /** Ensure unique durations */
        $duration_days = array_unique($duration_days);

        /** Handle selected values */
        $selected_category = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
        $selected_duration = isset($_GET['duration_days']) ? sanitize_text_field($_GET['duration_days']) : '';
        $selected_location = isset($_GET['tour-location']) ? intval($_GET['tour-location']) : '';

        // Get selected values for display
        $selected_category_name = $selected_category ? get_term_by('slug', $selected_category, 'tour_category')->name : '';
        $selected_location_name = '';
        if ($selected_location) {
            foreach ($this->cities_data as $city) {
                if (isset($city['id']) && $city['id'] == $selected_location) {
                    $selected_location_name = $city['name'];
                    break;
                }
            }
        }

        ob_start();
        ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

        <!-- <div class="search-widget"> -->
        <form method="GET" action="<?= esc_url(get_post_type_archive_link('tour')); ?>">
            <div class="search-bar-container">
                <!-- Categories Search Dropdown -->
                <div class="search-group sm:w-1/4 w-full sm:border-r border-dark/25 sm:my-0 my-5">
                    <div class="px-5 typeahead-widget">
                        <input type="hidden" name="category" id="tm_category" value="<?= esc_attr($selected_category); ?>">
                        <label for="category" class="block text-md font-medium text-secondary" name="category" id="category">Category</label>
                        <input type="text" name="category" class="typeahead-input text-dark/50 cursor-pointer" placeholder="Choose a Tour Type"
                            value="<?= esc_attr($selected_category_name); ?>" data-target="categoryOptions"
                            style="color: #697488" ;>
                        <div id="categoryOptions" class="typeahead-options">
                            <div class="typeahead-option" data-value="">All Categories</div>
                            <?php foreach ($categories as $category): ?>
                                <div class="typeahead-option" data-value="<?= esc_attr($category->slug); ?>">
                                    <?= esc_html($category->name); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Duration Search Dropdown -->
                <div class="search-group sm:w-1/4 w-full sm:border-r border-dark/25 sm:my-0 my-5">
                    <div class="px-5 typeahead-widget">
                        <input type="hidden" name="duration_days" id="tm_duration_days"
                            value="<?= esc_attr($selected_duration); ?>">
                        <label class="block text-md font-medium text-secondary">Duration</label>
                        <input type="text" class="typeahead-input" placeholder="Search duration..."
                            value="<?= esc_attr($selected_duration); ?>" data-target="durationOptions" style="color: #697488" ;>
                        <div id="durationOptions" class="typeahead-options">
                            <div class="typeahead-option" data-value="">Any Duration</div>
                            <?php foreach ($duration_days as $duration_day): ?>
                                <div class="typeahead-option" data-value="<?= esc_attr($duration_day); ?>">
                                    <?= esc_html($duration_day); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Locations Search Dropdown -->
                <div class="search-group sm:w-1/4 w-full sm:border-r border-dark/25 sm:my-0 my-5">
                    <div class="px-5 typeahead-widget">
                        <input type="hidden" name="tour-location" id="tm_location" value="<?= esc_attr($selected_location); ?>">
                        <label class="block text-md font-medium text-secondary">Location</label>
                        <input type="text" class="typeahead-input" placeholder="Search location..."
                            value="<?= esc_attr($selected_location_name); ?>" data-target="locationOptions"
                            style="color: #697488" ;>
                        <div id="locationOptions" class="typeahead-options">
                            <div class="typeahead-option" data-value="">Any Location</div>
                            <?php foreach ($this->cities_data as $city):
                                if (isset($city['id'], $city['name'])): ?>
                                    <div class="typeahead-option" data-value="<?= absint($city['id']); ?>">
                                        <?= esc_html($city['name']); ?>
                                    </div>
                                <?php endif;
                            endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class=" search-group sm:w-1/4 w-full sm:mt-0 mt-5">
                    <button
                        class="bg-secondary w-full h-full hover:bg-primary text-white font-medium py-3 sm:rounded-full rounded-sm transition duration-200 flex items-center justify-center">
                        <i class="fa-solid fa-magnifying-glass mr-3"></i>
                        <div class="text-md font-medium">Search</div>
                    </button>
                </div>
            </div>
        </form>
        <!-- </div> -->

        <style>
            .search-bar-container {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                align-items: center;
            }

            .search-group {
                flex: 1;
                min-width: 240px;
                position: relative;
            }

            .typeahead-input {
                width: 100%;
                /* padding: 10px 15px; */
                border: none;
                outline: none;
            }

            .typeahead-options {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                max-height: 300px;
                overflow-y: auto;
                background: #fff;
                /* border: 1px solid #ddd; */
                border-radius: 4px;
                box-shadow: 0 2px 5px rgba(94, 93, 93, 0.1);
                z-index: 100;
            }

            .typeahead-option {
                padding: 10px 15px;
                cursor: pointer;
                border-bottom: 1px solid #eee;
            }

            .typeahead-option:last-child {
                border-bottom: none;
            }

            .typeahead-option:hover {
                background-color: #f5f5f5;

            }

            /* .typeahead-no-results {
                        padding: 10px 15px;
                        color: #999;
                        font-style: italic;
                    } */

            /* .search-button {
                        flex: 0 0 auto;
                    } */

            /* .search-button button {
                        padding: 10px 20px;
                
                        color: white;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        gap: 8px;
                    } */



            @media (max-width: 768px) {
                .search-group {
                    min-width: 100%;
                }
            }
        </style>

        <script>
            jQuery(document).ready(function ($) {
                // Initialize all typeahead widgets
                $('.typeahead-widget').each(function () {
                    var $widget = $(this);
                    var $hiddenInput = $widget.find('input[type="hidden"]');
                    var $visibleInput = $widget.find('.typeahead-input');
                    var $optionsContainer = $widget.find('.typeahead-options');
                    var options = $optionsContainer.find('.typeahead-option');

                    // Toggle options on input click
                    $visibleInput.on('click', function (e) {
                        e.stopPropagation(); // Prevent document click handler from hiding it immediately
                        if ($optionsContainer.is(':visible')) {
                            $optionsContainer.hide();
                        } else {
                            $optionsContainer.show();
                            filterOptions($visibleInput.val());
                        }
                    });

                    // Also show on focus for tab navigation
                    $visibleInput.on('focus', function () {
                        $optionsContainer.show();
                        filterOptions($visibleInput.val());
                    });

                    // Filter options as user types
                    $visibleInput.on('input', function () {
                        // If input is empty, clear the hidden value
                        if ($(this).val() === '') {
                            $hiddenInput.val('');
                        }
                        filterOptions($(this).val());
                    });

                    // Select an option
                    $optionsContainer.on('click', '.typeahead-option', function (e) {
                        e.stopPropagation(); // Prevent event from bubbling to document
                        var value = $(this).data('value');
                        var text = $(this).text();

                        $hiddenInput.val(value);
                        $visibleInput.val(text);
                        $optionsContainer.hide();
                    });

                    // Clear both inputs when clicking the "clear" option (empty value)
                    $optionsContainer.on('click', '.typeahead-option[data-value=""]', function (e) {
                        e.stopPropagation();
                        $hiddenInput.val('');
                        $visibleInput.val('');
                        $optionsContainer.hide();
                    });

                    // Hide options when clicking outside
                    $(document).on('click', function (e) {
                        if (!$(e.target).closest('.typeahead-widget').length) {
                            $optionsContainer.hide();
                        }
                    });

                    // Filter function
                    function filterOptions(searchTerm) {
                        var term = searchTerm.toLowerCase();
                        var anyMatches = false;

                        options.each(function () {
                            var $option = $(this);
                            var optionText = $option.text().toLowerCase();

                            if (optionText.includes(term)) {
                                $option.show();
                                anyMatches = true;
                            } else {
                                $option.hide();
                            }
                        });

                        // Show "no results" if no matches
                        if (!anyMatches) {
                            $optionsContainer.append('<div class="typeahead-no-results">No results found</div>');
                        } else {
                            $optionsContainer.find('.typeahead-no-results').remove();
                        }
                    }
                });
            });
        </script>

        <?php
        return ob_get_clean();
    }


}