<?php
/** includes/frontend/inquiry-form.php */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

/** Load the shortcode handler */
require_once plugin_dir_path(__FILE__) . 'shortcodes/class-inquiry-form.php';