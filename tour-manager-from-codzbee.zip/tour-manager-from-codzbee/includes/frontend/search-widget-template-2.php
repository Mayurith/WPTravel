<?php
/** includes/frontend/search-widget-template-2.php */

if (!defined('ABSPATH'))
    exit;

class TM_Search_Widget_2
{
    public function __construct()
    {
        add_shortcode('tm_tour_search_widget_globelodger', [$this, 'tm_search_widget_country_month_template']);
        add_action('wp_enqueue_scripts', [$this, 'add_search_widget_scripts']);
    }

    public function add_search_widget_scripts()
    {
        // Enqueue the script properly
        wp_enqueue_script(
            'tm-search-widget-2',
            plugin_dir_url(__FILE__) . '../../assets/js/search-widget.js',
            ['jquery'],
            '1.0.0',
            true
        );

        wp_enqueue_style(
            'tm-search-widget-2',
            plugin_dir_url(__FILE__) . '../../assets/css/search-widget.css',
            [],
            '1.0.0'
        );

        // Add inline CSS
        // wp_add_inline_style('wp-block-library', $this->get_widget_css());
    }


    public function tm_search_widget_country_month_template()
    {
        $tours = get_posts(['post_type' => 'tour', 'posts_per_page' => -1, 'post_status' => 'publish']);
        $categories = get_terms(['taxonomy' => 'tour_category', 'hide_empty' => true]);
        $countries = [];
        $available_months = [];

        foreach ($tours as $tour) {
            $itinerary = get_post_meta($tour->ID, '_trip_itinerary', true);
            if (!empty($itinerary) && is_array($itinerary)) {
                foreach ($itinerary as $day) {
                    if (!empty($day['country']))
                        $countries[] = sanitize_text_field($day['country']);
                }
            }
        }

        // available months from all tours
        foreach ($tours as $tour) {
            $months = get_post_meta($tour->ID, '_available_months', true);
            if (!empty($months) && is_array($months)) {
                foreach ($months as $month) {
                    $available_months[] = sanitize_text_field($month);
                }
            }
        }

        if (!empty($_GET['category'])) {
            $category_slug = sanitize_text_field($_GET['category']);
            $category = get_term_by('slug', $category_slug, 'tour_category');

            if ($category) {
                $category_name = $category->name;
                echo esc_html($category_name);
            }
        }

        $countries = array_unique($countries);
        sort($countries);

        $available_months = array_unique($available_months);
        sort($available_months);

        $selected_country = $_GET['country'] ?? '';
        $selected_months = $_GET['months'] ?? '';
        $selected_category = $_GET['category'] ?? '';

        $months = [
            'Jan' => 'Jan',
            'Feb' => 'Feb',
            'Mar' => 'Mar',
            'Apr' => 'Apr',
            'May' => 'May',
            'Jun' => 'Jun',
            'Jul' => 'Jul',
            'Aug' => 'Aug',
            'Sep' => 'Sep',
            'Oct' => 'Oct',
            'Nov' => 'Nov',
            'Dec' => 'Dec'
        ];

        $selected_month_array = $selected_months ? explode(',', $selected_months) : [];

        // Get display values
        // $country_display = 'Select Destination';
        $month_display = $selected_months ? implode(', ', array_intersect_key($months, array_flip($selected_month_array))) : '';
        $category_display = $selected_category ?: '';

        ob_start(); ?>
        <form method="get" action="<?= esc_url(get_post_type_archive_link('tour')); ?>" class="tour-widget">
            <div class="grid lg:grid-cols-4 md:grid-cols-1 gap-5 px-4 bg-white py-4 rounded-sm shadow-sm text-left">

                <!-- Country -->
                <div class="dropdown-container">
                    <div class="cursor-pointer justify-between items-center text-secondary font-medium">
                        <span class="">Select Destination</span>
                        <!-- <i class="fas fa-chevron-down ml-2 text-gray-400 text-xs"></i> -->
                    </div>
                    <input type="text" name="country" id="selected-country" value="<?= esc_attr($selected_country); ?>"
                        placeholder="Where to Next" class="dropdown-toggle text-dark text-sm">
                    <div class="dropdown-menu country-menu text-sm overflow-y-auto absolute z-50 bg-white border border-gray-200 rounded-md shadow-lg w-full hidden"
                        style="display: none; max-height: 200px;">
                        <?php foreach ($countries as $country): ?>
                            <div class="typeahead-option px-4 py-2 hover:bg-secondary/10 cursor-pointer"
                                data-value="<?= esc_attr($country); ?>">
                                <?= esc_html($country); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Month -->
                <div class="dropdown-container month-container">
                    <div class="cursor-pointer justify-between items-center text-secondary font-medium">
                        <span class="">Travel Month</span>
                        <!-- <i class="fas fa-chevron-down ml-2 text-gray-400 text-xs"></i> -->
                    </div>
                    <input type="text" name="months" id="selected-months"
                        class="dropdown-toggle dropdown-text text-dark text-sm" value="<?= esc_html($month_display); ?>"
                        placeholder="Select Month">
                    <div class="dropdown-menu month-menu text-sm" style="display: none;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; padding: 10px;">
                            <?php foreach ($months as $num => $name): ?>
                                <div class="month-option <?= in_array($num, $selected_month_array) ? 'bg-secondary text-white' : 'hover:bg-gray-100'; ?> mb-2 mt-2 rounded-sm cursor-pointer text-center"
                                    data-value="<?= esc_attr($num); ?>"><?= esc_html($name); ?></div>
                            <?php endforeach; ?>
                        </div>
                        <div class="flex justify-between border-t border-gray-200 px-6 py-2">
                            <button type="button"
                                class="clear-months text-sm text-secondary bg-secondary/10 hover:bg-secondary hover:text-white px-2 py-1 rounded-sm cursor-pointer">Clear</button>
                            <button type="button"
                                class="apply-months text-sm text-white font-semibold bg-secondary hover:bg-primary px-2 py-1 rounded-sm cursor-pointer">Apply</button>
                        </div>
                    </div>
                </div>

                <!-- Category -->
                <div class="dropdown-container relative">
                    <div class="cursor-pointer justify-between items-center text-secondary font-medium">
                        <span class="">Category</span>
                    </div>
                    <input type="text" name="category" id="selected-category" value="<?= esc_attr($category_display); ?>"
                        class="dropdown-toggle dropdown-text text-dark text-sm" placeholder="Select Tour Type" readonly>
                    <div class="dropdown-menu category-menu text-sm overflow-y-auto absolute z-50 bg-white border border-gray-200 w-full hidden"
                        style="display: none; max-height: 200px;">
                        <!-- Add "All Categories" option -->
                        <div class="typeahead-option px-4 py-2 hover:bg-gray-100 cursor-pointer"
                            data-value="All Categories">
                            All Categories
                        </div>
                        <?php foreach ($categories as $category): ?>
                            <div class="typeahead-option px-4 py-2 hover:bg-gray-100 cursor-pointer"
                                data-value="<?= esc_attr($category->name); ?>">
                                <?= esc_html($category->name); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Button -->
                <div class="w-full">
                    <button type="submit"
                        class="w-full bg-secondary text-white px-6 py-2 rounded-sm hover:bg-primary cursor-pointer transition">
                        <i class="fas fa-search mr-2"></i>Search
                    </button>
                </div>

            </div>
        </form>

        <script>
            jQuery(document).ready(function ($) {
                'use strict';

                // Initialize dropdowns
                function initializeDropdowns() {
                    // Country
                    const countryVal = $('#selected-country').val();
                    if (countryVal) {
                        const countryText = $('.country-menu .typeahead-option[data-value="' + countryVal + '"]').text();
                        $('.country-container .dropdown-text').text(countryText);
                    }

                    // Months
                    const monthsVal = $('#selected-months').val();
                    if (monthsVal) {
                        const monthNames = [];
                        const monthNumbers = monthsVal.split(',');
                        monthNumbers.forEach(num => {
                            const monthText = $('.month-option[data-value="' + num + '"]').text();
                            monthNames.push(monthText);
                        });
                        $('.month-container .dropdown-text').text(monthNames.join(', '));

                        // Set selected state for months
                        $('.month-option').removeClass('selected bg-secondary text-white');
                        monthNumbers.forEach(num => {
                            $('.month-option[data-value="' + num + '"]').addClass('selected bg-secondary text-white');
                        });
                    }

                    // Category
                    const categoryVal = $('#selected-category').val();
                    if (categoryVal) {
                        const categoryText = $('.category-menu .typeahead-option[data-value="' + categoryVal + '"]').text();
                        $('.category-container .dropdown-text').text(categoryText);
                    } else {
                        // If no category is selected, show "All Categories" as the display text
                        $('.category-container .dropdown-text').text('All Categories');
                    }
                }

                // Initialize on page load
                initializeDropdowns();

                // Toggle dropdowns
                $('.dropdown-toggle').on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();

                    const $this = $(this);
                    const $container = $this.closest('.dropdown-container');
                    const $menu = $container.find('.dropdown-menu');

                    // Close all other dropdowns
                    $('.dropdown-menu').not($menu).slideUp(150).removeClass('active');

                    // Toggle current dropdown
                    if ($menu.is(':visible')) {
                        $menu.slideUp(150).removeClass('active');
                    } else {
                        $menu.slideDown(150).addClass('active');
                    }
                });

                // Close when clicking outside
                $(document).on('click', function (e) {
                    if (!$(e.target).closest('.dropdown-container').length) {
                        $('.dropdown-menu').slideUp(150).removeClass('active');
                    }
                });

                // Country option click
                $('.country-menu .typeahead-option').on('click', function () {
                    const value = $(this).data('value');
                    const text = $(this).text().trim();

                    $('#selected-country').val(value);
                    $(this).closest('.dropdown-container').find('.dropdown-text').text(text);
                    $('.country-menu').slideUp(150).removeClass('active');
                });

                // Month option click
                $('.month-option').on('click', function () {
                    $(this).toggleClass('selected bg-secondary text-white');
                });

                // Apply months
                $('.apply-months').on('click', function () {
                    const selectedMonths = [];
                    const selectedMonthNames = [];

                    $('.month-option.selected').each(function () {
                        selectedMonths.push($(this).data('value'));
                        selectedMonthNames.push($(this).text().trim());
                    });

                    const $container = $(this).closest('.dropdown-container');

                    if (selectedMonths.length > 0) {
                        $('#selected-months').val(selectedMonths.join(','));
                        $container.find('.dropdown-text').text(selectedMonthNames.join(', '));
                    } else {
                        $('#selected-months').val('');
                        $container.find('.dropdown-text').text('Travel Month');
                    }

                    $('.month-menu').slideUp(150).removeClass('active');
                });

                // Clear months
                $('.clear-months').on('click', function () {
                    $('.month-option').removeClass('selected bg-secondary text-white');
                    $('#selected-months').val('');
                    $('.month-container .dropdown-text').text('Travel Month');
                    $('.month-menu').removeClass('active');
                });

                // Category option click
                $('.category-menu .typeahead-option').on('click', function () {
                    const value = $(this).data('value');
                    const text = $(this).text().trim();

                    $('#selected-category').val(value);
                    $(this).closest('.dropdown-container').find('.dropdown-text').text(text);
                    $('.category-menu').slideUp(150).removeClass('active');
                });

                // Form validation and submission
                $('form.tour-widget').on('submit', function (e) {
                    const countryValue = $('#selected-country').val().trim();

                    // Validate destination (required)
                    if (!countryValue) {
                        e.preventDefault();
                        alert('Please select a destination');
                        $('#selected-country').closest('.dropdown-container').find('.dropdown-toggle').focus();
                        return false;
                    }

                    // If we reach here, validation passed
                    return true;
                });

            });
        </script>
        <?php
        return ob_get_clean();
    }
}