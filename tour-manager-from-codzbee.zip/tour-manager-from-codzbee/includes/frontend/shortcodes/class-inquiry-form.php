<?php
/** includes/frontend/shortcodes/class-inquiry-form.php */

if (!defined('ABSPATH')) {
    exit;
}

class Inquiry_Form_Shortcode
{
    public function __construct()
    {
        add_shortcode('tm_inquiry_form', [$this, 'render_form']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function render_form()
    {
        /** Fetch tour categories */
        $tour_categories = get_terms(array(
            'taxonomy' => 'tour_category',
            'hide_empty' => false,
        ));

        ob_start();

        /**
         * @var mixed
         * Path to the JSON file containing country data.
         */
        $countries_json_path = plugin_dir_path(__DIR__) . '/../../assets/data/countries.json';

        $countries = [];
        if (file_exists($countries_json_path)) {
            $countries = json_decode(file_get_contents($countries_json_path), true);
        }
        ?>

        <section class="container mx-auto mt-20 px-4 lg:mt-20">
            <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 border border-secondary rounded-lg">
                <!-- left side -->
                <div class="bg-secondary text-center flex flex-col items-center justify-center px-10 py-6">
                    <a href="<?= esc_url(home_url('/')); ?>">
                        <img src="<?= get_template_directory_uri(); ?>/assets/images/logo.png" alt="logo"
                            class="w-auto h-14 object-contain" />
                    </a>
                    <div class="text-2xl font-semibold text-white mt-6">Design Your Dream Vacation</div>
                    <div class="text-white text-sm mt-6 text-center">
                        Our expert travel designers are here to turn your travel dreams into reality. Just tell us what you
                        love your
                        interests, preferences, and any special requests and we'll craft a custom itinerary just for you. It's
                        all
                        about creating a trip that reflects your style and delivers unforgettable experiences, every step of the
                        way.
                    </div>
                </div>

                <!-- right side -->
                <div class="py-6 px-10">
                    <form id="tour-inquiry-form" method="post" novalidate>
                        <!-- tour details -->
                        <div class="grid lg:grid-rows-2 md:grid-rows-2 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="tour_category" class="block mb-2 text-sm font-medium text-gray-700">Tour Category
                                    *</label>
                                <select id="tour_category" name="tour_category"
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate">
                                    <option value="">Select Category</option>
                                    <?php foreach ($tour_categories as $category): ?>
                                        <option value="<?= esc_attr($category->slug); ?>"><?= esc_html($category->name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="arrival_date" class="block mb-2 text-sm font-medium text-gray-700">Arrival Date
                                    *</label>
                                <input type="text" id="arrival_date" name="arrival_date" required
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate">
                            </div>
                        </div>
                        <div class="grid lg:grid-rows-2 md:grid-rows-2 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="adults" class="block mb-2 mt-2 text-sm font-medium text-gray-700">Adults *</label>
                                <input type="number" id="adults" name="adults" min="1" max="50" required
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate">
                            </div>
                            <div>
                                <label for="children" class="block mb-2 mt-2 text-sm font-medium text-gray-700">Children</label>
                                <input type="number" id="children" name="children" min="0" max="50"
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary">
                            </div>
                        </div>

                        <!-- other requests -->
                        <div class="text-2xl font-semibold text-primary mt-4 mb-3">Your Other Requests</div>
                        <div class="text-dark mb-3 text-sm">Kindly provide any further details regarding your budget, passenger
                            count,
                            desired destinations, or other preferences to help us tailor our services to your needs.</div>

                        <textarea name="message" id="message" cols="30" rows="6"
                            placeholder="Please provide your detailed requirements here..."
                            class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 mt-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate"></textarea>

                        <!-- contact details -->
                        <div class="text-2xl font-semibold text-primary mt-6 mb-3">Your Contact Details</div>
                        <div class="grid lg:grid-rows-2 md:grid-rows-2 sm:grid-cols-2 gap-4">
                            <div class="mb-4">
                                <label for="full_name" class="block mb-2 text-sm font-medium text-gray-700">Full Name *</label>
                                <input type="text" id="full_name" name="full_name" placeholder="John Smith" required
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate">
                            </div>
                            <div class="mb-4">
                                <label for="email" class="block mb-2 text-sm font-medium text-gray-700">Email *</label>
                                <input type="email" id="email" name="email" placeholder="example@gmail.com" required
                                    class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate">
                            </div>
                        </div>
                        <div class="grid lg:grid-rows-2 md:grid-rows-2 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="phone" class="block mb-2 text-sm font-medium text-gray-700">Phone Number *</label>
                                <div class="relative">
                                    <input type="tel" id="phone" name="phone" required
                                        class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate tm-phone-input">
                                    <input type="hidden" id="full_phone" name="full_phone">
                                </div>
                            </div>
                            <div>
                                <label for="country" class="block mb-2 text-sm font-medium text-gray-700">Country
                                    *</label>
                                <div class="relative">
                                    <input type="text" id="country" name="country" placeholder="Start typing country name..."
                                        required
                                        class="w-full text-sm text-dark border border-gray-200 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-secondary tm-validate tm-country-input">
                                    <div id="country-suggestions"
                                        class="absolute z-10 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto hidden">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <div class="py-4 flex gap-4 justify-end">
                            <button type="submit" id="tour-inquiry-btn"
                                class="border bg-secondary text-white px-6 py-2 rounded-sm hover:bg-primary transition-all text-center font-semibold cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed">
                                Inquiry Now
                            </button>
                        </div>
                    </form>


                    <div id="tm-inquiry-modal"
                        class="fixed inset-0 flex bg-black/50 backdrop-blur-sm z-50 mx-auto items-center justify-center"
                        style="display: none; background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(0px);">

                        <!-- Modal Card -->
                        <div class="bg-white rounded-lg px-8 py-4 shadow-xl animate-fade-slide relative"
                            style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);">

                            <!-- Body -->
                            <div class="tm-modal-body text-center mb-4">
                                <p class="tm-modal-message text-gray-700 text-center text-base mr-2 p-2"></p>
                            </div>

                            <!-- Footer -->
                            <!-- <div class="flex justify-center">
                                <button type="button" class="tm-modal-ok bg-primary text-white py-2 px-4 rounded cursor-pointer">
                                    OK
                                </button>
                            </div> -->
                            <div class="flex justify-center">
                                <?php if (isset($type) && $type === 'success'): ?>
                                    <button type="button"
                                        class="tm-modal-ok bg-primary text-white py-2 px-4 rounded cursor-pointer">
                                        OK
                                    </button>
                                <?php else: ?>
                                    <button type="button"
                                        class="tm-modal-close bg-primary text-white py-2 px-4 rounded cursor-pointer">
                                        OK
                                    </button>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </section>

        <?php
        return ob_get_clean();
    }

    public function enqueue_assets()
    {
        /** Frontend CSS */
        wp_enqueue_style(
            'tour-inquiry-form-style',
            plugin_dir_url(__FILE__) . '../../../assets/css/inquiry-booking-form.css',
            array('intl-tel-input'),
            filemtime(plugin_dir_path(__FILE__) . '../../../assets/css/inquiry-booking-form.css')
        );

        /** intl-tel-input CSS */
        wp_enqueue_style(
            'intl-tel-input',
            'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css',
            array(),
            '17.0.8'
        );

        /** intl-tel-input JS */
        wp_enqueue_script(
            'intl-tel-input',
            'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js',
            array(),
            '17.0.8',
            true
        );

        /** Frontend JS */
        wp_enqueue_script(
            'tour-inquiry-form-script',
            plugin_dir_url(__FILE__) . '../../../assets/js/inquiry-form.js',
            array('jquery', 'intl-tel-input'),
            filemtime(plugin_dir_path(__FILE__) . '../../../assets/js/inquiry-form.js'),
            true
        );

        /** Localize script for AJAX URL and countries data */
        wp_localize_script(
            'tour-inquiry-form-script',
            'tourInquiryData',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tour_inquiry_nonce'),
                'countries' => $this->get_countries_list()
            )
        );

        // Enqueue Flatpickr
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', [], null, true);
    }

    private function get_countries_list()
    {
        $countries_json_path = plugin_dir_path(__DIR__) . '/../../assets/data/countries.json';

        if (file_exists($countries_json_path)) {
            $countries_data = json_decode(file_get_contents($countries_json_path), true);

            if (is_array($countries_data) && !empty($countries_data)) {
                if (is_string($countries_data[0])) {
                    return $countries_data;
                } else {
                    $country_names = [];
                    foreach ($countries_data as $country) {
                        if (isset($country['name'])) {
                            $country_names[] = $country['name'];
                        }
                    }
                    return $country_names;
                }
            }
        }

        // Fallback to hardcoded list if JSON file doesn't exist or is invalid
        return array(
            'Afghanistan',
            'Albania',
            'Algeria',
            'Andorra',
            'Angola',
            'Zambia',
            'Zimbabwe'
        );
    }
}

new Inquiry_Form_Shortcode();