<?php
/** includes/frontend/shortcode/archive-tour-shortcode.php */

/**
 * @function tm_display_tour_shortcode()
 * @description Register the shortcode to display the tour system.
 * @return void Output the All tours.
 * 
 */


function tm_display_tour_shortcode($atts)
{
    ob_start();
    if (is_page()) {
        include(plugin_dir_path(__FILE__) . '../../templates/archive-tour.php');
    }

    return ob_get_clean();
}
add_shortcode('tm_tours', 'tm_display_tour_shortcode');



/**
 * Summary of tm_archive_tour_shortcode_assets
 * @return void
 */
function tm_archive_tour_shortcode_assets()
{
    $plugin_url = plugin_dir_url(__FILE__);
    wp_enqueue_style('tm-achive-style', $plugin_url . '../../../assets/css/archive-tour.css');
    wp_enqueue_script('tm-achive-script', $plugin_url . '../../../assets/js/archive-tour.js', ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'tm_archive_tour_shortcode_assets');

