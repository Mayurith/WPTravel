<?php
/** includes/frontend/rewrite-rules.php */

/**
 * @function tm_add_query_vars()
 * @description Pages slug create.
 * 
 */
function tm_add_query_vars($vars)
{
    $vars[] = 'tour_slug';
    $vars[] = 'second_slug';
    $vars[] = 'is_tour_book';
    $vars[] = 'view';
    $vars[] = 'hotel_slug';
    $vars[] = 'city_slug';
    $vars[] = 'location_slug';
    return $vars;
}
add_filter('query_vars', 'tm_add_query_vars');



/**
 * @function tm_add_rewrite_rules()
 * @description 
 * 
 */


function tm_add_rewrite_rules()
{
    // Booking form (must come first)
    add_rewrite_rule(
        '^tour/([^/]+)/book/?$',
        'index.php?tour_slug=$matches[1]&is_tour_book=1',
        'top'
    );

    /** City single page */
    add_rewrite_rule('^city/([^/]+)/?$', 'index.php?city_slug=$matches[1]', 'top');

    /** Location single page */
    add_rewrite_rule('^location/([^/]+)/?$', 'index.php?location_slug=$matches[1]', 'top');

    // Location or hotel
    add_rewrite_rule('^tour/([^/]+)/([^/]+)/?$', 'index.php?tour_slug=$matches[1]&second_slug=$matches[2]', 'top');

    // Single tour
    add_rewrite_rule('^tour/([^/]+)/?$', 'index.php?post_type=tour&name=$matches[1]', 'top');

    // city archive
    add_rewrite_rule('^city/?$', 'index.php?post_type=city', 'top');
    /** city single page */
    // add_rewrite_rule('^city/([^/]+)/?$', 'index.php?post_type=city&name=$matches[1]', 'top');
    // location archive
    add_rewrite_rule('^location/?$', 'index.php?post_type=location', 'top');


    // All pages (optional fallback)
    add_rewrite_rule('^([^/]+)/?$', 'index.php?pagename=$matches[1]', 'top');
}

add_action('init', 'tm_add_rewrite_rules');