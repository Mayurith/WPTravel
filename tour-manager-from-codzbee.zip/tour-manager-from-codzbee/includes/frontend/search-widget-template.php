<?php
/** includes/frontend/search-widget-template.php */

/**
 * Search Widget Template
 * @package Tour Manager
 * @since 1.0
 * @version 1.0
 * @Description Search by : Country, City, Duration and Category
 */

/** Prevent direct access */
if (!defined('ABSPATH')) {
    exit;
}

class TM_Search_Widget
{

    public function __construct()
    {
        add_shortcode('tm_search_widget_globelodger', array($this, 'tm_search_widget_template'));
        add_action('wp_ajax_get_cities_by_country', array($this, 'get_cities_by_country'));
        add_action('wp_ajax_nopriv_get_cities_by_country', array($this, 'get_cities_by_country'));
    }


    public function tm_search_widget_template()
    {
        /** Fetch categories */
        $categories = get_terms(array(
            'taxonomy' => 'tour_category',
            'hide_empty' => false,
        ));

        /** Fetch all tours to extract countries, cities, and durations */
        $tours = get_posts(array(
            'post_type' => 'tour',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ));

        $countries = [];
        $all_cities = [];
        $duration_days = [];

        foreach ($tours as $tour) {
            $post_id = $tour->ID;
            $itinerary = get_post_meta($post_id, '_trip_itinerary', true);

            if (!empty($itinerary) && is_array($itinerary)) {
                /** Calculate duration */
                $total_days = count($itinerary);
                $total_night = max(0, $total_days - 1);
                $duration_days[] = "$total_night Nights - $total_days Days";

                /** Extract countries and cities */
                foreach ($itinerary as $day) {
                    if (!empty($day['country'])) {
                        $country = sanitize_text_field($day['country']);
                        $countries[] = $country;

                        /** Extract cities for this country */
                        if (!empty($day['cities']) && is_array($day['cities'])) {
                            foreach ($day['cities'] as $city) {
                                if (!empty($city['name'])) {
                                    $city_name = sanitize_text_field($city['name']);
                                    $all_cities[$country][] = $city_name;
                                }
                            }
                        }
                    }
                }
            }
        }

        /** Remove duplicates and sort */
        $countries = array_unique($countries);
        sort($countries);

        $duration_days = array_unique($duration_days);
        sort($duration_days);

        ob_start();
        ?>
        <div class="hero-archive-wrapper">
            <div class="hero-archive-inner">
                <div class="search-bar-wrapper">
                    <form method="get" action="<?= esc_url(get_post_type_archive_link('tour')); ?>" id="tour-search-form">
                        <div class="search-bar-container">
                            <div class="search-bar-row">
                                <!-- Country Dropdown -->
                                <div class="search-bar-item border">
                                    <div class="search-bar-title text-md">Country</div>
                                    <div class="dropdown-wrapper">
                                        <div class="search-bar-label dropdown-toggle country-toggle text-sm">Select Destination
                                        </div>
                                        <input type="hidden" name="country" id="selected-country" value="">
                                        <div class="dropdown-menu country-menu">
                                            <?php foreach ($countries as $country): ?>
                                                <div class="typeahead-option" data-value="<?= esc_attr($country); ?>">
                                                    <?= esc_html($country); ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- City Dropdown -->
                                <div class="search-bar-item border">
                                    <div class="search-bar-title text-md">City</div>
                                    <div class="dropdown-wrapper">
                                        <div class="search-bar-label dropdown-toggle city-toggle text-sm">Choose City</div>
                                        <input type="hidden" name="city" id="selected-city" value="">
                                        <div class="dropdown-menu city-menu" id="city-dropdown-menu">
                                            <div class="typeahead-option no-cities" data-value="">
                                                Please select a country first
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Duration Dropdown -->
                                <div class="search-bar-item border">
                                    <div class="search-bar-title text-md">Duration</div>
                                    <div class="dropdown-wrapper">
                                        <div class="search-bar-label dropdown-toggle duration-toggle text-sm">Select Duration
                                        </div>
                                        <input type="hidden" name="duration" id="selected-duration" value="">
                                        <div class="dropdown-menu duration-menu">
                                            <?php foreach ($duration_days as $duration): ?>
                                                <div class="typeahead-option" data-value="<?= esc_attr($duration); ?>">
                                                    <?= esc_html($duration); ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Category Dropdown -->
                                <div class="search-bar-item">
                                    <div class="search-bar-title text-md">Category</div>
                                    <div class="dropdown-wrapper">
                                        <div class="search-bar-label dropdown-toggle category-toggle text-sm">Tour Category
                                        </div>
                                        <input type="hidden" name="tour_category" id="selected-category" value="">
                                        <div class="dropdown-menu category-menu">
                                            <?php foreach ($categories as $category): ?>
                                                <div class="typeahead-option" data-value="<?= esc_attr($category->slug); ?>">
                                                    <?= esc_html($category->name); ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="search-bar-item">
                                    <button type="submit" class="search-bar-button" id="search-submit">
                                        <i class="fas fa-search"></i>
                                        <span>Search</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <style>
            .hero-archive-wrapper {
                position: absolute;
                inset: 0;
                z-index: 30;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 0 1rem;
            }

            .hero-archive-inner {
                width: 100%;
                max-width: 1024px;
                text-align: center;
            }

            .search-bar-wrapper {
                padding: 0.5rem;
                width: 100%;
                background-color: white;
                margin-top: 2.5rem;
                border-radius: 3rem;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                text-align: left;
            }

            .search-bar-container {
                width: 100%;
            }

            .search-bar-row {
                display: flex;
                flex-direction: row;
                gap: 20px;
                margin: 0 5px 0 20px;
                ;
            }

            .search-bar-item {
                flex: 1;
                position: relative;
            }

            .search-bar-title {
                color: #00807f;
                font-weight: 500;
            }

            .search-bar-label {
                color: #bdc2cb;
                cursor: pointer;
            }

            .search-bar-button {
                background-color: #00807f;
                color: #fff;
                padding: 10px 50px;
                border-radius: 25px;
                width: 100%;
                cursor: pointer;
                border: none;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 5px;
            }

            .search-bar-button:disabled {
                background-color: #cccccc;
                cursor: not-allowed;
            }

            .search-bar-button:hover:not(:disabled) {
                background-color: #051036;
            }

            .border {
                border-right: 1px solid #e4e8eeff;
                border-left: 0;
                border-top: 0;
                border-bottom: 0;
            }

            /* Dropdown styles */
            .dropdown-wrapper {
                position: relative;
                width: 100%;
            }

            .dropdown-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                z-index: 1000;
                background: #fff;
                width: 100%;
                max-height: 200px;
                overflow-y: auto;
                border: 1px solid #e4e8eeff;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                margin-top: 5px;
            }

            .dropdown-menu .typeahead-option {
                padding: 10px;
                cursor: pointer;
                border-bottom: 1px solid #f0f0f0;
            }

            .dropdown-menu .typeahead-option:hover {
                background-color: #f0f0f0;
            }

            .dropdown-menu .typeahead-option:last-child {
                border-bottom: none;
            }

            .dropdown-menu .typeahead-option.no-cities {
                color: #999;
                cursor: not-allowed;
            }

            .dropdown-menu .typeahead-option.no-cities:hover {
                background-color: transparent;
            }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const countryToggle = document.querySelector('.country-toggle');
                const cityToggle = document.querySelector('.city-toggle');
                const durationToggle = document.querySelector('.duration-toggle');
                const categoryToggle = document.querySelector('.category-toggle');

                const countryMenu = document.querySelector('.country-menu');
                const cityMenu = document.querySelector('.city-menu');
                const durationMenu = document.querySelector('.duration-menu');
                const categoryMenu = document.querySelector('.category-menu');

                const selectedCountry = document.getElementById('selected-country');
                const selectedCity = document.getElementById('selected-city');
                const searchForm = document.getElementById('tour-search-form');
                const searchSubmit = document.getElementById('search-submit');

                // Initialize all dropdowns
                const dropdowns = [
                    { toggle: countryToggle, menu: countryMenu, input: selectedCountry },
                    { toggle: cityToggle, menu: cityMenu, input: selectedCity },
                    { toggle: durationToggle, menu: durationMenu, input: document.getElementById('selected-duration') },
                    { toggle: categoryToggle, menu: categoryMenu, input: document.getElementById('selected-category') }
                ];

                dropdowns.forEach(function (dropdown) {
                    if (dropdown.toggle && dropdown.menu) {
                        // Toggle dropdown menu
                        dropdown.toggle.addEventListener('click', function (e) {
                            e.stopPropagation();
                            // Close all other dropdowns
                            closeAllDropdowns();
                            // Toggle current dropdown
                            dropdown.menu.style.display = (dropdown.menu.style.display === 'block') ? 'none' : 'block';
                        });

                        // Select option
                        dropdown.menu.querySelectorAll('.typeahead-option').forEach(function (option) {
                            option.addEventListener('click', function () {
                                if (this.classList.contains('no-cities')) return;

                                const selectedText = this.textContent;
                                const selectedValue = this.getAttribute('data-value');

                                dropdown.toggle.textContent = selectedText;
                                dropdown.toggle.style.color = '#000';

                                if (dropdown.input) {
                                    dropdown.input.value = selectedValue;
                                }

                                // If country is selected, update cities
                                if (dropdown.input === selectedCountry) {
                                    updateCitiesDropdown(selectedValue);
                                    // Reset city selection when country changes
                                    selectedCity.value = '';
                                    cityToggle.textContent = 'Choose City';
                                    cityToggle.style.color = '#bdc2cb';
                                }

                                dropdown.menu.style.display = 'none';
                                validateForm();
                            });
                        });
                    }
                });

                function updateCitiesDropdown(country) {
                    if (!country) {
                        cityMenu.innerHTML = '<div class="typeahead-option no-cities" data-value="">Please select a country first</div>';
                        return;
                    }

                    /** Show loading */
                    cityMenu.innerHTML = '<div class="typeahead-option no-cities" data-value="">Loading cities...</div>';
                    console.log('Fetching cities for country:', country);
                    

                    /** AJAX call to get cities for selected country */
                    fetch('<?= admin_url('admin-ajax.php'); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=get_cities_by_country&country=' + encodeURIComponent(country)
                    })
                        .then(response => {
                            console.log('Response status:', response.status);
                            console.log('Response ok:', response.ok);
                            if (!response.ok) {
                                throw new Error('Network response was not ok: ' + response.status);
                            }
                            return response.json();
                        })
                        .then(data => {
                            console.log('AJAX response data:', data);
                            if (data.success && data.data && data.data.length > 0) {
                                console.log('Cities found:', data.data);
                                cityMenu.innerHTML = '';
                                data.data.forEach(function (city) {
                                    const option = document.createElement('div');
                                    option.className = 'typeahead-option';
                                    option.setAttribute('data-value', city);
                                    option.textContent = city;
                                    option.addEventListener('click', function () {
                                        cityToggle.textContent = city;
                                        cityToggle.style.color = '#000';
                                        selectedCity.value = city;
                                        cityMenu.style.display = 'none';
                                        validateForm();
                                    });
                                    cityMenu.appendChild(option);
                                });
                            } else {
                                console.log('No cities found or empty response');
                                cityMenu.innerHTML = '<div class="typeahead-option no-cities" data-value="">No cities found for ' + country + '</div>';
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching cities:', error);
                            console.error('Error details:', error.message);
                            cityMenu.innerHTML = '<div class="typeahead-option no-cities" data-value="">Error loading cities: ' + error.message + '</div>';
                        });
                }

                /** Form validation */
                function validateForm() {
                    const hasCountry = selectedCountry.value !== '';
                    const hasCity = selectedCity.value !== '';
                    const hasDuration = document.getElementById('selected-duration').value !== '';
                    const hasCategory = document.getElementById('selected-category').value !== '';

                    /** Enable submit button if at least one field is filled */
                    const isValid = hasCountry || hasCity || hasDuration || hasCategory;
                    searchSubmit.disabled = !isValid;
                }

                /** Close dropdowns when clicking outside */
                document.addEventListener('click', function (e) {
                    if (!e.target.matches('.dropdown-toggle')) {
                        closeAllDropdowns();
                    }
                });

                function closeAllDropdowns() {
                    document.querySelectorAll('.dropdown-menu').forEach(function (menu) {
                        menu.style.display = 'none';
                    });
                }

                /** Initial validation */
                validateForm();
            });
        </script>

        <?php
        return ob_get_clean();
    }


    /** AJAX handler to get cities by country */
    public function get_cities_by_country()
    {
        // Log the request
        error_log('AJAX get_cities_by_country called with country: ' . ($_POST['country'] ?? 'empty'));

        $country = sanitize_text_field($_POST['country'] ?? '');

        if (empty($country)) {
            error_log('AJAX ERROR: Country parameter is empty');
            wp_send_json_error('Country parameter is required');
        }

        error_log('Processing country: ' . $country);

        $tours = get_posts(array(
            'post_type' => 'tour',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ));

        error_log('Found ' . count($tours) . ' tours');

        $cities = [];

        foreach ($tours as $tour) {
            $post_id = $tour->ID;
            $itinerary = get_post_meta($post_id, '_trip_itinerary', true);

            error_log("Tour {$post_id} itinerary: " . print_r($itinerary, true));

            if (!empty($itinerary) && is_array($itinerary)) {
                foreach ($itinerary as $day_index => $day) {
                    error_log("Day {$day_index} country: " . ($day['country'] ?? 'empty'));

                    // Exact match for country
                    if (!empty($day['country']) && $day['country'] === $country) {
                        error_log("Country match found for: " . $country);

                        if (!empty($day['cities']) && is_array($day['cities'])) {
                            foreach ($day['cities'] as $city_index => $city) {
                                if (!empty($city['name'])) {
                                    $city_name = sanitize_text_field($city['name']);
                                    $cities[] = $city_name;
                                    error_log("Added city: " . $city_name);
                                } else {
                                    error_log("City name empty at day {$day_index}, city {$city_index}");
                                }
                            }
                        } else {
                            error_log("No cities array found for day {$day_index}");
                        }
                    }
                }
            } else {
                error_log("Tour {$post_id} has no itinerary or invalid format");
            }
        }

        $cities = array_unique($cities);
        sort($cities);

        error_log('Final cities list for ' . $country . ': ' . print_r($cities, true));

        wp_send_json_success($cities);
    }
}