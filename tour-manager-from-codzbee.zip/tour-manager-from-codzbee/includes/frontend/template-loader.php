<?php
/** includes/frontend/template-loader.php */

/**
 * @function tm_template_include()
 * @description Pages slug create.
 * 
 */
function tm_template_include($template)
{
    global $wp_query;
    global $wp;

    $tour_slug = get_query_var('tour_slug');
    $second_slug = get_query_var('second_slug');
    $city_slug = get_query_var('city_slug');
    $location_slug = get_query_var('location_slug');

    if ($city_slug) {
        $city = get_page_by_path($city_slug, OBJECT, 'city');
        if ($city) {
            setup_postdata($city);
            $wp_query->queried_object = $city;
            $wp_query->is_single = true;
            return TBS_PATH . 'includes/templates/single-city.php';
        }
    }

    if ($location_slug) {
        $location = get_page_by_path($location_slug, OBJECT, 'location');
        if ($location) {
            setup_postdata($location);
            $wp_query->queried_object = $location;
            $wp_query->is_single = true;
            return TBS_PATH . 'includes/templates/single-location.php';
        }
    }

    if (!empty($wp->query_vars['tour_slug']) && isset($wp->query_vars['is_tour_book'])) {
        // $template = plugin_dir_path(__FILE__) . 'templates/tour-book.php';
        $template = dirname(__DIR__) . '/templates/tour-book.php';
    }

    /** Handle hotel or location page based on second slug */
    if ($tour_slug && $second_slug) {
        /**  Check if second slug is a hotel */
        $hotel = get_page_by_path($second_slug, OBJECT, 'hotel');
        if ($hotel) {
            setup_postdata($hotel);
            $wp_query->queried_object = $hotel;
            $wp_query->is_single = true;
            return TBS_PATH . 'includes/templates/single-hotel.php';
        }

        /** Check if second slug is a location */
        $location = get_page_by_path($second_slug, OBJECT, 'location');
        if ($location) {
            setup_postdata($location);
            $wp_query->queried_object = $location;
            $wp_query->is_single = true;
            return TBS_PATH . 'includes/templates/single-location.php';
        }

    }

    if (is_singular(post_types: 'tour') || (get_query_var('post_type') === 'tour' && get_query_var('name'))) {
        return TBS_PATH . 'includes/templates/single-tour.php';
    }

    //** Archive of all tours */ 
    if (is_post_type_archive('tour')) {
        return TBS_PATH . 'includes/templates/archive-tour.php';
    }

    /** Return the default template: archive-city.php */
    if (is_post_type_archive('city')) {
        return TBS_PATH . 'includes/templates/archive-city.php';
    }
    /** Return the default template: archive-location.php */
    if (is_post_type_archive('location')) {
        return TBS_PATH . 'includes/templates/archive-location.php';
    }
    return $template;

}
add_filter('template_include', 'tm_template_include');


/**
 * @function tm_enqueue_frontend_assets()
 * @description Enqueue CSS and JS for all pages where the plugin is active.
 * 
 */

function tm_enqueue_frontend_assets()
{
    if (is_admin())
        return; // Avoid loading in the admin area

    $plugin_url = plugin_dir_url(__FILE__);

    // Enqueue plugin styles/scripts as before...
    if (
        is_singular(['tour', 'hotel', 'location', 'city']) ||
        is_post_type_archive('tour') ||
        is_post_type_archive('city') ||

        get_query_var('is_tour_book') ||
        get_query_var('view') === 'book' ||
        get_query_var('second_slug')
    ) {
        wp_enqueue_style('tm-style', $plugin_url . '../../assets/css/tour-manager.css');
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
        wp_enqueue_script('tm-script', $plugin_url . '../../assets/js/tour-manager.js', ['jquery'], null, true);
        /** Date Picker JS */
        wp_enqueue_script(
            'another-js-file',
            plugin_dir_url(__FILE__) . '../../assets/js/date-picker.js',
            array('jquery'),
            filemtime(plugin_dir_path(__FILE__) . '../../assets/js/date-picker.js'),
            true
        );
    }

    // Enqueue Flatpickr and Font Awesome for single tour and booking pages
    if (
        is_singular('tour') ||
        get_query_var('is_tour_book')
    ) {
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
        wp_enqueue_script('flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', ['jquery'], null, true);
    }

    /** tour-archive-page css/js */
    if (is_post_type_archive('tour')) {
        wp_enqueue_style('tm-achive-style', $plugin_url . '../../assets/css/archive-tour.css');
        wp_enqueue_script('tm-achive-script', $plugin_url . '../../assets/js/archive-tour.js', ['jquery'], null, true);
    }

    /** city-archive-page css/js */
    if (is_post_type_archive('city')) {
        wp_enqueue_style('tm-achive-style', $plugin_url . '../../assets/css/archive-city.css');
        wp_enqueue_script('tm-achive-script', $plugin_url . '../../assets/js/archive-city.js', ['jquery'], null, true);
    }

    /** single-tour-page css/js */
    if (is_singular('tour')) {
        wp_enqueue_style('tm-single-tour-style', $plugin_url . '../../assets/css/single-tour.css');
        wp_enqueue_script('tm-single-tour-script', $plugin_url . '../../assets/js/single-tour.js', ['jquery'], null, true);
        // wp_enqueue_script('tm-gmap-script', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBrlErC7_iaeM_C3dM8-GKTVysbqNSXNNE&callback=initMap', [], null, true);
        /** Date Picker JS */
        wp_enqueue_script(
            'another-js-file',
            plugin_dir_url(__FILE__) . '../../assets/js/date-picker.js',
            array('jquery'),
            filemtime(plugin_dir_path(__FILE__) . '../../assets/js/date-picker.js'),
            true
        );

        // wp_localize_script('tour-map-js', 'tourRouteData', array(
        //     'cities' => $all_cities,
        //     'coords' => $city_coordinates
        // ));
    }

    global $wp_query;
    $post_type = '';
    if (isset($wp_query->queried_object) && isset($wp_query->queried_object->post_type)) {
        $post_type = $wp_query->queried_object->post_type;
    }
    global $wp_query;
    $post_type = '';
    if (isset($wp_query->queried_object) && isset($wp_query->queried_object->post_type)) {
        $post_type = $wp_query->queried_object->post_type;
    }


    /** single-hotel-page css/js */
    if ($post_type === 'hotel') {
        wp_enqueue_style('tm-single-hotel-style', $plugin_url . '../../assets/css/single-hotel.css');
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
        wp_enqueue_script('tm-single-hotel-script', $plugin_url . '../../assets/js/single-hotel.js', ['jquery'], null, true);
    }

    /** single-city-page css/js */
    if ($post_type === 'city') {
        wp_enqueue_style('tm-single-city-style', $plugin_url . '../../assets/css/single-city.css');
        // wp_enqueue_style('light-gallery-css', '../../assets/css/lightslider.css');
        wp_enqueue_script('tm-single-city-script', $plugin_url . '../../assets/js/single-city.js', ['jquery'], null, true);
        // wp_enqueue_script('light-gallery-js', '../../assets/js/lightslider.js', ['jquery'], null, true);

        /** Light Gallery */
        // wp_enqueue_script('lg-js', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/lightgallery.min.js', ['jquery'], null, true);
        // wp_enqueue_style('lightgallery-core', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/2.8.3/css/lightgallery.min.css');
        wp_localize_script('tm-single-city-script', 'cityGalleryData', [
            'images' => $gallery_data,
        ]);

        // wp_enqueue_style('css', 'css/lightGallery.css');
        // wp_enqueue_style('js', 'js/lightGallery.js', ['jquery'], null, true);

    }

    /** single-location-page css/js */
    if ($post_type === 'location') {
        wp_enqueue_style('tm-single-location-style', $plugin_url . '../../assets/css/single-location.css');
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
        wp_enqueue_script('tm-single-location-script', $plugin_url . '../../assets/js/single-location.js', ['jquery'], null, true);


        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css');
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), null, true);

    }

    /** tour-book-page css/js */
    if ($post_type === 'tour' && get_query_var('is_tour_book')) {
        wp_enqueue_style('tm-booking-style', $plugin_url . '../../assets/css/inquiry-booking-form.css');
        wp_enqueue_script('tm-booking-script', $plugin_url . '../../assets/js/inquiry-form.js', ['jquery'], null, true);


        // Localize script data
        wp_localize_script(
            'tm-booking-script',
            'tourInquiryData',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('tour_booking_ajax_nonce')
            ]
        );

    }
}
add_action('wp_enqueue_scripts', 'tm_enqueue_frontend_assets');