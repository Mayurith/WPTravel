<?php
/**
 *  @package Tour-Manager
 *  @version 6.6.2
 */

if (!defined('WPINC')) {
  die; // Prevent direct access
}

/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}

/*
  Plugin Name: Tour Manager
  Plugin URI : http://Tour-Manager/
  Description: A comprehensive plugin designed for tour manager agencies to manage tours, bookings, schedules, and
               customer information efficiently. This plugin provides tools for creating and managing tour packages, 
               and handling reservations your tour management operations
  Version: 1.0.0
  Author: Codz Bee
  Author URI : codzbee.com
  License: GPL-2.0+
  License URI: http://www.gnu.org/licenses/gpl-2.0.txt
  Text Domain: tour-manager
  Domain Path: /languages
*/


/** Prevent direct access */
if (!defined('ABSPATH')) {
  exit;
}


/** Load dependencies */
require_once plugin_dir_path(__FILE__) . 'includes/backend/tour.php';
require_once plugin_dir_path(__FILE__) . 'includes/backend/location.php';
require_once plugin_dir_path(__FILE__) . 'includes/backend/hotel.php';
require_once plugin_dir_path(__FILE__) . 'includes/backend/booking-inquiry.php';
require_once plugin_dir_path(__FILE__) . 'includes/backend/setting.php';
require_once plugin_dir_path(__FILE__) . 'includes/backend/city.php';

/** URL */
define('TBS_PATH', plugin_dir_path(__FILE__));
require_once TBS_PATH . 'includes/frontend/template-loader.php';
require_once TBS_PATH . 'includes/frontend/rewrite-rules.php';

/** Include the Shortcodes file */
require_once plugin_dir_path(__FILE__) . 'includes/frontend/shortcodes/archive-tour-shortcode.php';

/** Search widget */
require_once plugin_dir_path(__FILE__) . 'includes/frontend/search-widget-template.php';
require_once plugin_dir_path(__FILE__) . 'includes/frontend/search-widget-template-2.php';
require_once plugin_dir_path(__FILE__) . 'includes/frontend/search-widget-template-hotel.php';
require_once plugin_dir_path(__FILE__) . 'includes/frontend/search-widget-template-akrasia.php';

/** Booking Engine */
require_once plugin_dir_path(__FILE__) . 'includes/backend/booking-engine/class-booking-engine-ajax-handler.php';



/**
 * @class TourManager
 * @description main class for add menu page : Tour Manager
 */

class TourManager
{
  public function __construct()
  {
    /** Hook for add admin menu */
    add_action('admin_menu', array($this, 'tr_add_admin_menu'));

    /** Hook for register category taxonomy */
    add_action('init', array($this, 'tr_register_tour_categories_taxonomy'));


    /** Hook for remove private status */
    add_filter('display_post_states', 'custom_remove_private_state', 10, 2);
    function custom_remove_private_state($post_states, $post)
    {
      if ($post->post_type === 'inquiry' && isset($post_states['private'])) {
        unset($post_states['private']); // Remove "Private" label
      }
      return $post_states;
    }
    new Hotel();
    new Location();
    new Tour();
    new City();
    new Booking_Inquiry();
    new Setting();
    new TM_Search_Widget();
    new TM_Search_Widget_2();
    new Search_widget_template_hotel();
    new Search_widget_template_akrasia();
    new BookingEngineAjaxHandler();

  }


  /**
   * @function tr_add_admin_menu()
   * @description Admin menu callback
   * @return void 
   */
  public function tr_add_admin_menu()
  {

    add_menu_page(
      'Tour Manager',
      'Tour Manager',
      'manage_options',
      'main_menu_of_tour_manager',
      '',
      'dashicons-admin-site',
      5
    );

    /** Add "Categories" submenu linking to the taxonomy edit screen */
    add_submenu_page(
      'main_menu_of_tour_manager',
      'Tour Categories',
      'Categories',
      'manage_options',
      'edit-tags.php?taxonomy=tour_category&post_type=tour',
      false
    );

  }


  /**
   * @function tr_register_tour_categories_taxonomy
   * @return void
   */
  // public function tr_register_tour_categories_taxonomy()
  // {
  //   $labels = array(
  //     'name' => 'Tour Categories',
  //     'singular_name' => 'Tour Category',
  //     'search_items' => 'Search Tour Categories',
  //     'all_items' => 'All Tour Categories',
  //     'parent_item' => 'Parent Tour Category',
  //     'parent_item_colon' => 'Parent Tour Category:',
  //     'edit_item' => 'Edit Tour Category',
  //     'update_item' => 'Update Tour Category',
  //     'add_new_item' => 'Add New Tour Category',
  //     'new_item_name' => 'New Tour Category Name',
  //     'menu_name' => 'Tour Categories',
  //   );

  //   $args = array(
  //     'hierarchical' => true,
  //     'labels' => $labels,
  //     'show_ui' => true,
  //     'show_admin_column' => true,
  //     'query_var' => true,
  //     'rewrite' => array('slug' => 'tour-category'),
  //     'show_in_menu' => false,
  //   );

  //   register_taxonomy('tour_category', array('tour'), $args);
  // }

  public function tr_register_tour_categories_taxonomy()
  {
    $labels = array(
      'name' => 'Tour Categories',
      'singular_name' => 'Tour Category',
      'search_items' => 'Search Tour Categories',
      'all_items' => 'All Tour Categories',
      'parent_item' => 'Parent Tour Category',
      'parent_item_colon' => 'Parent Tour Category:',
      'edit_item' => 'Edit Tour Category',
      'update_item' => 'Update Tour Category',
      'add_new_item' => 'Add New Tour Category',
      'new_item_name' => 'New Tour Category Name',
      'menu_name' => 'Tour Categories',
    );

    $args = array(
      'hierarchical' => true,
      'labels' => $labels,
      'show_ui' => true,
      'show_admin_column' => true,
      'query_var' => true,
      'rewrite' => array('slug' => 'tour-category'),
      'show_in_menu' => false,
    );

    register_taxonomy('tour_category', array('tour'), $args);

    // Add icon field hooks after taxonomy is registered
    $this->tr_add_icon_field_to_tour_categories();
  }

  /**
   * Add icon field to tour categories taxonomy
   */
  public function tr_add_icon_field_to_tour_categories()
  {
    // Add field to add new taxonomy form
    add_action('tour_category_add_form_fields', array($this, 'tr_tour_category_icon_add_field'), 10, 2);

    // Add field to edit taxonomy form
    add_action('tour_category_edit_form_fields', array($this, 'tr_tour_category_icon_edit_field'), 10, 2);

    // Save taxonomy icon
    add_action('created_tour_category', array($this, 'tr_save_tour_category_icon'), 10, 2);
    add_action('edited_tour_category', array($this, 'tr_save_tour_category_icon'), 10, 2);

    // Add custom column to taxonomy list
    add_filter('manage_edit-tour_category_columns', array($this, 'tr_add_tour_category_icon_column'));
    add_filter('manage_tour_category_custom_column', array($this, 'tr_show_tour_category_icon_column'), 10, 3);
  }

  /**
   * Add icon field to "Add New Tour Category" form
   */
  public function tr_tour_category_icon_add_field($taxonomy)
  {
    wp_enqueue_media();
    ?>
    <div class="form-field term-group">
      <label for="tour_category_icon"><?php _e('Category Icon', 'textdomain'); ?></label>
      <input type="hidden" name="tour_category_icon" id="tour_category_icon" value="">
      <div id="tour_category_icon_preview" style="margin: 10px 0; min-height: 50px;"></div>
      <button type="button" class="button" id="upload_tour_category_icon_btn">
        <?php _e('Upload Icon', 'textdomain'); ?>
      </button>
      <button type="button" class="button" id="remove_tour_category_icon_btn" style="display:none;">
        <?php _e('Remove Icon', 'textdomain'); ?>
      </button>
      <p class="description"><?php _e('Upload or select an icon for this tour category', 'textdomain'); ?></p>
    </div>

    <script>
      jQuery(document).ready(function ($) {
        $('#upload_tour_category_icon_btn').click(function (e) {
          e.preventDefault();
          var frame = wp.media({
            title: '<?php _e('Select or Upload Icon', 'textdomain'); ?>',
            button: { text: '<?php _e('Use this icon', 'textdomain'); ?>' },
            multiple: false
          });

          frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            $('#tour_category_icon').val(attachment.url);
            $('#tour_category_icon_preview').html('<img src="' + attachment.url + '" style="max-width: 50px; height: auto; display: block;">');
            $('#remove_tour_category_icon_btn').show();
          });

          frame.open();
        });

        $('#remove_tour_category_icon_btn').click(function () {
          $('#tour_category_icon').val('');
          $('#tour_category_icon_preview').html('');
          $(this).hide();
        });
      });
    </script>
    <?php
  }

  /**
   * Add icon field to "Edit Tour Category" form
   */
  public function tr_tour_category_icon_edit_field($term, $taxonomy)
  {
    wp_enqueue_media();
    $icon_url = get_term_meta($term->term_id, 'tour_category_icon', true);
    ?>
    <tr class="form-field term-group">
      <th scope="row">
        <label for="tour_category_icon"><?php _e('Category Icon', 'textdomain'); ?></label>
      </th>
      <td>
        <input type="hidden" name="tour_category_icon" id="tour_category_icon" value="<?= esc_attr($icon_url); ?>">
        <div id="tour_category_icon_preview" style="margin: 10px 0; min-height: 50px;">
          <?php if ($icon_url): ?>
            <img src="<?= esc_url($icon_url); ?>" style="max-width: 50px; height: auto; display: block;">
          <?php endif; ?>
        </div>
        <button type="button" class="button" id="upload_tour_category_icon_btn">
          <?php _e('Upload Icon', 'textdomain'); ?>
        </button>
        <button type="button" class="button" id="remove_tour_category_icon_btn" <?= empty($icon_url) ? 'style="display:none;"' : ''; ?>>
          <?php _e('Remove Icon', 'textdomain'); ?>
        </button>
        <p class="description"><?php _e('Upload or select an icon for this tour category', 'textdomain'); ?></p>
      </td>
    </tr>

    <script>
      jQuery(document).ready(function ($) {
        $('#upload_tour_category_icon_btn').click(function (e) {
          e.preventDefault();
          var frame = wp.media({
            title: '<?php _e('Select or Upload Icon', 'textdomain'); ?>',
            button: { text: '<?php _e('Use this icon', 'textdomain'); ?>' },
            multiple: false
          });

          frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();
            $('#tour_category_icon').val(attachment.url);
            $('#tour_category_icon_preview').html('<img src="' + attachment.url + '" style="max-width: 50px; height: auto; display: block;">');
            $('#remove_tour_category_icon_btn').show();
          });

          frame.open();
        });

        $('#remove_tour_category_icon_btn').click(function () {
          $('#tour_category_icon').val('');
          $('#tour_category_icon_preview').html('');
          $(this).hide();
        });
      });
    </script>
    <?php
  }

  /**
   * Save tour category icon
   */
  public function tr_save_tour_category_icon($term_id)
  {
    if (isset($_POST['tour_category_icon'])) {
      $icon_url = sanitize_text_field($_POST['tour_category_icon']);
      update_term_meta($term_id, 'tour_category_icon', $icon_url);
    }
  }

  /**
   * Add icon column to tour categories list
   */
  public function tr_add_tour_category_icon_column($columns)
  {
    $new_columns = array();

    foreach ($columns as $key => $value) {
      $new_columns[$key] = $value;
      if ($key === 'name') {
        $new_columns['tour_category_icon'] = __('Icon', 'textdomain');
      }
    }

    return $new_columns;
  }

  /**
   * Display icon in tour categories list
   */
  public function tr_show_tour_category_icon_column($content, $column_name, $term_id)
  {
    if ($column_name === 'tour_category_icon') {
      $icon_url = get_term_meta($term_id, 'tour_category_icon', true);
      if ($icon_url) {
        $content = '<img src="' . esc_url($icon_url) . '" style="max-width: 30px; height: auto;">';
      } else {
        $content = '—';
      }
    }

    return $content;
  }

}

new TourManager();