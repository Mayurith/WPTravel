
/* tm_add_custom_meta_box_for_hotel_gallery function js */
jQuery(document).ready(function ($) {
  var imageFrame;
  var imageInput = $('#hotel_image_gallery');
  var imagePreview = $('#image_preview');
  var removeImages = $('#remove_all_images');

  $('#upload_images').click(function (e) {
    e.preventDefault();
    if (imageFrame) {
      imageFrame.open();
      return;
    }

    imageFrame = wp.media({
      title: 'Select Images',
      multiple: true,
      library: { type: 'image' },
      button: { text: 'Add Image Gallery' }
    });

    imageFrame.on('select', function () {
      var attachments = imageFrame.state().get('selection').toJSON();
      var imageIDs = imageInput.val() ? imageInput.val().split(',') : [];

      attachments.forEach(function (attachment) {
        if (!imageIDs.includes(attachment.id.toString())) {
          imageIDs.push(attachment.id);
          imagePreview.append(`
                    <div class="gallery-item">
                        <img src="${attachment.url}"  class="gallery-item-inner">
                        <span class="remove-image" data-id="${attachment.id}" >×</span>
                    </div>
                `);
        }
      });

      imageInput.val(imageIDs.join(','));
      removeImages.show();
    });

    imageFrame.open();
  });

  /** Remove individual image */
  $(document).on('click', '.remove-image', function () {
    var imageID = $(this).data('id').toString();
    var imageIDs = imageInput.val().split(',');

    imageIDs = imageIDs.filter(id => id !== imageID);
    imageInput.val(imageIDs.join(','));

    $(this).parent().remove();
    if (imageIDs.length === 0) removeImages.hide();
  });

  /** Remove all images */
  removeImages.click(function () {
    imageInput.val('');
    imagePreview.empty();
    $(this).hide();
  });

  if (imageInput.val()) removeImages.show();

  // Handle city selection change
  $('#hotel_city_id').on('change', function () {
    const selectedOption = $(this).find('option:selected');
    const cityDetails = $('#city-details');

    if (selectedOption.val()) {
      // Update the hidden fields and display
      $('#city-name').val(selectedOption.text());
      $('#city-code-value').val(selectedOption.data('city-code'));
      $('#city-lat-value').val(selectedOption.data('city-lat'));
      $('#city-lng-value').val(selectedOption.data('city-lng'));

      // Update the displayed details
      $('#city-code').text(selectedOption.data('city-code'));
      $('#city-latitude').text(selectedOption.data('city-lat'));
      $('#city-longitude').text(selectedOption.data('city-lng'));

      // Show the details section
      cityDetails.show();
    } else {
      // Hide the details section if no city selected
      cityDetails.hide();
    }
  });
});