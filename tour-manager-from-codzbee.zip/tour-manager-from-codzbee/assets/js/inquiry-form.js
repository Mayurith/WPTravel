jQuery(document).ready(function ($) {
    'use strict';

    class TourInquiryForm {
        constructor() {
            this.form = $('#tour-inquiry-form');
            this.submitBtn = $('#tour-inquiry-btn');
            this.countries = tourInquiryData.countries || [];
            this.phoneInput = null;
            this.modal = $('#tm-inquiry-modal');
            this.init();
            this.isSuccess = false;
        }

        init() {
            this.setupEventListeners();
            this.setupCountryAutocomplete();
            this.setupDateValidation();
            this.setupPhoneValidation();
            this.setupModalEvents();
        }

        setupEventListeners() {
            // Form submission - prevent default and use our validation
            this.form.on('submit', (e) => this.handleSubmit(e));

            // Real-time validation
            this.form.find('.tm-validate').on('blur', (e) => this.validateField(e.target));
            this.form.find('.tm-validate').on('input', (e) => this.clearError(e.target));

            // Special handling for phone field
            this.form.find('#phone').on('input', (e) => {
                $(e.target).addClass('tm-phone-interacted');
                this.clearError(e.target);
            });

            // Enter key prevention in country field
            this.form.find('#country').on('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                }
            });
        }

        // Setup Modal Events
        setupModalEvents() {
            const self = this;

            // Close modal on close button click
            this.modal.find('.tm-modal-close').on('click', () => this.hideModal());

            // Close modal on OK button click
            this.modal.find('.tm-modal-ok-btn').on('click', () => this.hideModal());

            // Close when clicking outside modal content (overlay click)
            // The modal container itself is the overlay; ensure we only close when click target is the overlay (not modal inner content)
            this.modal.on('click', function (e) {
                if (e.target === this) {
                    self.hideModal();
                }
            });

            // Close modal on Escape key
            $(document).on('keydown', (e) => {
                if (e.key === 'Escape' && this.modal.is(':visible')) {
                    this.hideModal();
                }
            });

        }

        showModal(title, message, type = 'info') {
            this.isSuccess = (type === 'success'); // track success status

            this.modal.find('.tm-modal-title').text(title);
            this.modal.find('.tm-modal-message').html(message);

            this.modal.removeClass('tm-modal-success tm-modal-error tm-modal-info');
            this.modal.addClass(`tm-modal-${type}`);

            this.modal.fadeIn(250);
            $('body').css('overflow', 'hidden');
        }

        hideModal() {
            this.modal.fadeOut(200);
            $('body').css('overflow', '');

            if (this.isSuccess) {
                // On success → redirect to home
                window.location.href = '/';
            }
            // else {
            //     // On error → stay on the same form page
            //     // No reload needed → previously entered data remains
            //     // window.location.href = window.location.href; // soft redirect
            // }
        }

        // Setup Phone Validation
        setupPhoneValidation() {
            const phoneInputField = document.querySelector("#phone");

            this.phoneInput = window.intlTelInput(phoneInputField, {
                utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
                initialCountry: "auto",
                geoIpLookup: function (callback) {
                    // Default to US if geoIP fails
                    callback("us");
                },
                separateDialCode: true,
                preferredCountries: ["us", "gb", "ca", "au"],
                customPlaceholder: function (selectedCountryPlaceholder, selectedCountryData) {
                    return "e.g. " + selectedCountryPlaceholder;
                }
            });

            // Update the hidden full_phone field with the complete number
            $(phoneInputField).on('input', () => {
                this.updateFullPhoneNumber();
            });

            // Validate phone on country change
            phoneInputField.addEventListener('countrychange', () => {
                this.updateFullPhoneNumber();
                this.validateField(phoneInputField);
            });
        }

        // Update phone number
        updateFullPhoneNumber() {
            if (this.phoneInput && this.phoneInput.isValidNumber()) {
                const fullNumber = this.phoneInput.getNumber();
                $('#full_phone').val(fullNumber);
            } else {
                $('#full_phone').val('');
            }
        }

        // Setup Country Autocomplete
        setupCountryAutocomplete() {
            const countryInput = $('#country');
            const suggestions = $('#country-suggestions');

            countryInput.on('input', (e) => {
                const query = e.target.value.trim().toLowerCase();
                this.showCountrySuggestions(query);
            });

            countryInput.on('focus', () => {
                if (countryInput.val().trim() === '') {
                    this.showCountrySuggestions('');
                }
            });

            // Hide suggestions when clicking outside
            $(document).on('click', (e) => {
                if (!$(e.target).closest('.relative').length) {
                    suggestions.hide();
                }
            });
        }

        // Show Country Suggestions
        showCountrySuggestions(query) {
            const suggestions = $('#country-suggestions');
            const countryInput = $('#country');

            if (query === '') {
                // Show all countries when empty
                this.renderSuggestions(this.countries.slice(0, 10));
                return;
            }

            const filtered = this.countries.filter(country =>
                country.toLowerCase().includes(query)
            ).slice(0, 10);

            this.renderSuggestions(filtered);
        }

        // Render Country Suggestions
        renderSuggestions(countries) {
            const suggestions = $('#country-suggestions');
            const countryInput = $('#country');

            if (countries.length === 0) {
                suggestions.hide();
                return;
            }

            suggestions.empty();

            countries.forEach(country => {
                const div = $('<div class="px-3 py-2 cursor-pointer hover:bg-gray-100 border-b border-gray-100 last:border-b-0"></div>')
                    .text(country)
                    .on('click', () => {
                        countryInput.val(country);
                        suggestions.hide();
                        this.clearError(countryInput[0]);
                    });
                suggestions.append(div);
            });

            suggestions.show();
        }

        // Setup Date Validation
        setupDateValidation() {
            const arrivalDate = $('#arrival_date');
            const today = new Date().toISOString().split('T')[0];
            arrivalDate.attr('min', today);
        }

        // Validate input field
        validateField(field) {
            const value = field.value.trim();
            const fieldName = field.name;
            let isValid = true;
            let errorMessage = '';

            switch (fieldName) {
                case 'full_name':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Full name is required';
                    } else if (value.length < 2) {
                        isValid = false;
                        // errorMessage = 'Full name must be at least 2 characters long';
                    }
                    break;

                case 'email':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Email is required';
                    } else {
                        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                        if (!emailRegex.test(value)) {
                            isValid = false;
                            // errorMessage = 'Please enter a valid email address';
                        }
                    }
                    break;

                case 'phone':
                    if (!this.phoneInput) {
                        isValid = false;
                        // errorMessage = 'Phone validation not initialized';
                        break;
                    }

                    const phoneValue = this.phoneInput.getNumber();
                    const hasInteracted = $(field).hasClass('tm-phone-interacted');

                    // Only validate if user has interacted with the field
                    if (!hasInteracted && phoneValue === '') {
                        isValid = true; // Don't show error for untouched field
                        break;
                    }

                     if (value === '') {
                        isValid = false;
                        // errorMessage = 'Country is required';
                    }

                    if (phoneValue === '') {
                        isValid = false;
                        // errorMessage = 'Phone number is required';
                    } else if (!this.phoneInput.isValidNumber()) {
                        isValid = false;
                        // errorMessage = `Please enter a valid phone number`;
                    }
                    break;

                case 'country':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Country is required';
                    } else if (!this.countries.includes(value)) {
                        isValid = false;
                        // errorMessage = 'Please select a valid country from the suggestions';
                    }
                    break;

                case 'tour_category':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Tour category is required';
                    }
                    break;

                case 'adults':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Number of adults is required';
                    } else if (value < 1 || value > 50) {
                        isValid = false;
                        // errorMessage = 'Number of adults must be between 1 and 50';
                    }
                    break;

                case 'children':
                    const childrenValue = value === '' ? 0 : parseInt(value);
                    if (childrenValue < 0 || childrenValue > 50) {
                        isValid = false;
                        // errorMessage = 'Number of children must be between 0 and 50';
                    }
                    break;

                case 'arrival_date':
                    if (value === '') {
                        isValid = false;
                        // errorMessage = 'Arrival date is required';
                    }
                    else {
                        const selectedDate = new Date(value);
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);

                        if (selectedDate < today) {
                            isValid = false;
                            // errorMessage = 'Arrival date cannot be in the past';
                        }
                    }
                    break;
            }

            if (isValid) {
                this.clearError(field);
            } else {
                this.showError(field, errorMessage);
            }

            return isValid;
        }

        // Show error
        showError(field, message) {
            this.clearError(field);
            $(field).addClass('border-red-500');

            // Create error message element if it doesn't exist
            // let errorDiv = $(field).next('.tm-validation-error');
            // if (errorDiv.length === 0) {
            //     errorDiv = $('<div class="tm-validation-error text-sm mt-1" style="color: #ff4362 !important;"></div>');
            //     $(field).after(errorDiv);
            // }

            // errorDiv.text(message).removeClass('hidden');
            // errorDiv.text(message).css('display', 'block');
        }

        // Clear error
        clearError(field) {
            $(field).removeClass('border-red-500');
            // const errorDiv = $(field).next('.tm-validation-error');
            // if (errorDiv.length > 0) {
            //     // errorDiv.addClass('hidden').text('');
            //     errorDiv.css('display', 'none').text('');
            // }
        }

        // Validate form
        // validateForm() {
        //     let isValid = true;
        //     const fields = this.form.find('.tm-validate');
        //     let firstErrorField = null;

        //     // Validate all fields
        //     fields.each((index, field) => {
        //         if (!this.validateField(field)) {
        //             isValid = false;
        //             if (!firstErrorField) {
        //                 firstErrorField = field;
        //             }
        //         }
        //     });

        //     // Scroll to first error if any
        //     if (firstErrorField) {
        //         $('html, body').animate({
        //             scrollTop: $(firstErrorField).offset().top - 100
        //         }, 500);
        //         $(firstErrorField).focus();
        //     }

        //     return isValid;
        // }
        // Validate entire form
        validateForm() {
            let isValid = true;
            const fields = this.form.find('.tm-validate');
            let firstErrorField = null;

            // Validate all fields
            fields.each((index, field) => {
                if (!this.validateField(field)) {
                    isValid = false;
                    if (!firstErrorField) {
                        firstErrorField = field;
                    }
                }
            });

            // Smooth scroll to first error
            if (firstErrorField) {
                firstErrorField.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'  // centers the field in the viewport
                });
                $(firstErrorField).focus();
            }

            return isValid;
        }


        async handleSubmit(e) {
            e.preventDefault();

            // Update full phone number before validation
            this.updateFullPhoneNumber();

            // Validate all fields before submission
            if (!this.validateForm()) {
                this.showModal('Validation Error', 'Please fill in all the required fields before submitting the form.', 'error');
                return;
            }

            this.setLoading(true);

            try {
                const formData = new FormData(this.form[0]);
                formData.append('action', 'submit_tour_inquiry');
                formData.append('nonce', tourInquiryData.nonce);

                const response = await $.ajax({
                    url: tourInquiryData.ajax_url,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false
                });

                if (response.success) {
                    // this.showModal('Success!', 'Inquiry submitted successfully! We will get back to you soon.', 'success');
                    // Ajax response 
                    const successMessage = response.data || 'Inquiry submitted successfully!';
                    this.showModal('Success!', successMessage, 'success');

                    // Reset form
                    this.form[0].reset();
                    // Reset phone input
                    if (this.phoneInput) {
                        this.phoneInput.setNumber('');
                    }
                    // Clear all errors
                    this.form.find('.tm-validation-error').addClass('hidden');
                    this.form.find('.border-red-500').removeClass('border-red-500');
                } else {
                    // Error response 
                    const errorMessage = response.data || 'Submission failed';
                    throw new Error(errorMessage);
                    // throw new Error(response.data || 'Submission failed');
                }
            } catch (error) {
                console.error('Submission error:', error);
                // Catch block 
                const errorMessage = error.message || 'An error occurred while submitting your inquiry. Please try again.';
                this.showModal('Error', errorMessage, 'error');
                // this.showModal('Error', 'An error occurred while submitting your inquiry. Please try again.', 'error');
            } finally {
                this.setLoading(false);
            }
        }

        setLoading(loading) {
            if (loading) {
                this.submitBtn.prop('disabled', true).text('Submitting...');
            } else {
                this.submitBtn.prop('disabled', false).text('Inquiry Now');
            }
        }

    }

    // Initialize the form
    new TourInquiryForm();


    /**************************************************************************************
     * Tour Booking Form Submission with Validation
     **************************************************************************************/
    $('#tour-booking-form').on('submit', function (e) {
        e.preventDefault();

        // Validate form before submission
        if (!validateBookingForm()) {
            showBookingModal('Validation Error', 'Please fill in all the required fields correctly before submitting.', 'error');
            return;
        }

        var formData = $(this).serialize();
        formData += '&action=submit_tour_booking';

        $.ajax({
            url: tourInquiryData.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                $('#tour-booking-btn').prop('disabled', true).text('Submitting...');
            },
            success: function (response) {
                if (response.success) {
                    showBookingModal('Success!', 'Booking submitted successfully!', 'success');
                    // Reset form on success
                    $('#tour-booking-form')[0].reset();
                    // Clear all validation errors
                    clearBookingFormErrors();
                } else {
                    showBookingModal('Error', 'Error: ' + response.data, 'error');
                }
            },
            error: function () {
                showBookingModal('Error', 'An error occurred. Please try again.', 'error');
                // showTmModal('Error', 'An error occurred. Please try again.', 'error');
            },
            complete: function () {
                $('#tour-booking-btn').prop('disabled', false).text('Book Now');
            }
        });
    });

    // Booking Form Validation Function
    function validateBookingForm() {
        let isValid = true;
        const form = $('#tour-booking-form');

        // Clear previous errors
        clearBookingFormErrors();

        // Validate Full Name
        const fullName = form.find('#full_name').val().trim();
        if (fullName === '') {
            showBookingFieldError('full_name', 'Full name is required');
            isValid = false;
        } else if (fullName.length < 2) {
            showBookingFieldError('full_name', 'Full name must be at least 2 characters long');
            isValid = false;
        }

        // Validate Email
        const email = form.find('#email').val().trim();
        if (email === '') {
            showBookingFieldError('email', 'Email is required');
            isValid = false;
        } else {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showBookingFieldError('email', 'Please enter a valid email address');
                isValid = false;
            }
        }

        // Validate Phone
        const phone = form.find('#phone').val().trim();
        if (phone === '') {
            showBookingFieldError('phone', 'Phone number is required');
            isValid = false;
        } else {
            // Basic phone validation - adjust regex as needed
            const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
            const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
            if (!phoneRegex.test(cleanPhone)) {
                showBookingFieldError('phone', 'Please enter a valid phone number');
                isValid = false;
            }
        }

        // Validate Country
        const country = form.find('#country').val().trim();
        if (country === '') {
            showBookingFieldError('country', 'Country is required');
            isValid = false;
        }


        // Scroll to first error if any
        if (!isValid) {
            const firstErrorField = form.find('.border-red-500').first();
            if (firstErrorField.length) {
                $('html, body').animate({
                    scrollTop: firstErrorField.offset().top - 100
                }, 500);
                firstErrorField.focus();
            }
        }

        return isValid;
    }

    // Show error for specific booking form field
    function showBookingFieldError(fieldId, message) {
        const field = $(`#${fieldId}`);
        field.addClass('border-red-500');

        // Create error message element if it doesn't exist
        let errorDiv = field.next('.booking-validation-error');
        if (errorDiv.length === 0) {
            errorDiv = $('<div class="booking-validation-error text-sm mt-1" style="color: #ff4362 !important;"></div>');
            field.after(errorDiv);
        }

        errorDiv.text(message).removeClass('hidden');
    }

    // Clear all booking form errors
    function clearBookingFormErrors() {
        $('#tour-booking-form').find('.border-red-500').removeClass('border-red-500');
        $('#tour-booking-form').find('.booking-validation-error').addClass('hidden').text('');
    }

    // Real-time validation for booking form fields
    $(document).ready(function () {
        // Add real-time validation on blur
        $('#tour-booking-form .tm-validate').on('blur', function () {
            validateBookingField(this);
        });

        // Clear errors on input
        $('#tour-booking-form .tm-validate').on('input', function () {
            clearBookingFieldError(this);
        });

        // Initialize modal close handlers
        initializeTmModal();
    });

    // Validate individual booking field
    function validateBookingField(field) {
        const fieldId = $(field).attr('id');
        const value = $(field).val().trim();
        let isValid = true;
        let errorMessage = '';

        switch (fieldId) {
            case 'full_name':
                if (value === '') {
                    isValid = false;
                    errorMessage = 'Full name is required';
                } else if (value.length < 2) {
                    isValid = false;
                    errorMessage = 'Full name must be at least 2 characters long';
                }
                break;

            case 'email':
                if (value === '') {
                    isValid = false;
                    errorMessage = 'Email is required';
                } else {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(value)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid email address';
                    }
                }
                break;

            case 'phone':
                if (value === '') {
                    isValid = false;
                    errorMessage = 'Phone number is required';
                } else {
                    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
                    const cleanPhone = value.replace(/[\s\-\(\)]/g, '');
                    if (!phoneRegex.test(cleanPhone)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid phone number';
                    }
                }
                break;

            case 'country':
                if (value === '') {
                    isValid = false;
                    errorMessage = 'Country is required';
                }
                break;
        }

        if (isValid) {
            clearBookingFieldError(field);
        } else {
            showBookingFieldError(fieldId, errorMessage);
        }

        return isValid;
    }

    // Clear individual booking field error
    function clearBookingFieldError(field) {
        const fieldId = $(field).attr('id');
        const fieldElement = $(`#${fieldId}`);
        fieldElement.removeClass('border-red-500');

        const errorDiv = fieldElement.next('.booking-validation-error');
        if (errorDiv.length > 0) {
            errorDiv.addClass('hidden').text('');
        }
    }

    // Helper function for booking form modal
    // function showBookingModal(title, message, type) {
    //     // Remove existing modal if any
    //     $('#message-modal').remove();

    //     // Determine OK button behavior based on message type
    //     const okButtonHtml = type === 'success'
    //         ? `<a href="${window.location.origin}/" class="bg-primary text-white py-2 px-4 rounded flex justify-center">OK</a>`
    //         : `<button type="button" class="bg-primary text-white py-2 px-4 rounded flex justify-center modal-close-btn">OK</button>`;

    //     // Create modal HTML
    //     const modalHtml = `
    //     <div id="message-modal" class="fixed inset-0 flex items-center justify-center z-50" style="background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(0px);">
    //         <div class="bg-white rounded-lg max-w-md mx-4 px-10 py-10" style="box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);">
    //             <div class="text-center">
    //                 <p class="modal-message text-gray-600 mb-6">${message}</p>
    //             </div>
    //             <div class="flex justify-end p-4">
    //                 ${okButtonHtml}
    //             </div>
    //         </div>
    //     </div>
    // `;

    //     // Add modal to body
    //     $('body').append(modalHtml);

    //     // Add event listener for error modal close button
    //     if (type === 'error') {
    //         $('.modal-close-btn').on('click', () => {
    //             $('#message-modal').remove();
    //         });

    //         // Close modal when clicking outside (only for error messages)
    //         $('#message-modal').on('click', function (e) {
    //             if (e.target === this) {
    //                 $(this).remove();
    //             }
    //         });

    //         // Close on escape key (only for error messages)
    //         $(document).on('keydown', function (e) {
    //             if (e.key === 'Escape' && $('#message-modal').length) {
    //                 $('#message-modal').remove();
    //             }
    //         });
    //     }
    // }

    function initializeTmModal() {
        // Support multiple modal button class names used in markup
        // Close modal when clicking any close button
        $(document).off('click.tm.modal').on('click.tm.modal', '.tm-modal-close, .tm-modal-close-btn', function () {
            $('#tm-booking-modal').hide();
        });

        // OK button behavior — close and redirect if success
        $(document).off('click.tm.modal.ok').on('click.tm.modal.ok', '.tm-modal-ok, .tm-modal-ok-btn', function () {
            $('#tm-booking-modal').hide();
            if ($('#tm-booking-modal').hasClass('success-modal')) {
                const homeUrl = tourInquiryData.home_url || window.location.origin;
                window.location.href = homeUrl;
            }
        });

        // Close when clicking outside modal content (click on the modal container / overlay)
        $('#tm-booking-modal').off('click.tm.modal.outside').on('click.tm.modal.outside', function (e) {
            if (e.target === this) {
                $(this).hide();
            }
        });

        // Close on escape key
        $(document).off('keydown.tm.modal.escape').on('keydown.tm.modal.escape', function (e) {
            if (e.key === 'Escape' && $('#tm-booking-modal').is(':visible')) {
                $('#tm-booking-modal').hide();
            }
        });
    }

    // Show TM Modal with custom message
    function showBookingModal(title, message, type = 'info') {
        const modal = $('#tm-booking-modal');
        modal.data('isSuccess', (type === 'success'));

        // Set title and message (elements may or may not exist in markup)
        modal.find('.tm-modal-title').text(title);
        modal.find('.tm-modal-message').text(message);

        // Normalize classes and add type class (e.g. 'success-modal' or 'error-modal')
        modal.removeClass('error-modal success-modal info-modal');
        modal.addClass(type + '-modal');

        // Support both ok class variations
        const okBtn = modal.find('.tm-modal-ok, .tm-modal-ok-btn');
        okBtn.text(type === 'success' ? 'Return to Home' : 'OK');

        // Show modal and focus the OK button for accessibility
        modal.show();
        setTimeout(function () {
            okBtn.first().focus();
        }, 100);
    }

});

/**
 * flatpickr
 */
document.addEventListener('DOMContentLoaded', function () {
    flatpickr("#arrival_date", {
        minDate: new Date().fp_incr(1), // Tomorrow
        dateFormat: "Y-m-d",
        allowInput: true
    });
});