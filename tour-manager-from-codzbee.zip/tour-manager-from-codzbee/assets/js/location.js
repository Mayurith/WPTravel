
/* tm_add_custom_meta_box_for_location_gallery function js*/
jQuery(document).ready(function ($) {

  var imageFrame;
  var imageInput = $('#location_image_gallery');
  var imagePreview = $('#image_preview');
  var removeImages = $('#remove_all_images');

  $('#upload_images').click(function (e) {

    e.preventDefault();
    if (imageFrame) {
      imageFrame.open();
      return;
    }

    imageFrame = wp.media({
      title: 'Select Images',
      multiple: true,
      library: { type: 'image' },
      button: { text: 'Add Image Gallery' }
    });

    imageFrame.on('select', function () {
      var attachments = imageFrame.state().get('selection').toJSON();
      var imageIDs = imageInput.val() ? imageInput.val().split(',') : [];

      attachments.forEach(function (attachment) {
        if (!imageIDs.includes(attachment.id.toString())) {
          imageIDs.push(attachment.id);
          imagePreview.append(`
                    <div class="gallery-item" >
                        <img src="${attachment.url}" class="gallery-item-inner">
                        <span class="remove-image" data-id="${attachment.id}" >×</span>
                    </div>
                `);
        }
      });

      imageInput.val(imageIDs.join(','));
      removeImages.show();
    });

    imageFrame.open();
  });

  /** Remove individual image */
  $(document).on('click', '.remove-image', function () {
    var imageID = $(this).data('id').toString();
    var imageIDs = imageInput.val().split(',');

    imageIDs = imageIDs.filter(id => id !== imageID);
    imageInput.val(imageIDs.join(','));

    $(this).parent().remove();
    if (imageIDs.length === 0) removeImages.hide();
  });

  /** Remove all images */
  removeImages.click(function () {
    imageInput.val('');
    imagePreview.empty();
    $(this).hide();
  });

  if (imageInput.val()) removeImages.show();

  // Handle city selection change
  $('#location_city_id').on('change', function () {
    const selectedOption = $(this).find('option:selected');
    const cityDetails = $('#city-details');

    if (selectedOption.val()) {
      // Update the hidden fields and display
      $('#city-name').val(selectedOption.text());
      $('#city-code-value').val(selectedOption.data('city-code'));
      $('#city-lat-value').val(selectedOption.data('city-lat'));
      $('#city-lng-value').val(selectedOption.data('city-lng'));

      // Update the displayed details
      $('#city-code').text(selectedOption.data('city-code'));
      $('#city-latitude').text(selectedOption.data('city-lat'));
      $('#city-longitude').text(selectedOption.data('city-lng'));

      // Show the details section
      cityDetails.show();
    } else {
      // Hide the details section if no city selected
      cityDetails.hide();
    }
  });

})


// Map

// document.addEventListener('DOMContentLoaded', function () {
//     const input = document.getElementById('location_input');
//     const latInput = document.getElementById('location_lat');
//     const lngInput = document.getElementById('location_lng');

//     if (!input || !latInput || !lngInput) return;

//     const defaultLat = parseFloat(latInput.value) || 37.7749;
//     const defaultLng = parseFloat(lngInput.value) || -122.4194;

//     const map = new google.maps.Map(document.getElementById('map'), {
//         center: { lat: defaultLat, lng: defaultLng },
//         zoom: 13
//     });

//     const marker = new google.maps.Marker({
//         map: map,
//         position: { lat: defaultLat, lng: defaultLng },
//         draggable: true
//     });

//     const autocomplete = new google.maps.places.Autocomplete(input);
//     autocomplete.bindTo('bounds', map);

//     autocomplete.addListener('place_changed', () => {
//         const place = autocomplete.getPlace();

//         if (!place.geometry || !place.geometry.location) {
//             alert("No details available for input: '" + place.name + "'");
//             return;
//         }

//         const location = place.geometry.location;
//         map.setCenter(location);
//         marker.setPosition(location);

//         latInput.value = location.lat();
//         lngInput.value = location.lng();
//     });

//     // Update hidden fields if marker is dragged
//     marker.addListener('dragend', function () {
//         const position = marker.getPosition();
//         latInput.value = position.lat();
//         lngInput.value = position.lng();
//     });
// });

document.addEventListener('DOMContentLoaded', function () {
  const input = document.getElementById('location_input');
  const latInput = document.getElementById('location_lat');
  const lngInput = document.getElementById('location_lng');
  const mapContainer = document.getElementById('map');

  if (!input || !latInput || !lngInput || !mapContainer) return;

  const defaultLat = parseFloat(latInput.value) || 37.7749;
  const defaultLng = parseFloat(lngInput.value) || -122.4194;

  const map = new google.maps.Map(mapContainer, {
    center: { lat: defaultLat, lng: defaultLng },
    zoom: 13
  });

  const marker = new google.maps.Marker({
    map: map,
    position: { lat: defaultLat, lng: defaultLng },
    draggable: true
  });

  const autocomplete = new google.maps.places.Autocomplete(input, {
    types: ['geocode']
  });

  autocomplete.bindTo('bounds', map);

  autocomplete.addListener('place_changed', () => {
    const place = autocomplete.getPlace();

    if (!place.geometry || !place.geometry.location) {
      alert("No details available for input: '" + place.name + "'");
      return;
    }

    const location = place.geometry.location;
    map.setCenter(location);
    map.setZoom(15);
    marker.setPosition(location);

    latInput.value = location.lat();
    lngInput.value = location.lng();
  });

  marker.addListener('dragend', function () {
    const position = marker.getPosition();
    latInput.value = position.lat();
    lngInput.value = position.lng();
  });
});

