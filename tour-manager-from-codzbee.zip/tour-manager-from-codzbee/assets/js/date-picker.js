/** Date Picker JS */
    document.addEventListener('DOMContentLoaded', function () {
        if (typeof flatpickr !== 'undefined') {
            flatpickr("#booking-date", {
                minDate: "today",
                dateFormat: "Y-m-d",
                allowInput: true
            });
            flatpickr("#inquiry-datepicker", {
                minDate: "today",
                dateFormat: "Y-m-d",
                allowInput: true
            });
        }
    });

