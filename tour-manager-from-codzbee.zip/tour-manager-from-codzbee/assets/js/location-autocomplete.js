jQuery(document).ready(function ($) {

    if ($('#location_search').length) {
        const searchInput = document.getElementById('location_search');
        const latInput = document.getElementById('location_lat');
        const lngInput = document.getElementById('location_lng');
        const placeIdInput = document.getElementById('location_place_id');
        const mapElement = document.getElementById('location_map');

        let map;
        let marker;

        /** Initialize autocomplete */
        const autocomplete = new google.maps.places.Autocomplete(searchInput, {
            types: ['geocode', 'establishment'],
            fields: ['geometry', 'formatted_address', 'place_id']
        });

        /** When a place is selected */
        autocomplete.addListener('place_changed', function () {
            const place = autocomplete.getPlace();

            if (!place.geometry) {
                alert("No details available for input: '" + place.name + "'");
                return;
            }

            /** Update coordinates */
            searchInput.value = place.formatted_address || searchInput.value;
            latInput.value = place.geometry.location.lat();
            lngInput.value = place.geometry.location.lng();
            placeIdInput.value = place.place_id;

            // Initialize or update map
            if (!map) {
                map = new google.maps.Map(mapElement, {
                    center: place.geometry.location,
                    zoom: 15
                });

                marker = new google.maps.Marker({
                    map: map,
                    position: place.geometry.location
                });
            } else {
                map.setCenter(place.geometry.location);
                marker.setPosition(place.geometry.location);
            }

            // Show the map
            $(mapElement).show();
        });

        // If we have existing coordinates, initialize the map
        if (locationData.lat && locationData.lng) {
            const location = new google.maps.LatLng(
                parseFloat(locationData.lat),
                parseFloat(locationData.lng)
            );

            map = new google.maps.Map(mapElement, {
                center: location,
                zoom: 15
            });

            marker = new google.maps.Marker({
                map: map,
                position: location
            });

            // Show the map
            $(mapElement).show();
        }
    }
});