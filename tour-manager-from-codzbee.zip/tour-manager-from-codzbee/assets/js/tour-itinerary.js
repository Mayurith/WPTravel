jQuery(function($) {
    const container = $('#days-container');
    const addDayBtn = $('#add-day');
    const citiesData = tourItinerary.cities;
    let dayCounter = container.children().length;

    // Add new day
    addDayBtn.on('click', function() {
        addDayBlock(dayCounter++);
    });

    // Initialize existing days
    if (tourItinerary.days.length) {
        tourItinerary.days.forEach((day, index) => {
            const dayBlock = addDayBlock(index);
            initializeDayBlock(dayBlock, day);
        });
    }

    // Add day block function
    function addDayBlock(index) {
        const dayBlock = $(`
            <div class="day-block" data-day-index="${index}">
                <div class="day-header">
                    <h3>Day <span class="day-number">${index + 1}</span></h3>
                    <button type="button" class="remove-day">Remove Day</button>
                </div>
                
                <div class="day-content">
                    <div class="form-field">
                        <label>Description</label>
                        <textarea name="itinerary[${index}][description]"></textarea>
                    </div>
                    
                    <div class="form-field">
                        <label>Meal Plan</label>
                        <input type="text" name="itinerary[${index}][meal_plan]">
                    </div>
                    
                    <div class="form-field">
                        <label>Hotel</label>
                        <select name="itinerary[${index}][hotel_id]" class="hotel-select">
                            <option value="">Select Hotel</option>
                        </select>
                    </div>
                    
                    <h4>Cities</h4>
                    <div class="cities-container"></div>
                    <button type="button" class="add-city button">Add City</button>
                </div>
            </div>
        `);
        
        container.append(dayBlock);
        
        // Add city event
        dayBlock.find('.add-city').on('click', function() {
            addCityBlock(dayBlock, $(this).siblings('.cities-container'));
        });
        
        // Remove day event
        dayBlock.find('.remove-day').on('click', function() {
            dayBlock.remove();
            updateDayNumbers();
        });
        
        return dayBlock;
    }

    // Initialize day with saved data
    function initializeDayBlock(dayBlock, dayData) {
        dayBlock.find('textarea').val(dayData.description);
        dayBlock.find('input[name*="meal_plan"]').val(dayData.meal_plan);
        
        // Initialize cities
        if (dayData.cities && dayData.cities.length) {
            const citiesContainer = dayBlock.find('.cities-container');
            dayData.cities.forEach(city => {
                const cityBlock = addCityBlock(dayBlock, citiesContainer);
                initializeCityBlock(cityBlock, city);
            });
        }
        
        // Initialize hotel
        updateHotelDropdown(dayBlock, dayData.cities);
    }

    // Add city block
    function addCityBlock(dayBlock, container) {
        const cityIndex = container.children().length;
        const dayIndex = dayBlock.data('day-index');
        
        const cityBlock = $(`
            <div class="city-block">
                <div class="city-header">
                    <h4>City #${cityIndex + 1}</h4>
                    <button type="button" class="remove-city">Remove</button>
                </div>
                
                <div class="city-content">
                    <div class="form-field">
                        <label>City</label>
                        <select class="city-select" name="itinerary[${dayIndex}][cities][${cityIndex}][city_id]">
                            <option value="">Select City</option>
                            ${citiesData.map(city => 
                                `<option value="${city.id}">${city.name}</option>`
                            ).join('')}
                        </select>
                    </div>
                    
                    <div class="activities-container">
                        <div class="loading">Loading activities...</div>
                    </div>
                </div>
            </div>
        `);
        
        container.append(cityBlock);
        
        // City change event
        cityBlock.find('.city-select').on('change', function() {
            const cityId = $(this).val();
            loadActivities(cityBlock, cityId);
            updateDayHotelDropdown(dayBlock);
        });
        
        // Remove city event
        cityBlock.find('.remove-city').on('click', function() {
            cityBlock.remove();
            updateDayHotelDropdown(dayBlock);
        });
        
        return cityBlock;
    }

    // Initialize city block with saved data
    function initializeCityBlock(cityBlock, cityData) {
        cityBlock.find('.city-select').val(cityData.city_id).trigger('change');
        
        // Activities will be loaded via AJAX on city select
    }

    // Load activities for a city
    function loadActivities(cityBlock, cityId) {
        const container = cityBlock.find('.activities-container');
        container.html('<div class="loading">Loading activities...</div>');
        
        if (!cityId) {
            container.empty();
            return;
        }
        
        $.ajax({
            url: tourItinerary.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_locations_by_city',
                nonce: tourItinerary.nonce,
                city_id: cityId
            },
            success: function(response) {
                if (response.success) {
                    let activitiesHTML = '';
                    let attractionsHTML = '';
                    
                    response.data.forEach(location => {
                        const item = `
                            <label>
                                <input type="checkbox" name="itinerary[${cityBlock.closest('.day-block').data('day-index')}][cities][${cityBlock.index()}][${location.type.toLowerCase()}s][]" value="${location.id}">
                                ${location.title}
                            </label><br>
                        `;
                        
                        if (location.type === 'Activity') {
                            activitiesHTML += item;
                        } else {
                            attractionsHTML += item;
                        }
                    });
                    
                    container.html(`
                        ${activitiesHTML ? '<div><strong>Activities</strong><br>' + activitiesHTML + '</div>' : ''}
                        ${attractionsHTML ? '<div><strong>Attractions</strong><br>' + attractionsHTML + '</div>' : ''}
                    `);
                }
            }
        });
    }

    // Update hotel dropdown for a day
    function updateDayHotelDropdown(dayBlock) {
        const cityIds = [];
        dayBlock.find('.city-select').each(function() {
            if ($(this).val()) cityIds.push($(this).val());
        });
        
        updateHotelDropdown(dayBlock, cityIds);
    }

    // Update hotel dropdown
    function updateHotelDropdown(dayBlock, cityIds) {
        const hotelSelect = dayBlock.find('.hotel-select');
        hotelSelect.html('<option value="">Loading hotels...</option>');
        
        if (cityIds.length === 0) {
            hotelSelect.html('<option value="">No hotels available</option>');
            return;
        }
        
        $.ajax({
            url: tourItinerary.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_hotels_by_cities',
                nonce: tourItinerary.nonce,
                city_ids: cityIds
            },
            success: function(response) {
                if (response.success) {
                    let options = '<option value="">Select Hotel</option>';
                    
                    response.data.forEach(hotel => {
                        options += `<option value="${hotel.id}">${hotel.title}</option>`;
                    });
                    
                    hotelSelect.html(options || '<option value="">No hotels found</option>');
                }
            }
        });
    }

    // Update day numbers
    function updateDayNumbers() {
        container.find('.day-block').each(function(index) {
            $(this).find('.day-number').text(index + 1);
            $(this).attr('data-day-index', index);
        });
    }
});