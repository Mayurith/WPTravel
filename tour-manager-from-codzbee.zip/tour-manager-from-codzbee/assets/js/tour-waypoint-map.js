jQuery(document).ready(function ($) {
    if (typeof tourMapData !== 'undefined') {
        // Initialize the map
        var map = new google.maps.Map(document.getElementById('tour-itinerary-map'), {
            zoom: parseInt(tourMapData.zoom),
            center: new google.maps.LatLng(
                tourMapData.itinerary[0].lat,
                tourMapData.itinerary[0].lng
            ),
            mapTypeId: tourMapData.mapType
        });

        // Add custom styles if defined
        if (tourMapData.mapStyles) {
            map.setOptions({ styles: tourMapData.mapStyles });
        }

        // Create markers and path
        var markers = [];
        var pathCoordinates = [];
        var bounds = new google.maps.LatLngBounds();

        tourMapData.itinerary.forEach(function (location) {
            var position = new google.maps.LatLng(location.lat, location.lng);

            // Create marker
            var marker = new google.maps.Marker({
                position: position,
                map: map,
                title: 'Day ' + location.day + ': ' + location.title,
                label: {
                    text: location.day.toString(),
                    color: 'white',
                    fontWeight: 'bold'
                }
            });

            // Create info window content
            var contentString = `
                <div class="map-info-window">
                    <h3>Day ${location.day}: ${location.title}</h3>
                    ${location.stay_time ? `<p><strong>Stay Time:</strong> ${location.stay_time}</p>` : ''}
                    ${location.description ? `<div class="location-description">${location.description}</div>` : ''}
                </div>
            `;

            // Add info window
            var infowindow = new google.maps.InfoWindow({
                content: contentString
            });

            marker.addListener('click', function () {
                infowindow.open(map, marker);
            });

            markers.push(marker);
            pathCoordinates.push(position);
            bounds.extend(position);
        });

        // Fit map to bounds
        map.fitBounds(bounds);

        // Draw path connecting the points
        var path = new google.maps.Polyline({
            path: pathCoordinates,
            geodesic: true,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 2
        });

        path.setMap(map);
    }
});