jQuery(document).ready(function ($) {
    let frame;

    // Use event delegation for dynamic elements
    $(document).on('click', '#upload_tour_category_image', function (e) {
        console.log('Upload button clicked');
        e.preventDefault();

        var $button = $(this);
        var $preview = $('#tour_category_image_preview');
        var $input = $('#tour_category_image');
        var $removeBtn = $('#remove_tour_category_image');

        // If the media frame already exists, reopen it.
        if (frame) {
            frame.open();
            return;
        }

        // Create a new media frame
        frame = wp.media({
            title: 'Select or Upload Image',
            button: {
                text: 'Use this image'
            },
            library: {
                type: 'image' // Only allow images
            },
            multiple: false
        });

        // When an image is selected in the media frame...
        frame.on('select', function () {
            // Get media attachment details from the frame state
            var attachment = frame.state().get('selection').first().toJSON();

            // Set the hidden field value to the attachment ID
            $input.val(attachment.id);

            // Update image preview
            var imageUrl = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
            $preview.html('<img src="' + imageUrl + '" style="max-width: 100%; max-height: 200px;">');

            // Show remove button
            $removeBtn.show();
        });

        // Finally, open the modal on click
        frame.open();
    });

    // Remove button click
    $(document).on('click', '#remove_tour_category_image', function (e) {
        e.preventDefault();

        var $preview = $('#tour_category_image_preview');
        var $input = $('#tour_category_image');
        var $removeBtn = $(this);

        // Clear the hidden field
        $input.val('');

        // Reset the preview
        $preview.html('<span style="color: #999;">No icon selected</span>');

        // Hide remove button
        $removeBtn.hide();
    });
});