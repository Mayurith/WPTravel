/** tm_render_inquiry_meta_box */
jQuery(document).ready(function ($) {
    $(document).on('click', '.Edit-details', function (e) {
        e.preventDefault();

        const postId = $(this).data('id');
        const type = $(this).data('type');
        const nonce = $(this).data('nonce');

        // Example: Show modal or load details
        alert('Load data for Post ID: ' + postId + ' of type: ' + type);

        // TODO: Add AJAX logic or modal popup
    });







    /** tm_render_inquiry_meta_box function footer */

    // Handle form submission
    $('#post').on('submit', function (e) {
        const status = $('select[name="tm_inquiry_status"]').val();

        // Only handle accepted/rejected statuses
        if (status === 'accepted' || status === 'rejected') {
            // Hide the select dropdown
            $('.tm-status-buttons').hide();

            // Show the appropriate message
            $(`#${status}Message`).show();

            // Make the message container visible
            $('.tm-status-message').show();
        }
    });

    // Show the correct status on page load
    const currentStatus = '<?php echo esc_js($current_status); ?>';
    if (currentStatus === 'accepted' || currentStatus === 'rejected') {
        $('.tm-status-buttons').hide();
        $(`#${currentStatus}Message`).show();
        $('.tm-status-message').show();

        if (currentStatus === 'accepted') {
            // $('.fa-xmark').hide();
            $('.tm-reject').hide();
        } else {
            // $('.fa-check').hide();
            $('.tm-accept').hide();
        }
    }
});





/** tm_booking_inquiry_rejected_meta_box */



/** tm_booking_inquiry_rejected_meta_box */
// jQuery(document).ready(function($) {
    
//     // Form submission validation for rejected status
//     $('#post').on('submit', function(e) {
//         const status = $('select[name="tm_inquiry_status"]').val();
//         const rejectedNote = $('textarea[name="custom_rejected_note"]').val().trim();
        
//         if (status === 'rejected' && rejectedNote === '') {
//             if (typeof tm_inquiry_data !== 'undefined') {
//                 alert(tm_inquiry_data.rejected_note_required);
//             } else {
//                 alert('Please add the Rejected Note before updating.');
//             }
//             e.preventDefault();
//             return false;
//         }
//     });
// });

