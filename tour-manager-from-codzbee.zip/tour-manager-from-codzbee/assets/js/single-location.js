
/**
 * Initialize Swiper
 */
document.addEventListener('DOMContentLoaded', function () {
    new Swiper('.mySwiper', {
        slidesPerView: 1,
        spaceBetween: 10,
        loop: true,
        grabCursor: true,
        simulateTouch: true,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            640: { slidesPerView: 1 },
            1024: { slidesPerView: 4 }
        }
    });

});

/**
 * Cursor Animation
 */
document.addEventListener('DOMContentLoaded', function () {
    const cursor = document.getElementById("custom-cursor");
    const swiperContainer = document.querySelector(".mySwiper");

    document.addEventListener("mousemove", function (e) {
        cursor.style.left = e.clientX + "px";
        cursor.style.top = e.clientY + "px";
    });

    swiperContainer.addEventListener("mouseenter", function () {
        cursor.style.display = "flex";
    });

    swiperContainer.addEventListener("mouseleave", function () {
        cursor.style.display = "none";
    });
});