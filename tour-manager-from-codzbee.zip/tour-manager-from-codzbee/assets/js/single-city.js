/** 
 * Toggle Short/Full Description
 * Handles the toggling of short and full descriptions on the city detail page.
 */
document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('toggleBtn');
    const shortDesc = document.getElementById('shortDescription');
    const fullDesc = document.getElementById('fullDescription');

    if (!toggleBtn) return; // Exit if there's no toggle button (short text only)

    toggleBtn.addEventListener('click', function () {
        const isHidden = fullDesc.classList.contains('hidden');

        if (isHidden) {
            shortDesc.classList.add('hidden');
            fullDesc.classList.remove('hidden');
            toggleBtn.textContent = 'Show Less';
        } else {
            shortDesc.classList.remove('hidden');
            fullDesc.classList.add('hidden');
            toggleBtn.textContent = 'Show More';
        }
    });
});


/**
 * Handle the FAQs toggling (accordion style)
 * @param {*} id 
 */
function toggleFaq(id) {
    const content = document.getElementById(id);
    const icon = document.getElementById('icon-' + id);

    const isHidden = content.classList.contains('hidden');

    // Optional: Close other open FAQs (accordion style)
    document.querySelectorAll('.faq-answer').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('svg[id^="icon-faq-"]').forEach(el => el.classList.remove('rotate-180'));

    if (isHidden) {
        content.classList.remove('hidden');
        icon.classList.add('rotate-180');
    }
}


/**
 * Handle the nearest destination slider using Swiper.js
 */
document.addEventListener('DOMContentLoaded', function () {
    if (typeof Swiper !== 'undefined') {
        new Swiper('.destination-slider', {
            slidesPerView: 2,
            spaceBetween: 24,
            loop: false,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                640: { slidesPerView: 2 },
                768: { slidesPerView: 3 },
                1024: { slidesPerView: 4 },
            }
        });
    }
});


/**
 * Custom Cursor for Nearest Destination Slider
 */
document.addEventListener('DOMContentLoaded', function () {
    const cursor = document.getElementById("custom-cursor");
    const swiperSlides = document.querySelectorAll(".swiper-slide");

    if (cursor) {
        document.addEventListener("mousemove", function (e) {
            cursor.style.left = e.clientX + "px";
            cursor.style.top = e.clientY + "px";
        });

        swiperSlides.forEach(function (slide) {
            slide.addEventListener("mouseenter", function () {
                cursor.style.display = "flex";
            });
            slide.addEventListener("mouseleave", function () {
                cursor.style.display = "none";
            });
        });
    }
});



// Swiper Slider
let thumbSwiper, modalSwiper;
const openModalButton = document.getElementById("see-photos-btn");

// Function to initialize Swiper in modal
function initSwiper() {
    // Thumbnail swiper
    thumbSwiper = new Swiper(".thumb-swiper", {
        spaceBetween: 10,
        slidesPerView: "auto",
        freeMode: true,
        watchSlidesProgress: true,
        // autoplay: {
        //     delay: 3000,
        // },
        height: 300,
    });

    // Modal swiper
    modalSwiper = new Swiper(".modal-swiper", {
        spaceBetween: 10,
        // autoplay: {
        //     delay: 3000,
        // },
        navigation: {
            nextEl: ".modal-next",
            prevEl: ".modal-prev",
        },
        thumbs: {
            swiper: thumbSwiper,
        },
        on: {
            slideChange: function () {
                document.getElementById('current-slide').textContent = this.activeIndex + 1;
            }
        }

    });
}

// Function to open modal
function openModal(slideIndex = 0) {

    const modal = document.getElementById("imageModal");

    // Initialize Swiper
    if (modalSwiper) {
        modalSwiper.destroy(true, true);
        thumbSwiper.destroy(true, true);
    }

    initSwiper();

    // Show modal and go to selected slide
    modal.style.display = "block";
    modalSwiper.slideTo(slideIndex);
    document.getElementById('current-slide').textContent = slideIndex + 1;
}

// Close modal functionality
document.querySelector(".close").addEventListener("click", () => {
    document.getElementById("imageModal").style.display = "none";
});

// Close modal when clicking outside content
window.addEventListener("click", (event) => {
    if (event.target === document.getElementById("imageModal")) {
        document.getElementById("imageModal").style.display = "none";
    }
});

// Close modal with Escape key
document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
        document.getElementById("imageModal").style.display = "none";
    }
});

// Initialize button functionality
// document.addEventListener("DOMContentLoaded", () => {
//     // Add event listener to the button
//     document.getElementById("see-photos-btn").addEventListener("click", () => {
//         openModal(0);
//     });
// });
document.addEventListener("DOMContentLoaded", () => {
    // --- NEW LOGIC HERE ---
    // Count the number of swiper slides that were generated by PHP
    const slideCount = document.querySelectorAll('.modal-swiper .swiper-slide').length;

    if (slideCount === 0) {
        // If there are no images, disable the button
        if (openModalButton) {
            openModalButton.disabled = true;
            // Optional: You might also hide the button entirely if you prefer
            // openModalButton.style.display = 'none';
        }
    } else {
        // If images exist, enable the button and add the click listener
        if (openModalButton) {
            openModalButton.disabled = false; // Ensure it's enabled if default is disabled
            openModalButton.addEventListener("click", () => {
                openModal(0);
            });
        }
    }
    // ----------------------
});