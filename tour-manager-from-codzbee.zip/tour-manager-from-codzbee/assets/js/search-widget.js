/**
 * @package Tour Manager
 * @subpackage Search Widget : Hotel Search JS
 * @since 1.0
 */


jQuery(document).ready(function ($) {

    /**
     * Date Picker
     */
    var dateFormat = "mm/dd/yy";

    // Set default dates (tomorrow and day after tomorrow)
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    var dayAfterTomorrow = new Date();
    dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);

    var checkin = $("#checkin").datepicker({
        minDate: 0,
        defaultDate: tomorrow,
        dateFormat: dateFormat,
        onClose: function (selectedDate) {
            if (selectedDate) {
                // Set checkout min date to selected checkin date
                $("#checkout").datepicker("option", "minDate", selectedDate);
                $("#checkin-error").addClass('hidden');

                // If checkout is empty or before/equal to selected checkin, update it to next day
                var checkoutDate = $("#checkout").val();
                if (!checkoutDate || new Date(selectedDate) >= new Date(checkoutDate)) {
                    var nextDay = new Date(selectedDate);
                    nextDay.setDate(nextDay.getDate() + 1);
                    $("#checkout").datepicker("setDate", nextDay);
                }
            }
        },
        onSelect: function (selectedDate) {
            $("#checkin-error").addClass('hidden');
        }
    });

    var checkout = $("#checkout").datepicker({
        minDate: 1, // Minimum is tomorrow (when no checkin selected)
        defaultDate: dayAfterTomorrow,
        dateFormat: dateFormat,
        onClose: function (selectedDate) {
            if (selectedDate) {
                $("#checkout-error").addClass('hidden');
            }
        },
        onSelect: function (selectedDate) {
            $("#checkout-error").addClass('hidden');
        }
    });

    // Set default values
    $("#checkin").datepicker("setDate", tomorrow);
    $("#checkout").datepicker("setDate", dayAfterTomorrow);


    // -------------------------------------

    $('.destination-select').select2({
        ajax: {
            transport: function (params, success, failure) {
                const searchTerm = params.data.term || ''; // user input

                callCoreBookingEngineApi('GET', 'api/hotel/destination-search', {}, {
                    page: 1,
                    limit: 50,
                    search: searchTerm // pass search term here
                }).then(function (response) {
                    console.log(response);
                    const data = response.data;

                    // Format the hotels
                    const hotels = data.hotels.map(hotel => ({
                        id: `hotels/${hotel.id}/${hotel.slug}`,
                        text: hotel.name
                    }));

                    // Format the cities
                    const cities = data.cities.map(city => ({
                        id: `region/${city.id}`,
                        text: city.name
                    }));

                    // Format the countries
                    const countries = data.countries.map(country => ({
                        id: `region/${country.id}`,
                        text: country.name
                    }));

                    // Group them into Select2 optgroup-style format
                    const groupedResults = [
                        {
                            text: 'HOTELS',
                            children: hotels
                        },
                        {
                            text: 'CITIES',
                            children: cities
                        },
                        {
                            text: 'COUNTRIES',
                            children: countries
                        }
                    ].filter(group => group.children && group.children.length > 0);

                    // Return grouped results
                    success({ results: groupedResults });

                }).catch(failure);
            },
            processResults: function (data) {
                return data; // already formatted above
            }
        },
        placeholder: 'Where to Next',
        minimumInputLength: 3, // start searching after 3 character
        width: '100%',
    });


    // -------------------------------------


    /**
     * Guest modal
     */
    let rooms = [{
        roomId: 1,
        adults: 2,
        children: 0,
        childrenAges: []
    }];

    const MAX_ROOMS = 9;
    const MAX_ADULTS_PER_ROOM = 6;
    const MAX_CHILDREN_PER_ROOM = 4;

    // Initialize guest modal
    function initGuestModal() {
        updateRoomsDisplay();
        updateGuestSummary();
    }

    // Update rooms display in modal
    function updateRoomsDisplay() {
        const container = $('#rooms-container');
        container.empty();

        rooms.forEach((room, index) => {
            const roomHtml = `
                <div class="room p-4 border-b pb-5 border-gray-300 mt-4 w-[300px]" data-room-index="${index}">
                    <div class="flex justify-between items-center mb-3">
                        <h4 class="text-primary text-3xl font-medium">Room ${index + 1}</h4>
                        ${index > 0 ? '<button type="button" class="remove-room text-red hover:text-red">×</button>' : ''}
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div>
                            <label class="block text-md text-dark mb-2">Adults</label>
                            <div class="flex items-center space-x-2">
                                <button type="button" class="decrease-adults w-8 h-8 border border-4 border-secondary rounded flex items-center justify-center hover:bg-gray-100" ${room.adults <= 1 ? 'disabled' : ''}>-</button>
                                <span class="adults-count w-8 text-center">${room.adults}</span>
                                <button type="button" class="increase-adults w-8 h-8 border border-4 border-secondary rounded flex items-center justify-center hover:bg-gray-100" ${room.adults >= MAX_ADULTS_PER_ROOM ? 'disabled' : ''}>+</button>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-md text-dark mb-2">Children</label>
                            <div class="flex items-center space-x-2">
                                <button type="button" class="decrease-children w-8 h-8 border border-4 border-secondary rounded flex items-center justify-center hover:bg-gray-100" ${room.children <= 0 ? 'disabled' : ''}>-</button>
                                <span class="children-count w-8 text-center">${room.children}</span>
                                <button type="button" class="increase-children w-8 h-8 border border-4 border-secondary rounded flex items-center justify-center hover:bg-gray-100" ${room.children >= MAX_CHILDREN_PER_ROOM ? 'disabled' : ''}>+</button>
                            </div>
                        </div>
                    </div>
                    
                    ${room.children > 0 ? `
                        <div class="children-ages mt-3">
                            <div class="space-y-2 text-dark w-full">
                                ${Array.from({ length: room.children }, (_, i) => `
                                    <div class="flex items-center space-x-2">
                                        <span class="text-md w-20">Child ${i + 1} Age:</span>
                                        <select class="child-age border border-gray-300 rounded p-1 text-sm w-2/3">
                                            <option value=""></option>
                                            ${Array.from({ length: 18 }, (_, age) => `
                                                <option value="${age}" ${room.childrenAges[i] === age ? 'selected' : ''}>${age}</option>
                                            `).join('')}
                                        </select>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            `;
            container.append(roomHtml);
        });

        // Update button states
        $('#add-room').prop('disabled', rooms.length >= MAX_ROOMS);
        if (rooms.length >= MAX_ROOMS) {
            $('#add-room').addClass('opacity-50 cursor-not-allowed');
        } else {
            $('#add-room').removeClass('opacity-50 cursor-not-allowed');
        }
    }

    // Update guest summary
    function updateGuestSummary() {
        const totalAdults = rooms.reduce((sum, room) => sum + room.adults, 0);
        const totalChildren = rooms.reduce((sum, room) => sum + room.children, 0);
        const totalRooms = rooms.length;

        const summary = `${totalAdults} adult${totalAdults !== 1 ? 's' : ''}, ${totalChildren} child${totalChildren !== 1 ? 'ren' : ''}, ${totalRooms} room${totalRooms !== 1 ? 's' : ''}`;
        $('#guest-summary').text(summary);
        $('#guest-display').val(summary);

        // Store data in hidden field
        $('#guests-data').val(JSON.stringify(rooms));
    }

    // Add new room
    function addRoom() {
        if (rooms.length < MAX_ROOMS) {
            rooms.push({
                roomId: rooms.length + 1,
                adults: 2,
                children: 0,
                childrenAges: []
            });
            updateRoomsDisplay();
            updateGuestSummary();
        }
    }

    // Remove room
    function removeRoom(index) {
        if (rooms.length > 1) {
            rooms.splice(index, 1);
            updateRoomsDisplay();
            updateGuestSummary();
        }
    }

    // Event Handlers
    $('#guest-display').on('click', function () {
        $('#guest-modal').removeClass('hidden');
        initGuestModal();
    });

    $('#close-modal, #apply-guests').on('click', function () {
        // Validate children ages before closing
        let isValid = true;
        rooms.forEach((room, roomIndex) => {
            if (room.children > 0) {
                $(`.room[data-room-index="${roomIndex}"] .child-age`).each(function (index) {
                    if (!$(this).val()) {
                        isValid = false;
                        $(this).addClass('border-red-500');
                    } else {
                        $(this).removeClass('border-red-500');
                        room.childrenAges[index] = parseInt($(this).val());
                    }
                });
            }
        });

        if (isValid) {
            $('#guest-modal').addClass('hidden');
            $('#guest-error').addClass('hidden');
            updateGuestSummary();
        } else {
            alert('Please select ages for all children.');
        }
    });

    $(document).on('click', '#add-room', addRoom);

    $(document).on('click', '.remove-room', function () {
        const roomIndex = $(this).closest('.room').data('room-index');
        removeRoom(roomIndex);
    });

    $(document).on('click', '.increase-adults', function () {
        const roomIndex = $(this).closest('.room').data('room-index');
        if (rooms[roomIndex].adults < MAX_ADULTS_PER_ROOM) {
            rooms[roomIndex].adults++;
            updateRoomsDisplay();
            updateGuestSummary();
        }
    });

    $(document).on('click', '.decrease-adults', function () {
        const roomIndex = $(this).closest('.room').data('room-index');
        if (rooms[roomIndex].adults > 1) {
            rooms[roomIndex].adults--;
            updateRoomsDisplay();
            updateGuestSummary();
        }
    });

    $(document).on('click', '.increase-children', function () {
        const roomIndex = $(this).closest('.room').data('room-index');
        if (rooms[roomIndex].children < MAX_CHILDREN_PER_ROOM) {
            rooms[roomIndex].children++;
            rooms[roomIndex].childrenAges.push(0);
            updateRoomsDisplay();
            updateGuestSummary();
        }
    });

    $(document).on('click', '.decrease-children', function () {
        const roomIndex = $(this).closest('.room').data('room-index');
        if (rooms[roomIndex].children > 0) {
            rooms[roomIndex].children--;
            rooms[roomIndex].childrenAges.pop();
            updateRoomsDisplay();
            updateGuestSummary();
        }
    });

    // Submit form
    $("#hotel-search-form").on('submit', function (e) {
        e.preventDefault();

        // 2. prepare and redirect to booking engine
        const destinationValue = $("select[name='destination-value']").val();

        const splitDestination = destinationValue ? destinationValue.split('/') : [];
        const destinationType = splitDestination[0];
        const destinationId = splitDestination[1];
        const hotelSlug = splitDestination.length > 2 ? splitDestination[2] : '';
        console.log(destinationValue, splitDestination, hotelSlug);

        // Convert dates from mm/dd/yy to YYYY-MM-DD format
        const convertDate = (dateString) => {
            if (!dateString) return '';

            const parts = dateString.split('/');
            if (parts.length !== 3) return dateString;

            const month = parts[0].padStart(2, '0');
            const day = parts[1].padStart(2, '0');
            const year = '' + parts[2];

            return `${year}-${month}-${day}`;
        };

        // Prepare guests array
        const guests = rooms.map(room => {
            const guestRoom = {
                adults: room.adults,
                children: room.children > 0 ? room.childrenAges : []
            };
            return guestRoom;
        });

        // Prepare final search data
        const searchData = {
            check_in: convertDate($('#checkin').val()),
            check_out: convertDate($('#checkout').val()),
            residency: "gb",
            language: "en",
            guests: guests,
            search_type: destinationType,
            hotel_ids: destinationType === 'hotels' ? [destinationId] : [],
            region_id: destinationType === 'region' ? parseInt(destinationId) : undefined
        }

        const urlSearchParam = encodeURIComponent(JSON.stringify(searchData));
        let url = `/hotels?params=${urlSearchParam}`
        if (searchData.hotel_ids.length > 0 && hotelSlug) { // hotel redirect
            url = `/hotels/${hotelSlug}?params=${urlSearchParam}`
        }

        const bookingEngineUrl = server_data.booking_engine_url;
        url = bookingEngineUrl + url;

        // console.log(url);
        // console.log('Booking URL:', server_data.booking_engine_url);
        window.location.href = url;


        // console.log(JSON.stringify(searchData));
        // const urlSearch = encodeURIComponent(JSON.stringify(searchData));

        // const bookingEngineUrl = server_data.booking_engine_url;
        // const redirectUrl = `${bookingEngineUrl}?search=${urlSearch}`;
        // window.location.href = redirectUrl;

    });


    // Initialize
    updateGuestSummary();
});



/**
 * @package Tour Manager
 * @subpackage Search Widget : Tour Search JS
 * @since 1.0
 */
// jQuery(function ($) {
//     // console.log("Dropdown script loaded");

//     // Initialize dropdowns (set current country name)
//     function initializeDropdowns() {
//         const countryVal = $('#selected-country').val();
//         if (countryVal) {
//             const countryText = $('.country-menu .typeahead-option[data-value="' + countryVal + '"]').text();
//             $('.country-toggle').text(countryText);
//         }
//     }

//     initializeDropdowns();

//     //  Toggle dropdowns
//     $(document).on('click', '.dropdown-toggle', function (e) {
//         e.stopPropagation();

//         const menu = $(this).siblings('.dropdown-menu'); //  FIXED (was .next)
//         console.log("Toggling menu:", menu);

//         // Close other menus
//         $('.dropdown-menu').not(menu).slideUp(150).removeClass('active');

//         if (menu.is(':visible')) {
//             menu.slideUp(150).removeClass('active');
//         } else {
//             menu.css({
//                 position: 'absolute',
//                 display: 'none',
//                 zIndex: 99999
//             }).slideDown(150).addClass('active');
//         }
//     });

//     //  Close when clicking outside
//     $(document).on('click', function () {
//         $('.dropdown-menu').slideUp(150).removeClass('active');
//     });

//     //  Prevent closing when clicking inside
//     $(document).on('click', '.dropdown-menu', function (e) {
//         e.stopPropagation();
//     });

//     // //  Country option click
//     // $(document).on('click', '.country-menu .typeahead-option', function () {
//     //     const val = $(this).data('value');
//     //     const txt = $(this).text();
//     //     $('#selected-country').val(val);
//     //     $('.country-toggle').text(txt);
//     //     $('.country-menu').slideUp(150).removeClass('active');
//     // });

//     // //  Month select toggling
//     // $(document).on('click', '.month-option', function () {
//     //     $(this).toggleClass('selected bg-secondary text-white');
//     // });

//     // //  Apply months
//     // $(document).on('click', '.apply-months', function () {
//     //     const selected = [];
//     //     const selectedNames = [];
//     //     $('.month-option.selected').each(function () {
//     //         selected.push($(this).data('value'));
//     //         selectedNames.push($(this).text());
//     //     });

//     //     $('#selected-months').val(selected.join(','));
//     //     $('.month-toggle').text(selectedNames.join(', ') || 'Travel Month');
//     //     $('.month-menu').slideUp(150).removeClass('active');
//     // });

//     // //  Clear months
//     // $(document).on('click', '.clear-months', function () {
//     //     $('.month-option').removeClass('selected bg-secondary text-white');
//     //     $('#selected-months').val('');
//     //     $('.month-toggle').text('Travel Month');
//     //     $('.month-menu').slideUp(150).removeClass('active');
//     // });

//     // //category option click
//     // $(document).on('click', '.category-menu .typeahead-option', function () {
//     //     const val = $(this).data('value');
//     //     const txt = $(this).text();
//     //     $('#selected-category').val(val);
//     //     $('.category-toggle').text(txt);
//     //     $('.category-menu').slideUp(150).removeClass('active');
//     // });


//     // Country option click
//     $(document).on('click', '.country-menu .typeahead-option', function () {
//         const val = $(this).data('value');
//         const txt = $(this).text();
//         $('#selected-country').val(val);
//         $(this).closest('.dropdown-container').find('.dropdown-toggle').text(txt);
//         $('.country-menu').slideUp(150).removeClass('active');
//     });

//     // Month apply
//     $(document).on('click', '.apply-months', function () {
//         const selected = [];
//         const selectedNames = [];
//         $('.month-option.selected').each(function () {
//             selected.push($(this).data('value'));
//             selectedNames.push($(this).text());
//         });

//         $('#selected-months').val(selected.join(','));
//         $(this).closest('.dropdown-container').find('.dropdown-toggle').text(selectedNames.join(', ') || 'Travel Month');
//         $('.month-menu').slideUp(150).removeClass('active');
//     });

//     // Clear months
//     $(document).on('click', '.clear-months', function () {
//         $('.month-option').removeClass('selected bg-secondary text-white');
//         $('#selected-months').val('');
//         $(this).closest('.dropdown-container').find('.dropdown-toggle').text('Travel Month');
//         $('.month-menu').slideUp(150).removeClass('active');
//     });

//     // Category option click
//     $(document).on('click', '.category-menu .typeahead-option', function () {
//         const val = $(this).data('value');
//         const txt = $(this).text();
//         $('#selected-category').val(val);
//         $(this).closest('.dropdown-container').find('.dropdown-toggle').text(txt);
//         $('.category-menu').slideUp(150).removeClass('active');
//     });

// });