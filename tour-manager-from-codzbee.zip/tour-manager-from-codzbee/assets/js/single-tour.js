/**
 * FAQs
 * @param {*} id 
 */
function toggleFaq(id) {
    const answer = document.getElementById(id);
    const icon = answer.previousElementSibling.querySelector('i');

    if (answer.classList.contains('hidden')) {
        // Hide all other answers (optional)
        document.querySelectorAll('.faq-answer').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.faq-answer').forEach(el => {
            const i = el.previousElementSibling.querySelector('i');
            if (i) {
                i.classList.remove('fa-minus');
                i.classList.add('fa-plus');
            }
        });

        // Show selected answer
        answer.classList.remove('hidden');
        icon.classList.remove('fa-plus');
        icon.classList.add('fa-minus');
    } else {
        // Hide selected answer
        answer.classList.add('hidden');
        icon.classList.remove('fa-minus');
        icon.classList.add('fa-plus');
    }
}


/**
 * flatpickr
 */
// document.addEventListener('DOMContentLoaded', function () {
//     flatpickr("#check-in-date", {
//         minDate: new Date().fp_incr(1), // disables today and all previous days
//         dateFormat: "Y-m-d",
//         allowInput: true
//     });
// });



/**
 * Activity, Attraction carousel
 * @param {*} id 
 */
document.addEventListener('DOMContentLoaded', function () {
    new Swiper('#activity-attraction-carousel', {
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        slidesPerView: 1,
        spaceBetween: 20,
        breakpoints: {
            640: {
                slidesPerView: 2,
            },
            768: {
                slidesPerView: 3,
            },
            1024: {
                slidesPerView: 5,
            },
        },
    });
});


/**
 * Day Desacription : Word limit
 */
function toggleDescription(dayIndex) {
    const shortEl = document.getElementById('description-' + dayIndex + '-short');
    const fullEl = document.getElementById('description-' + dayIndex + '-full');
    const btn = event.target;

    if (shortEl.classList.contains('hidden')) {
        shortEl.classList.remove('hidden');
        fullEl.classList.add('hidden');
        btn.textContent = 'See More';
    } else {
        shortEl.classList.add('hidden');
        fullEl.classList.remove('hidden');
        btn.textContent = 'See Less';
    }
}


/**
 * Day : Carousel
 */
document.addEventListener('DOMContentLoaded', function () {
    // Initialize all carousels
    document.querySelectorAll('.location-carousel').forEach(initCarousel);

    function initCarousel(carouselContainer) {
        const track = carouselContainer.querySelector('.carousel-track');
        const slides = carouselContainer.querySelectorAll('.carousel-slide');
        const prevBtn = carouselContainer.querySelector('.carousel-prev');
        const nextBtn = carouselContainer.querySelector('.carousel-next');
        const indicators = carouselContainer.querySelectorAll('.carousel-indicator');

        let currentSlide = 0;
        const slidesPerView = window.innerWidth >= 768 ? 2 : 1;
        const totalSlides = slides.length;
        const totalGroups = Math.ceil(totalSlides / slidesPerView);

        // Auto-play configuration
        let autoplayInterval = setInterval(nextSlide, 3000);

        function updateCarousel() {
            track.style.transform = `translateX(-${currentSlide * (100 / slidesPerView)}%)`;

            // Update indicators
            indicators.forEach((indicator, index) => {
                indicator.classList.toggle('active', index === currentSlide);
            });

            // Reset autoplay timer
            resetAutoplay();
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % totalGroups;
            updateCarousel();
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + totalGroups) % totalGroups;
            updateCarousel();
        }

        function goToSlide(index) {
            currentSlide = index;
            updateCarousel();
        }

        function resetAutoplay() {
            clearInterval(autoplayInterval);
            autoplayInterval = setInterval(nextSlide, 3000);
        }

        // Handle window resize
        function handleResize() {
            const newSlidesPerView = window.innerWidth >= 768 ? 2 : 1;
            if (newSlidesPerView !== slidesPerView) {
                currentSlide = 0;
                updateCarousel();
            }
        }

        // Event listeners
        if (nextBtn) nextBtn.addEventListener('click', nextSlide);
        if (prevBtn) prevBtn.addEventListener('click', prevSlide);

        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => goToSlide(index));
        });

        // Pause autoplay on hover
        carouselContainer.addEventListener('mouseenter', () => {
            clearInterval(autoplayInterval);
        });

        carouselContainer.addEventListener('mouseleave', () => {
            resetAutoplay();
        });

        // Window resize handler
        window.addEventListener('resize', handleResize);

        // Touch/swipe support for mobile
        let startX = 0;
        let endX = 0;

        carouselContainer.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        });

        carouselContainer.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            handleSwipe();
        });

        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = startX - endX;

            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextSlide();
                } else {
                    prevSlide();
                }
            }
        }

        // Initialize carousel
        updateCarousel();
    }

    // Accordion functionality - Remove 'hidden' class from accordion content by default
    document.querySelectorAll('.accordion-content').forEach(content => {
        content.classList.remove('hidden');
    });

    document.querySelectorAll('.accordion-header').forEach(header => {
        const icon = header.querySelector('i');
        icon.classList.add('rotate-180'); // Start with down arrow rotated (pointing up)

        header.addEventListener('click', () => {
            const content = header.nextElementSibling;
            const icon = header.querySelector('i');

            // Toggle hidden class
            content.classList.toggle('hidden');

            // Rotate icon
            icon.classList.toggle('rotate-180');

            // Stop all carousels when accordion closes
            if (content.classList.contains('hidden')) {
                const carousels = content.querySelectorAll('.location-carousel');
                carousels.forEach(carousel => {
                    // You might want to add pause functionality here
                    console.log('Pause carousel for accordion close');
                });
            }
        });
    });
});


/**
 * What's Included : Accordion
 * What's Not Included : Accordion
 */
function toggleAccordion(id) {
    const content = document.getElementById(id);
    const icon = document.getElementById('icon-' + id);
    const button = content.previousElementSibling;

    // Toggle content visibility
    content.classList.toggle('hidden');

    // Toggle icon rotation
    icon.classList.toggle('rotate-180');

    // Toggle aria-expanded attribute
    const isExpanded = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', !isExpanded);
}

// Optional: Add keyboard accessibility
document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') {
        const accordionButton = e.target.closest('.accordion-button');
        if (accordionButton && accordionButton.hasAttribute('onclick')) {
            e.preventDefault();
            accordionButton.click();
        }
    }
});

/**
 * Cancellation policy
 */
// Get DOM elements
const openModalButton = document.getElementById('cancellation-policy');
const closeModalButton = document.getElementById('close-modal');
const acceptPolicyButton = document.getElementById('accept-policy');
const modalOverlay = document.getElementById('modal-overlay');

// Open modal function
function openModal() {
    modalOverlay.classList.remove('hidden');
    // Prevent body scrolling when modal is open
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
        modalOverlay.classList.add('modal-open');
    }, 10);
}

// Close modal function
function closeModal() {
    modalOverlay.classList.remove('modal-open');
    // Restore body scrolling
    document.body.style.overflow = 'auto';
    setTimeout(() => {
        modalOverlay.classList.add('hidden');
    }, 300);
}

// Event listeners
openModalButton.addEventListener('click', openModal);
closeModalButton.addEventListener('click', closeModal);
acceptPolicyButton.addEventListener('click', closeModal);

// Close modal when clicking outside the content
modalOverlay.addEventListener('click', function (e) {
    if (e.target === modalOverlay) {
        closeModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !modalOverlay.classList.contains('hidden')) {
        closeModal();
    }
});



// // 
// document.addEventListener('DOMContentLoaded', function () {
//     // Get elements
//     const adultInput = document.getElementById('adults');
//     const childInput = document.getElementById('children');
//     const decrementAdultBtn = document.querySelector('.decrement-adult');
//     const incrementAdultBtn = document.querySelector('.increment-adult');
//     const decrementChildBtn = document.querySelector('.decrement-child');
//     const incrementChildBtn = document.querySelector('.increment-child');

//     // Get min and max values from data attributes
//     const adultMin = parseInt(adultInput.getAttribute('data-min')) || 1;
//     const adultMax = parseInt(adultInput.getAttribute('data-max')) || 10;
//     const childMin = parseInt(childInput.getAttribute('data-min')) || 0;
//     const childMax = parseInt(childInput.getAttribute('data-max')) || 10;

//     // Initialize values
//     let adultCount = parseInt(adultInput.value) || adultMin;
//     let childCount = parseInt(childInput.value) || childMin;

//     // Update button states
//     function updateButtonStates() {
//         // Adult buttons
//         decrementAdultBtn.disabled = adultCount <= adultMin;
//         incrementAdultBtn.disabled = adultCount >= adultMax;

//         // Child buttons
//         decrementChildBtn.disabled = childCount <= childMin;
//         incrementChildBtn.disabled = childCount >= childMax;

//         // Visual feedback for disabled buttons
//         if (decrementAdultBtn.disabled) {
//             decrementAdultBtn.classList.add('opacity-50', 'cursor-not-allowed');
//             decrementAdultBtn.classList.remove('hover:bg-secondary', 'hover:text-white');
//         } else {
//             decrementAdultBtn.classList.remove('opacity-50', 'cursor-not-allowed');
//             decrementAdultBtn.classList.add('hover:bg-secondary', 'hover:text-white');
//         }

//         if (incrementAdultBtn.disabled) {
//             incrementAdultBtn.classList.add('opacity-50', 'cursor-not-allowed');
//             incrementAdultBtn.classList.remove('hover:bg-secondary', 'hover:text-white');
//         } else {
//             incrementAdultBtn.classList.remove('opacity-50', 'cursor-not-allowed');
//             incrementAdultBtn.classList.add('hover:bg-secondary', 'hover:text-white');
//         }

//         if (decrementChildBtn.disabled) {
//             decrementChildBtn.classList.add('opacity-50', 'cursor-not-allowed');
//             decrementChildBtn.classList.remove('hover:bg-secondary', 'hover:text-white');
//         } else {
//             decrementChildBtn.classList.remove('opacity-50', 'cursor-not-allowed');
//             decrementChildBtn.classList.add('hover:bg-secondary', 'hover:text-white');
//         }

//         if (incrementChildBtn.disabled) {
//             incrementChildBtn.classList.add('opacity-50', 'cursor-not-allowed');
//             incrementChildBtn.classList.remove('hover:bg-secondary', 'hover:text-white');
//         } else {
//             incrementChildBtn.classList.remove('opacity-50', 'cursor-not-allowed');
//             incrementChildBtn.classList.add('hover:bg-secondary', 'hover:text-white');
//         }
//     }

//     // Adult increment function
//     function incrementAdult() {
//         if (adultCount < adultMax) {
//             adultCount++;
//             adultInput.value = adultCount;
//             updateButtonStates();
//         }
//     }

//     // Adult decrement function
//     function decrementAdult() {
//         if (adultCount > adultMin) {
//             adultCount--;
//             adultInput.value = adultCount;
//             updateButtonStates();
//         }
//     }

//     // Child increment function
//     function incrementChild() {
//         if (childCount < childMax) {
//             childCount++;
//             childInput.value = childCount;
//             updateButtonStates();
//         }
//     }

//     // Child decrement function
//     function decrementChild() {
//         if (childCount > childMin) {
//             childCount--;
//             childInput.value = childCount;
//             updateButtonStates();
//         }
//     }

//     // Event listeners
//     incrementAdultBtn.addEventListener('click', incrementAdult);
//     decrementAdultBtn.addEventListener('click', decrementAdult);
//     incrementChildBtn.addEventListener('click', incrementChild);
//     decrementChildBtn.addEventListener('click', decrementChild);

//     // Initialize button states
//     updateButtonStates();
// });


// document.addEventListener('DOMContentLoaded', function () {
//     console.log('DOM loaded - initializing passenger counters');

//     // Get elements with more specific selectors
//     const adultInput = document.getElementById('adults');
//     const childInput = document.getElementById('children');
//     const decrementAdultBtn = document.querySelector('.decrement-adult');
//     const incrementAdultBtn = document.querySelector('.increment-adult');
//     const decrementChildBtn = document.querySelector('.decrement-child');
//     const incrementChildBtn = document.querySelector('.increment-child');

//     // Debug log
//     console.log('Elements found:', {
//         adultInput,
//         childInput,
//         decrementAdultBtn,
//         incrementAdultBtn,
//         decrementChildBtn,
//         incrementChildBtn
//     });

//     // Get min and max values from data attributes with fallbacks
//     const adultMin = parseInt(adultInput.getAttribute('data-min')) || 1;
//     const adultMax = parseInt(adultInput.getAttribute('data-max')) || 10;
//     const childMin = parseInt(childInput.getAttribute('data-min')) || 0;
//     const childMax = parseInt(childInput.getAttribute('data-max')) || 10;

//     console.log('Limits:', { adultMin, adultMax, childMin, childMax });

//     // Initialize values
//     let adultCount = parseInt(adultInput.value) || adultMin;
//     let childCount = parseInt(childInput.value) || childMin;

//     console.log('Initial counts:', { adultCount, childCount });

//     // Update button states
//     function updateButtonStates() {
//         console.log('Updating button states', { adultCount, childCount });

//         // Adult buttons
//         decrementAdultBtn.disabled = adultCount <= adultMin;
//         incrementAdultBtn.disabled = adultCount >= adultMax;

//         // Child buttons
//         decrementChildBtn.disabled = childCount <= childMin;
//         incrementChildBtn.disabled = childCount >= childMax;

//         // Visual feedback for disabled buttons
//         [decrementAdultBtn, incrementAdultBtn, decrementChildBtn, incrementChildBtn].forEach(btn => {
//             if (btn.disabled) {
//                 btn.classList.add('opacity-50', 'cursor-not-allowed');
//                 btn.classList.remove('hover:bg-secondary', 'hover:text-white');
//             } else {
//                 btn.classList.remove('opacity-50', 'cursor-not-allowed');
//                 btn.classList.add('hover:bg-secondary', 'hover:text-white');
//             }
//         });
//     }

//     // Adult increment function
//     function incrementAdult() {
//         console.log('Increment adult clicked');
//         if (adultCount < adultMax) {
//             adultCount++;
//             adultInput.value = adultCount;
//             console.log('Adult count increased to:', adultCount);
//             updateButtonStates();
//         }
//     }

//     // Adult decrement function
//     function decrementAdult() {
//         console.log('Decrement adult clicked');
//         if (adultCount > adultMin) {
//             adultCount--;
//             adultInput.value = adultCount;
//             console.log('Adult count decreased to:', adultCount);
//             updateButtonStates();
//         }
//     }

//     // Child increment function
//     function incrementChild() {
//         console.log('Increment child clicked');
//         if (childCount < childMax) {
//             childCount++;
//             childInput.value = childCount;
//             console.log('Child count increased to:', childCount);
//             updateButtonStates();
//         }
//     }

//     // Child decrement function
//     function decrementChild() {
//         console.log('Decrement child clicked');
//         if (childCount > childMin) {
//             childCount--;
//             childInput.value = childCount;
//             console.log('Child count decreased to:', childCount);
//             updateButtonStates();
//         }
//     }

//     // Add event listeners with error handling
//     try {
//         incrementAdultBtn.addEventListener('click', incrementAdult);
//         decrementAdultBtn.addEventListener('click', decrementAdult);
//         incrementChildBtn.addEventListener('click', incrementChild);
//         decrementChildBtn.addEventListener('click', decrementChild);
//         console.log('Event listeners added successfully');
//     } catch (error) {
//         console.error('Error adding event listeners:', error);
//     }

//     // Initialize button states
//     updateButtonStates();
// });
