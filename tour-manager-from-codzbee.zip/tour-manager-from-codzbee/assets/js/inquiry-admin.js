jQuery(document).ready(function ($) {
    // var isModalOpen = true;

    /** Status change handler */
    $('.inquiry-status, .booking-status').on('focus', function () {
        $(this).data('previous-value', $(this).val());
    })
    .change(function () {
        var status = $(this).val();

        /** Only show modal for Confirmed/Cancelled statuses */
        if (status === 'Confirmed' || status === 'Cancelled') {
            handleStatusChange($(this));
        } else {
            /** For other statuses, just save without modal */
            saveStatusOnly($(this));
        }
    });

    function saveStatusOnly(select) {
        var postID = select.data('post-id');
        var status = select.val();
        var previousValue = select.data('previous-value');
        var loader = select.siblings('.status-loader');

        $.ajax({
            type: 'POST',
            url: tourInquiryAdminData.ajax_url,
            data: {
                action: 'save_inquiry_status',
                post_id: postID,
                status: status,
                security: tourInquiryAdminData.nonce
            },
            beforeSend: function () {
                loader.show();
            },
            success: function (response) {
                loader.hide();
                if (!response.success) {
                    select.val(previousValue);
                    alert("Error: " + (response.data?.message || 'Update failed.'));
                }
            },
            error: function (xhr) {
                loader.hide();
                select.val(previousValue);
                alert("Request failed: " + xhr.statusText);
            }
        });
    }

    function handleStatusChange(select) {
        // console.log('Status change triggered');
        var postID = select.data('post-id');
        var status = select.val();
        var previousValue = select.data('previous-value');
        var loader = select.siblings('.status-loader');
        var isBooking = select.hasClass('booking-status');
        var type = isBooking ? 'booking' : 'inquiry';

        /** First save the status */
        $.ajax({
            type: 'POST',
            url: tourInquiryAdminData.ajax_url,
            data: {
                action: 'save_inquiry_status',
                post_id: postID,
                status: status,
                security: tourInquiryAdminData.nonce
            },
            beforeSend: function () {
                loader.show();
            },
            success: function (response) {
                if (response.success) {
                    /** Then get details to show in modal */
                    $.ajax({
                        type: 'POST',
                        url: tourInquiryAdminData.ajax_url,
                        data: {
                            action: 'get_inquiry_details',
                            post_id: postID,
                            security: tourInquiryAdminData.nonce
                        },
                        success: function (detailsResponse) {
                            // console.log('Details response:', detailsResponse);
                            loader.hide();
                            if (detailsResponse.success) {
                                showStatusChangeModal(detailsResponse.data, status, type);
                            } else {
                                // console.error('Error fetching details:', detailsResponse.data);
                                alert('Status updated successfully!');
                            }
                        },
                        error: function () {
                            // console.error('Error fetching details');
                            loader.hide();
                            alert('Status updated but could not load details.');
                        }
                    });
                } else {
                    loader.hide();
                    select.val(previousValue);
                    alert("Error: " + (response.data?.message || 'Update failed.'));
                }
            },
            error: function (xhr) {
                loader.hide();
                select.val(previousValue);
                alert("Request failed: " + xhr.statusText);
            }
        });
    }
        










    // // Variables
    // var currentPostId = 0;
    // var modal = $('#details-modal');
    // var modalContent = $('.details-modal-content');
    // var postType = '';
    // var isLoading = false;

    // // Open modal handler
    // $(document).on('click', '.view-details', function(e) {
    //     console.log('View details clicked');
    //     e.preventDefault();
        
    //     if (isLoading) return;
        
    //     currentPostId = $(this).data('id');
    //     postType = $(this).data('type');
        
    //     showLoadingState();
    //     fetchInquiryDetails(currentPostId);
    // });

    // // Close modal handlers
    // $(document).on('click', '.close-modal', closeModal);
    // modal.on('click', function(e) {
    //     if ($(e.target).is(modal)) {
    //         closeModal();
    //     }
    // });

    // // Update status handler
    // $('#update-status').on('click', updateInquiryStatus);

    // // Prevent modal content from closing when clicking inside
    // modalContent.on('click', function(e) {
    //     console.log('Modal content clicked');           
    //     e.stopPropagation();
    // });

    // // Fetch inquiry details via AJAX
    // function fetchInquiryDetails(postId) {
    //     $.ajax({
    //         url: tourInquiryAdminData.ajax_url,
    //         type: 'POST',
    //         data: {
    //             action: 'get_inquiry_details',
    //             post_id: postId,
    //             security: tourInquiryAdminData.nonce
    //         },
    //         beforeSend: function() {
    //             isLoading = true;
    //         },
    //         success: function(response) {
    //             if (response.success) {
    //                 populateModal(response.data);
    //                 // console.log('Modal data:', response.data);
    //                 showModal();
    //             } else {
    //                 showError(tourInquiryAdminData.i18n.error);
    //                 // console.error('Error fetching details:', response.data);
    //             }
    //         },
    //         error: function() {
    //             showError(tourInquiryAdminData.i18n.error);
    //         },
    //         complete: function() {
    //             isLoading = false;
    //         }
    //     });
    // }

    // // Populate modal with data
    // function populateModal(data) {
    //     // Clear previous data
    //     $('#modal-title, #modal-message').empty();
    //     $('#customer-details, #booking-details').empty();

    //     // Set header info
    //     $('#modal-title').text(data.header.title || 'Inquiry Details');
    //     $('#modal-status')
    //         .text(data.header.status)
    //         .removeClass()
    //         .addClass('status-badge ' + (data.header.status ? data.header.status.toLowerCase() : 'pending'));
    //     $('#modal-date').text(data.header.date || '');
    //     $('#modal-edit-link').attr('href', data.header.edit_link || '#');

    //     // Set customer details
    //     var customerHtml = '<div class="inquiry-detail">';
    //     if (data.customer) {
    //         customerHtml += data.customer.name ? '<p><strong>Name:</strong> ' + data.customer.name + '</p>' : '';
    //         customerHtml += data.customer.email ? '<p><strong>Email:</strong> ' + data.customer.email + '</p>' : '';
    //         customerHtml += data.customer.phone ? '<p><strong>Phone:</strong> ' + data.customer.phone + '</p>' : '';
    //     }
    //     customerHtml += '</div>';
    //     $('#customer-details').append(customerHtml);

    //     // Set booking details
    //     var bookingHtml = '<div class="inquiry-detail">';
    //     if (data.booking) {
    //         bookingHtml += data.booking.tour ? '<p><strong>Tour:</strong> ' + data.booking.tour + '</p>' : '';
    //         bookingHtml += data.booking.date ? '<p><strong>Date:</strong> ' + data.booking.date + '</p>' : '';
    //         bookingHtml += data.booking.adults ? '<p><strong>Adults:</strong> ' + data.booking.adults + '</p>' : '';
    //         bookingHtml += data.booking.children ? '<p><strong>Children:</strong> ' + data.booking.children + '</p>' : '';
    //     }
    //     bookingHtml += '</div>';
    //     $('#booking-details').append(bookingHtml);

    //     // Set message
    //     $('#modal-message').text(data.message || 'No message provided');

    //     // Set current status
    //     $('#status-selector').val(data.header.status || 'Pending');
    // }

    // // Update inquiry status
    // function updateInquiryStatus() {
    //     var newStatus = $('#status-selector').val();
        
    //     if (!currentPostId || !newStatus) {
    //         showError('Invalid data');
    //         return;
    //     }

    //     showLoadingState(true, tourInquiryAdminData.i18n.updating);
        
    //     $.ajax({
    //         url: tourInquiryAdminData.ajax_url,
    //         type: 'POST',
    //         data: {
    //             action: 'update_inquiry_status',
    //             post_id: currentPostId,
    //             status: newStatus,
    //             security: tourInquiryAdminData.nonce
    //         },
    //         success: function(response) {
    //             if (response.success) {
    //                 // Update status display
    //                 $('#modal-status')
    //                     .text(newStatus)
    //                     .removeClass()
    //                     .addClass('status-badge ' + newStatus.toLowerCase());
                    
    //                 showSuccess(response.data.message || tourInquiryAdminData.i18n.success);
    //             } else {
    //                 showError(response.data.message || tourInquiryAdminData.i18n.error);
    //             }
    //         },
    //         error: function() {
    //             showError(tourInquiryAdminData.i18n.error);
    //         },
    //         complete: function() {
    //             hideLoadingState();
    //         }
    //     });
    // }

    // // Show modal
    // function showModal() {
    //     modal.fadeIn(200);
    //     $('body').addClass('modal-open');
    // }

    // // Close modal
    // function closeModal() {
    //     modal.fadeOut(200);
    //     $('body').removeClass('modal-open');
    // }

    // // Show loading state
    // function showLoadingState(showInButton, text) {
    //     if (showInButton) {
    //         var button = $('#update-status');
    //         button.data('original-text', button.text());
    //         button.prop('disabled', true);
    //         button.text(text || 'Loading...');
    //     } else {
    //         modalContent.addClass('loading');
    //     }
    // }

    // // Hide loading state
    // function hideLoadingState() {
    //     var button = $('#update-status');
    //     if (button.data('original-text')) {
    //         button.text(button.data('original-text'));
    //         button.prop('disabled', false);
    //     }
    //     modalContent.removeClass('loading');
    // }

    // // Show success message
    // function showSuccess(message) {
    //     var alert = $('<div class="inquiry-alert success">' + message + '</div>');
    //     $('.modal-footer').prepend(alert);
    //     setTimeout(function() {
    //         alert.fadeOut(500, function() {
    //             $(this).remove();
    //         });
    //     }, 3000);
    // }

    // // Show error message
    // function showError(message) {
    //     var alert = $('<div class="inquiry-alert error">' + message + '</div>');
    //     $('.modal-footer').prepend(alert);
    //     setTimeout(function() {
    //         alert.fadeOut(500, function() {
    //             $(this).remove();
    //         });
    //     }, 3000);
    // }

    // // Close on ESC key
    // $(document).keyup(function(e) {
    //     if (e.key === "Escape" && modal.is(':visible')) {
    //         closeModal();
    //     }
    // });
});






