/**
 * Calls the CoreBookingEngineApi.
 */
async function callCoreBookingEngineApi(method, coreApiPath, body = {}, queryParams = {}) {
    try {
        const queryString = new URLSearchParams({
            action: 'tm_booking_engine_request',
            ...queryParams
        }).toString();

        const response = await $.ajax({
            url: `${server_data.ajax_url}?${queryString}`,
            method: method.toUpperCase(),
            headers: {
                'core-api-url': coreApiPath,
            },
            data: method.toUpperCase() === 'GET' ? null : JSON.stringify(body),
            contentType: 'application/json',
            dataType: 'json'
        });

        return response;
    } catch (error) {
        console.error('API call failed:', error);
        return null;
    }
}