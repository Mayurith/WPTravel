// jQuery(document).ready(function ($) {
//     $(document).on('click', '.view-post', function (e) {
//         e.preventDefault();
//         e.stopPropagation();

//         var inquiryId = $(this).data('post-id');
//         var modal = $('#inquiry-preview-modal');
//         var content = $('#inquiry-preview-content');

//         content.html('<div class="loading-spinner"></div><p>Loading inquiry details...</p>');

//         modal.css({
//             'display': 'block',
//             'opacity': 0
//         }).animate({opacity: 1}, 200);

//         $('.modal-overlay').css({
//             'display': 'block',
//             'opacity': 0
//         }).animate({opacity: 1}, 200);

//         isModalOpen = true;

//         $.ajax({
//             type: 'POST',
//             url: tourInquiryAdminData.ajax_url,
//             data: {
//                 action: 'get_inquiry_details',
//                 post_id: inquiryId,
//                 security: tourInquiryAdminData.get_nonce,
//                 detailed: true
//             },

//             success: function (response) {
//                 if (response.success) {
//                     var html = '<div class="inquiry-detail">';
//                     html += '<P><strong>Name:   </strong>' + response.data.name + '</P>';
//                     html += '<p><strong>Email:  </strong>' + response.data.email + '</p>';
//                     html += '<p><strong>Phone:  </strong>' + response.data.phone + '</p>';
//                     html += '<p><strong>Tour Category:  </strong>' + response.data.tour_category + '</p>';
//                     html += '<p><strong>Guests: </strong>' + response.data.adult_count + ' Adults ' + response.data.child_count + ' Children</p>';
//                     html += '<p><strong>Status: </strong>' + response.data.status + '</p>';
//                     html += '<p><strong>Date:   </strong>' + response.data.date + '</p>';

//                     if (response.data.message) {
//                         html += '<div class="inquiry-message">';
//                         html += '<strong>Additional Message:</strong><br>' + response.data.message;
//                         html += '</div>';
//                     }

//                     html += '</div>';
//                     content.html(html);
//                 } else {
//                     content.html('<p class="error"> Error loading inquiry details. </p>');
//                 }
//             },
//             error: function () {
//                 content.html('<P class="error"> Error loading inquiry details. </P>');
//             }
//         });
//     });


//     $(document).on('click', '#close-preview, .modal-overlay', function (e) {
//         e.preventDefault();
//         e.stopPropagation();

//         if (!isModalOpen) return;

//         $('#inquiry-preview-modal').animate({opacity: 0}, 200, function () {
//             $(this).css('display', 'none');
//         });

//         $('.modal-overlay').animate({opacity: 0}, 200, function () {
//             $(this).css('display', 'none');
//         });

//         isModalOpen = false;
//     });


// });
// /******************************************************************************************** */

// // jQuery(document).ready(function ($) {
// //     $(document).on('click', '.view-post', function (e) {
// //         e.preventDefault();
// //         e.stopPropagation();

// //         var inquiryId = $(this).data('post-id');
// //         var post_id = $(this).data('id');

// //         isModalOpen = true;

// //         $.ajax({
// //              type: 'POST',
// //             url: tourInquiryAdminData.ajax_url,
// //             data: {
// //                 action: 'get_inquiry_details',
// //                 post_id: inquiryId,
// //                 security: tourInquiryAdminData.get_nonce,
// //                 detailed: true
// //             },
// //             success: function (response) {
// //                 if (response.success) {
// //                     displayInquiryModal(response.data);
// //                 } else {
// //                     alert('Error loading details');
// //                 }
// //             }
// //         });
// //     });

// //     function displayInquiryModal(data) {
// //         // Create modal HTML based on the data structure
// //         var modalHTML = `
// //         <div class="inquiry-modal">
// //             <div class="modal-header">
// //                 <h2>${data.header.title}</h2>
// //                 <span class="status-badge ${data.header.status.toLowerCase()}">${data.header.status}</span>
// //                 <span class="date">${data.header.date}</span>
// //                 <a href="${data.header.edit_link}" class="edit-link">Edit</a>
// //             </div>
            
// //             <div class="modal-columns">
// //                 <div class="column">
// //                     <h3>Customer Details</h3>
// //                     <p><strong>Name:</strong> ${data.customer.name}</p>
// //                     <p><strong>Email:</strong> ${data.customer.email}</p>
// //                     <p><strong>Phone:</strong> ${data.customer.phone}</p>
// //                     ${data.customer.address ? `<p><strong>Address:</strong> ${data.customer.address}</p>` : ''}
// //                 </div>
                
// //                 <div class="column">
// //                     <h3>Tour Details</h3>
// //                     <p><strong>Tour:</strong> ${data.tour.title}</p>
// //                     <p><strong>Date:</strong> ${data.tour.date}</p>
// //                     <p><strong>Adults:</strong> ${data.tour.adults}</p>
// //                     <p><strong>Children:</strong> ${data.tour.children}</p>
// //                 </div>
// //             </div>
            
// //             <div class="message-section">
// //                 <h3>Message</h3>
// //                 <p>${data.details.message || 'No message provided'}</p>
// //             </div>
            
// //             <div class="modal-footer">
// //                 <select class="status-selector">
// //                     ${data.actions.status_options.map(option =>
// //             `<option value="${option}" ${option === data.actions.current_status ? 'selected' : ''}>${option}</option>`
// //         ).join('')}
// //                 </select>
// //                 <button class="button update-status">Update Status</button>
// //                 <button class="button send-email">Send Email</button>
// //             </div>
// //         </div>
// //         `;

// //         // Show the modal (you might use a library or custom implementation)
// //         showModal(modalHTML);
// //     }
// // });

// /********************************************************************************************* */
// // jQuery(document).ready(function($) {
// //     // Create modal container if it doesn't exist
// //     if (!$('#inquiry-modal-container').length) {
// //         $('body').append('<div id="inquiry-modal-container" class="inquiry-modal-overlay" style="display:none;"><div class="inquiry-modal-content"></div></div>');
// //     }

// //     $(document).on('click', '.view-inquiry-details', function(e) {
// //         e.preventDefault();
// //         var post_id = $(this).data('id');
        
// //         $.ajax({
// //             url: ajaxurl,
// //             type: 'POST',
// //             data: {
// //                 action: 'get_inquiry_details',
// //                 post_id: post_id,
// //                 security: ajax_nonce
// //             },
// //             beforeSend: function() {
// //                 // Show loading spinner
// //                 $('#inquiry-modal-container .inquiry-modal-content').html('<div class="loading-spinner"></div>');
// //                 $('#inquiry-modal-container').fadeIn();
// //             },
// //             success: function(response) {
// //                 if (response.success) {
// //                     displayInquiryModal(response.data);
// //                 } else {
// //                     alert('Error loading details');
// //                     $('#inquiry-modal-container').fadeOut();
// //                 }
// //             },
// //             error: function() {
// //                 alert('Error loading details');
// //                 $('#inquiry-modal-container').fadeOut();
// //             }
// //         });
// //     });

// //     // Close modal when clicking overlay or close button
// //     $(document).on('click', '.inquiry-modal-overlay', function(e) {
// //         if ($(e.target).hasClass('inquiry-modal-overlay')) {
// //             $(this).fadeOut();
// //         }
// //     });

// //     function displayInquiryModal(data) {
// //         var modalHTML = `
// //         <div class="inquiry-modal">
// //             <button class="close-modal">&times;</button>
// //             <div class="modal-header">
// //                 <h2>${data.header.title}</h2>
// //                 <span class="status-badge ${data.header.status.toLowerCase()}">${data.header.status}</span>
// //                 <span class="date">${data.header.date}</span>
// //                 <a href="${data.header.edit_link}" class="edit-link">Edit</a>
// //             </div>
            
// //             <div class="modal-columns">
// //                 <div class="column">
// //                     <h3>Customer Details</h3>
// //                     <p><strong>Name:</strong> ${data.customer.name}</p>
// //                     <p><strong>Email:</strong> ${data.customer.email}</p>
// //                     <p><strong>Phone:</strong> ${data.customer.phone}</p>
// //                     ${data.customer.address ? `<p><strong>Address:</strong> ${data.customer.address}</p>` : ''}
// //                 </div>
                
// //                 <div class="column">
// //                     <h3>Tour Details</h3>
// //                     <p><strong>Tour:</strong> ${data.tour.title}</p>
// //                     <p><strong>Date:</strong> ${data.tour.date}</p>
// //                     <p><strong>Adults:</strong> ${data.tour.adults}</p>
// //                     <p><strong>Children:</strong> ${data.tour.children}</p>
// //                 </div>
// //             </div>
            
// //             <div class="message-section">
// //                 <h3>Message</h3>
// //                 <p>${data.details.message || 'No message provided'}</p>
// //             </div>
            
// //             <div class="modal-footer">
// //                 <select class="status-selector">
// //                     ${data.actions.status_options.map(option => 
// //                         `<option value="${option}" ${option === data.actions.current_status ? 'selected' : ''}>${option}</option>`
// //                     ).join('')}
// //                 </select>
// //                 <button class="button button-primary update-status">Update Status</button>
// //                 <button class="button send-email">Send Email</button>
// //             </div>
// //         </div>
// //         `;
        
// //         // Insert the modal content
// //         $('#inquiry-modal-container .inquiry-modal-content').html(modalHTML);
        
// //         // Handle close button
// //         $('.close-modal').on('click', function() {
// //             $('#inquiry-modal-container').fadeOut();
// //         });
// //     }
// // });