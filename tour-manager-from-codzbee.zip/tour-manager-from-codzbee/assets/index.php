<?php
/** Add nonce for security */
wp_nonce_field('location_meta_box', 'location_meta_box_nonce');

/** Get saved values */
$location_types = get_post_meta($post->ID, '_location_types', true);
$activities = get_post_meta($post->ID, '_activities', true);
$attractions = get_post_meta($post->ID, '_attractions', true);

/** Convert to array if empty */
$location_types = empty($location_types) ? array() : $location_types;
// $activities = empty($activities) ? array() : maybe_unserialize($activities);
// $attractions = empty($attractions) ? array() : maybe_unserialize($attractions);


$activities = get_post_meta($post->ID, '_activities', true);
$activities = is_array($activities) ? $activities : maybe_unserialize($activities);
$activities = empty($activities) ? array() : $activities;


$attractions = get_post_meta($post->ID, '_attractions', true);
$attractions = is_array($attractions) ? $attractions : maybe_unserialize($attractions);
$attractions = empty($attractions) ? array() : $attractions;
?>



<div class="hotel-city-selection">
    <label for="hotel_city_id">Select City:</label>
    <select id="hotel_city_id" name="hotel_city_id" class="widefat">
        <option value="">-- Select a City --</option>
        <?php foreach ($this->cities_data as $city): ?>
            <option value="<?= esc_attr($city['id']); ?>" <?php selected($selected_city_id, $city['id']); ?>
                data-city-code="<?= esc_attr($city['code']); ?>" data-city-lat="<?= esc_attr($city['latitude']); ?>"
                data-city-lng="<?= esc_attr($city['longitude']); ?>">
                <?= esc_html($city['name']); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <div id="city-details" class="tm-city-details"
        style="margin-top: 15px; <?= empty($selected_city_id) ? 'display: none;' : ''; ?>">
        <h4>Selected City Details</h4>
        <div><strong>Code:</strong> <span id="city-code"><?= esc_html($selected_city_code); ?></span></div>
        <div><strong>Coordinates:</strong>
            <span id="city-latitude"><?= esc_html($selected_city_lat); ?></span>,
            <span id="city-longitude"><?= esc_html($selected_city_lng); ?></span>
        </div>
        <input type="hidden" id="city-name" name="hotel_city_name" value="<?= esc_attr($selected_city_name); ?>">
        <input type="hidden" id="city-code-value" name="hotel_city_code" value="<?= esc_attr($selected_city_code); ?>">
        <input type="hidden" id="city-lat-value" name="hotel_city_latitude"
            value="<?= esc_attr($selected_city_lat); ?>">
        <input type="hidden" id="city-lng-value" name="hotel_city_longitude"
            value="<?= esc_attr($selected_city_lng); ?>">
    </div>
</div>

<div class="tm-activity-attraction-field">
    <!-- Location Type Selection -->
    <div class="location-types">
        <h4>Location Types</h4>
        <label>
            <input type="checkbox" name="location_types[]" value="activity" <?php checked(in_array('activity', $location_types)); ?>>
            Activity
        </label>
        <label>
            <input type="checkbox" name="location_types[]" value="attraction" <?php checked(in_array('attraction', $location_types)); ?>>
            Attraction
        </label>
    </div>

    <!-- Activities Section -->
    <div class="activities-section"
        style="<?= !in_array('activity', $location_types) ? 'display:none;' : ''; ?>">
        <h4>Activities</h4>
        <div class="activities-container">
            <?php if (!empty($activities)): ?>
                <?php foreach ($activities as $index => $activity): ?>
                    <div class="activity-item" data-index="<?= $index; ?>">
                     
                            <div>Name:</div>
                            <input type="text" name="activities[<?= $index; ?>][name]"
                                value="<?= esc_attr($activity['name']); ?>">
                   
                            <div>Description:</div>
                            <textarea
                                name="activities[<?= $index; ?>][description]"><?= esc_textarea($activity['description']); ?></textarea>
                    
                        <div>
                            <div>Images:</div>
                            <div class="activity-images-container">
                                <?php
                                $activity_images = !empty($activity['images']) ? $activity['images'] : array();
                                if (!is_array($activity_images)) {
                                    $activity_images = array_filter(array_map('trim', explode(',', $activity_images)));
                                }
                                $main_image = !empty($activity['main_image']) ? $activity['main_image'] : 0;

                                foreach ($activity_images as $image_id):
                                    $image_url = wp_get_attachment_image_url($image_id, 'post-thumbnail');
                                    ?>
                                    <div class="activity-image-item" data-image-id="<?= $image_id; ?>">
                                        <img src="<?= esc_url($image_url); ?>" alt="">
                                        <input type="radio" name="activities[<?= $index; ?>][main_image]"
                                            value="<?= $image_id; ?>" <?php checked($image_id, $main_image); ?>>
                                        <!-- <label>Main Image</label> -->
                                        <button class="remove-activity-image button"
                                            data-image-id="<?= $image_id; ?>">X</button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" class="activity-image-ids" name="activities[<?= $index; ?>][images]"
                                value="<?= implode(',', $activity_images); ?>">
                            <button class="add-activity-images button">Add Images</button>
                        </div>

                        <!-- <button class="remove-activity-image button">Remove All Images</button> -->
                        <button class="remove-activity button">Remove Activity</button>
                    </div>

                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <button class="add-activity button">Add Activity</button>
    </div>

    <!-- Attractions Section -->
    <div class="attractions-section"
        style="<?= !in_array('attraction', $location_types) ? 'display:none;' : ''; ?>">
        <h4>Attractions</h4>
        <div class="attractions-container">
            <?php if (!empty($attractions)): ?>
                <?php foreach ($attractions as $index => $attraction): ?>
                    <div class="attraction-item" data-index="<?= $index; ?>">
                        
                        <div>Name:</div>
                        <input type="text" name="attractions[<?= $index; ?>][name]"
                            value="<?= esc_attr($attraction['name']); ?>">
 
                        <div>Description:</div>
                        <textarea
                            name="attractions[<?= $index; ?>][description]"><?= esc_textarea($attraction['description']); ?></textarea>

                        <div>
                            <div>Images:</div>
                            <div class="attraction-images-container">
                                <?php
                                $attraction_images = !empty($attraction['images']) ? $attraction['images'] : array();
                                if (!is_array($attraction_images)) {
                                    $attraction_images = array_filter(array_map('trim', explode(',', $attraction_images)));
                                }
                                $main_image = !empty($attraction['main_image']) ? $attraction['main_image'] : 0;

                                foreach ($attraction_images as $image_id):
                                    $image_url = wp_get_attachment_image_url($image_id, 'post-thumbnail');
                                    ?>
                                    <div class="attraction-image-item" data-image-id="<?= $image_id; ?>">
                                        <img src="<?= esc_url($image_url); ?>" alt="">
                                        <input type="radio" name="attractions[<?= $index; ?>][main_image]"
                                            value="<?= $image_id; ?>" <?php checked($image_id, $main_image); ?>>
                                        <button class="remove-attraction-image button"
                                            data-image-id="<?= $image_id; ?>">X</button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" class="attraction-image-ids" name="attractions[<?= $index; ?>][images]"
                                value="<?= implode(',', $attraction_images); ?>">
                            <button class="add-attraction-images button">Add Images</button>
                        </div>
                        <button class="remove-attraction button">Remove Attraction</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <button class="add-attraction button">Add Attraction</button>
    </div>
</div>

<script type="text/html" id="tmpl-activity-item">
    <div class="activity-item" data-index="{{data.index}}">

        <label>Name:</label>
        <input type="text" name="activities[{{data.index}}][name]" value="">

        <label>Description:</label>
        <textarea name="activities[{{data.index}}][description]"></textarea>

        <label>Image:</label>
        <input type="hidden" class="activity-image-id" name="activities[{{data.index}}][main_image]" value="">

        <div class="activity-image-preview"></div>
        <button class="upload-activity-image button">Upload Image</button>
        <button class="remove-activity-image button">Remove Image</button>

        <button class="remove-activity button">Remove Activity</button>
    </div>
</script>

<script type="text/html" id="tmpl-attraction-item">
        <div class="attraction-item" data-index="{{data.index}}">
            <p>
                <label>Name:</label>
                <input type="text" name="attractions[{{data.index}}][name]" value="">
            </p>
            <p>
                <label>Description:</label>
                <textarea name="attractions[{{data.index}}][description]"></textarea>
            </p>
            <p>
                <label>Image:</label>
                <input type="hidden" class="attraction-image-id" name="attractions[{{data.index}}][main_image]" value="">
                <div class="attraction-image-preview"></div>
                <button class="upload-attraction-image button">Upload Image</button>
                <button class="remove-attraction-image button">Remove Image</button>
            </p>
            <button class="remove-attraction button">Remove Attraction</button>
        </div>
    </script>

<style>
    .tm-city-details {
        background: #f9f9f9;
        padding: 15px;
        border: 1px solid #ddd;
    }

    .tm-activity-attraction-field .activity-item,
    .tm-activity-attraction-field .attraction-item {
        border: 1px solid #ddd;
        padding: 15px;
        margin-bottom: 15px;
        background: #f9f9f9;
    }

    .tm-activity-attraction-field label {
        display: inline-block;
        min-width: 100px;
        vertical-align: top;
    }

    .tm-activity-attraction-field input[type="text"],
    .tm-activity-attraction-field textarea {
        width: 100%;
        max-width: 400px;
    }

    .tm-activity-attraction-field textarea {
        height: 100px;
    }

    .tm-activity-attraction-field .activity-images-container,
    .tm-activity-attraction-field .attraction-images-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .tm-activity-attraction-field .activity-image-item img,
    .tm-activity-attraction-field .attraction-image-item img {
        max-width: 150px;
        width: 150px;
        height: 100px;
        display: block;
        margin-bottom: 10px;
    }

    .tm-activity-attraction-field .activity-image-item,
    .tm-activity-attraction-field .attraction-image-item {
        position: relative;
        display: inline-block;
    }

    .tm-activity-attraction-field .remove-activity-image.button,
    .tm-activity-attraction-field .remove-attraction-image.button {
        position: absolute;
        top: 5px;
        right: 5px;
        z-index: 2;
        padding: 2px 8px;
        font-size: 12px;
        background: #e74c3c;
        color: #fff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        opacity: 0.85;
    }

    .tm-activity-attraction-field .remove-activity-image.button:hover,
    .tm-activity-attraction-field .remove-attraction-image.button:hover {
        opacity: 1;
        background: #c0392b;
    }
</style>